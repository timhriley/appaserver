-- MySQL dump 10.13  Distrib 8.0.41, for Linux (x86_64)
--
-- Host: localhost    Database: template
-- ------------------------------------------------------
-- Server version	8.0.41-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `appaserver_application`
--

DROP TABLE IF EXISTS `appaserver_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appaserver_application` (
  `application` char(30) NOT NULL,
  `application_title` char(30) DEFAULT NULL,
  `user_date_format` char(15) DEFAULT NULL,
  `relative_source_directory` char(255) DEFAULT NULL,
  `next_session_number` int DEFAULT NULL,
  `next_reference_number` int DEFAULT NULL,
  `background_color` char(7) DEFAULT NULL,
  `menu_horizontal_yn` char(1) DEFAULT NULL,
  `grace_home_directory` char(50) DEFAULT NULL,
  `grace_execution_directory` char(50) DEFAULT NULL,
  `max_drop_down_size` int DEFAULT NULL,
  `ssl_support_yn` char(1) DEFAULT NULL,
  `max_query_rows_for_drop_downs` int DEFAULT NULL,
  UNIQUE KEY `appaserver_application` (`application`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appaserver_application`
--

LOCK TABLES `appaserver_application` WRITE;
/*!40000 ALTER TABLE `appaserver_application` DISABLE KEYS */;
INSERT INTO `appaserver_application` (`application`, `application_title`, `user_date_format`, `relative_source_directory`, `next_session_number`, `next_reference_number`, `background_color`, `menu_horizontal_yn`, `grace_home_directory`, `grace_execution_directory`, `max_drop_down_size`, `ssl_support_yn`, `max_query_rows_for_drop_downs`) VALUES ('template','Template Application','american','src_predictive:src_system',911,91,'#effdff','y','/usr/share/grace','/usr/bin',200,'y',50);
/*!40000 ALTER TABLE `appaserver_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appaserver_column`
--

DROP TABLE IF EXISTS `appaserver_column`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appaserver_column` (
  `column_name` char(60) NOT NULL,
  `column_datatype` char(20) DEFAULT NULL,
  `width` int DEFAULT NULL,
  `float_decimal_places` int DEFAULT NULL,
  `hint_message` text,
  UNIQUE KEY `appaserver_column` (`column_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appaserver_column`
--

LOCK TABLES `appaserver_column` WRITE;
/*!40000 ALTER TABLE `appaserver_column` DISABLE KEYS */;
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('permission','character',10,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('column_name','character',60,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('column_datatype','character',20,NULL,'');
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('command_line','character',512,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('float_decimal_places','integer',1,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('display_order','integer',3,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('drop_down_multi_select_yn','character',1,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('drop_down_prompt','character',50,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('drop_down_prompt_data','character',50,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('application','character',30,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('table_name','character',50,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('table_count_yn','character',1,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('pair_one2m_order','integer',2,NULL,'Pairing two related tables allows you to insert into the many-table at the same time you insert into the one-table.');
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('appaserver_form','character',6,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('hint_message','notepad',512,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('input_width','integer',5,0,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('insert_rows_number','integer',2,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('login_name','character',50,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('next_session_number','integer',5,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('notepad','notepad',4096,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('null','character',0,4,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('operation','character',30,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('output_yn','character',1,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('password','encrypt',56,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('person_full_name','character',30,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('populate_drop_down_process','character',40,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('insert_operation','character',40,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('update_operation','character',40,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('primary_key_index','integer',3,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('process','character',40,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('process_set','character',40,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('prompt','character',50,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('related_column','character',60,NULL,'It is required that all foreign keys be the same name as the corresponding primary keys, except the last one. If the last foreign key differs from the last primary key, set this attribute to it. This is necessary for recursive or multiple relationships. For example, the table RELATION has two relationships to FOLDER.');
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('related_table','character',50,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('role','character',25,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('session','character',10,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('width','integer',5,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('application_title','character',30,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('relative_source_directory','character',255,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('next_reference_number','integer',8,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('background_color','character',7,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('omit_drilldown_yn','character',1,NULL,'If a one-table has too many rows to effectively appear on the drilldown screen, then set this flag.');
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('relation_type_isa_yn','character',1,NULL,'Appaserver provides an \'isa\' relation for a many-table that \'isa\' one-table. When an \'isa\' relationship exists, then the many-table inherits the columns of the one-table. Note: the many-table\'s primary keys must match in quantity the one-table\'s primary keys.');
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('deactivated_yn','character',1,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('omit_insert_yn','character',1,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('upload_filename_yn','character',1,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('last_access_date','date',11,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('last_access_time','time',4,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('grace_home_directory','character',50,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('execution_count','integer',8,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('omit_insert_prompt_yn','character',1,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('menu_horizontal_yn','character',1,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('post_change_javascript','character',50,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('preprompt_yn','character',1,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('prompt_display_bottom_yn','character',1,0,'If all the processes in a process set are output processes, then placing the process selection at the bottom might be appropriate.');
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('html_help_file_anchor','character',50,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('javascript_filename','character',80,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('row_access_count','integer',6,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('post_change_process','character',40,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('index_directory','character',50,0,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('copy_common_columns_yn','character',1,NULL,'Set this flag if you have a column in the many-table with the same name as a column in the one-table. Appaserver will copy the datum from the one-table when you insert into the many-table. The prime example is to insert the retail price of a sale by copying the retail price from the inventory.');
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('additional_unique_index_yn','character',1,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('additional_index_yn','character',1,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('ssl_support_yn','character',1,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('max_drop_down_size','integer',5,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('automatic_preselection_yn','character',1,NULL,'When inserting new rows, you may want to preselect only the many-table rows that join to the one-table. When this flag is set, the edit screen appears like a spreadsheet, allowing you to easily insert an entire block of data at a time. ');
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('override_row_restrictions_yn','character',1,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('row_level_restriction','character',30,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('datatype_bar_graph_yn','character',1,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('datatype_scale_graph_zero_yn','character',1,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('grace_execution_directory','character',50,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('tablespace','character',20,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('exclude_application_export_yn','character',1,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('date_format','character',15,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('user_date_format','character',15,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('date_yn','character',1,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('date_column','character',60,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('time_column','character',60,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('datatype_table','character',50,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('lookup_required_yn','character',1,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('appaserver_version','character',10,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('http_user_agent','character',80,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('process_generic_unit','character',15,NULL,'Where is the units attribute?');
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('process_set_display','character',40,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('remote_ip_address','character',15,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('login_date','date',11,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('login_time','time',4,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('max_query_rows_for_drop_downs','integer',4,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('application_constant','character',80,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('application_constant_value','character',255,0,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('insert_required_yn','character',1,0,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('optional_display','character',40,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('foreign_table','character',50,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('drillthru_yn','character',1,0,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('prompt_display_text','character',25,0,'By default, the prompt for the process names is \'Process\'. However, many process sets are output-only processes. Therefore, changing the prompt display to \'Output Medium\' is desirable.');
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('join_one2m_each_row_yn','character',1,0,'');
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('select_statement','notepad',4096,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('foreign_key_index','integer',3,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('subschema','character',30,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('process_group','character',20,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('upgrade_script','character',80,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('value_column','character',60,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('value_table','character',50,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('no_initial_capital_yn','character',1,0,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('drop_down_folder','character',50,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('prepend_yn','character',1,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('populate_helper_process','character',40,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('omit_update_yn','character',1,0,'');
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('data_directory','character',50,0,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('datatype_aggregation_sum_yn','character',1,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('select_statement_title','character',80,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('column_not_null','character',60,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('preprompt_help_text','notepad',1024,0,'');
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('omit_drillthru_yn','character',1,0,'');
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('ajax_fill_drop_down_yn','character',1,0,'');
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('foreign_column','character',60,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('create_view_statement','notepad',4096,0,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('datatype_column','character',60,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('datatype_units_yn','character',1,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('foreign_units_yn','character',1,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('default_value','character',10,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('interface','character',10,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('IP_address','character',15,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('date','current_date',10,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('receive_daily_megabytes','integer',5,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('receive_megabytes','integer',10,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('transmit_daily_megabytes','integer',5,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('transmit_megabytes','integer',10,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('cell_phone_number','character',15,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('city','character',20,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('email_address','character',50,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('full_name','character',60,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('land_phone_number','character',15,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('state_code','character',2,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('street_address','character',60,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('website_address','character',50,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('website_login','character',50,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('website_password','password',20,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('zip_code','character',10,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('credit_card_expiration_month_year','character',4,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('credit_card_number','character',20,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('credit_card_security_code','character',3,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('credit_provider','character',30,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('invoice_amount_due','float',10,2,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('storage_engine','character',10,NULL,NULL);
INSERT INTO `appaserver_column` (`column_name`, `column_datatype`, `width`, `float_decimal_places`, `hint_message`) VALUES ('invoice_statement_current','upload_file',50,NULL,NULL);
/*!40000 ALTER TABLE `appaserver_column` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appaserver_form`
--

DROP TABLE IF EXISTS `appaserver_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appaserver_form` (
  `appaserver_form` char(6) NOT NULL,
  UNIQUE KEY `appaserver_form` (`appaserver_form`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appaserver_form`
--

LOCK TABLES `appaserver_form` WRITE;
/*!40000 ALTER TABLE `appaserver_form` DISABLE KEYS */;
INSERT INTO `appaserver_form` (`appaserver_form`) VALUES ('prompt');
INSERT INTO `appaserver_form` (`appaserver_form`) VALUES ('table');
/*!40000 ALTER TABLE `appaserver_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appaserver_table`
--

DROP TABLE IF EXISTS `appaserver_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appaserver_table` (
  `table_name` char(50) NOT NULL,
  `appaserver_form` char(6) DEFAULT NULL,
  `insert_rows_number` int DEFAULT NULL,
  `populate_drop_down_process` char(40) DEFAULT NULL,
  `notepad` text,
  `no_initial_capital_yn` char(1) DEFAULT NULL,
  `html_help_file_anchor` char(50) DEFAULT NULL,
  `post_change_javascript` char(50) DEFAULT NULL,
  `post_change_process` char(40) DEFAULT NULL,
  `drillthru_yn` char(1) DEFAULT NULL,
  `exclude_application_export_yn` char(1) DEFAULT NULL,
  `subschema` char(30) DEFAULT NULL,
  `data_directory` char(50) DEFAULT NULL,
  `index_directory` char(50) DEFAULT NULL,
  `create_view_statement` text,
  `javascript_filename` char(80) DEFAULT NULL,
  `storage_engine` char(10) DEFAULT NULL,
  UNIQUE KEY `appaserver_table` (`table_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appaserver_table`
--

LOCK TABLES `appaserver_table` WRITE;
/*!40000 ALTER TABLE `appaserver_table` DISABLE KEYS */;
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('session','prompt',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'security',NULL,NULL,NULL,NULL,'memory');
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('appaserver_user','prompt',1,NULL,NULL,NULL,NULL,NULL,'appaserver_user_trigger','n',NULL,'security',NULL,NULL,NULL,NULL,'InnoDB');
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('application','table',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'application',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('column','prompt',10,'attribute_list',NULL,NULL,NULL,'post_change_attribute( $row )',NULL,NULL,NULL,'schema',NULL,NULL,NULL,'post_change_attribute.js',NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('column_datatype','table',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'schema',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('column_exclude','prompt',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'security',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('drop_down_prompt','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'process',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('drop_down_prompt_data','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'process',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('table','prompt',5,'folder_list',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'schema',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('table_column','prompt',20,NULL,NULL,NULL,NULL,'post_change_folder_attribute( $row )',NULL,NULL,NULL,'schema',NULL,NULL,NULL,'post_change_folder_attribute.js',NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('appaserver_form','table',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'schema',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('null',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'application',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('operation','table',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'operation',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('permission','table',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'security',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('process','prompt',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'process',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('process_set','prompt',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'process_set',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('prompt','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'process',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('relation','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,'y',NULL,'schema',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('role','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'security',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('role_appaserver_user','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'security',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('role_table','prompt',20,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'security',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('table_operation','prompt',20,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'operation',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('role_process','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'process',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('role_process_set_member','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'process_set',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('row_level_restriction','table',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'security',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('table_row_level_restriction','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'security',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('date_format','table',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'application',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('application_constant','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'application',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('process_group','table',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'process',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('process_parameter','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'process',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('self','table',1,NULL,'<ol><li>One row for the entity running Appaserver<li>Must be set in order to run PredictBooks<li>Email Address must be set in order for Appahost to contact you<li>Credit card information must be set in order for you to contract with Appahost</ol>',NULL,NULL,NULL,'self_trigger',NULL,NULL,'entity',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('process_set_parameter','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'process_set',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('subschema','table',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'schema',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('upgrade_script','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'application',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('row_security_role_update','table',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'security',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('login_default_role','table',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'security',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('select_statement','prompt',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'application',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('foreign_column','prompt',5,NULL,'Normally, the foreign keys are the same names as their corresponding primary keys. Moreover, they are in the same order as their corresponding primary keys. Frequently, the last foreign key may differ. If only the last foreign key differs, then set RELATION.related_column. Infrequently, the foreign keys are not in the same order, or multiple foreign key names differ. If so, then populate FOREIGN_COLUMN.',NULL,NULL,NULL,NULL,NULL,NULL,'schema',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('entity','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'entity',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('process_generic','table',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'process_generic',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('process_generic_value','table',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'process_generic',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('financial_institution','table',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'entity',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('storage_engine','table',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'schema',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `appaserver_table` (`table_name`, `appaserver_form`, `insert_rows_number`, `populate_drop_down_process`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `drillthru_yn`, `exclude_application_export_yn`, `subschema`, `data_directory`, `index_directory`, `create_view_statement`, `javascript_filename`, `storage_engine`) VALUES ('vendor','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'entity',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `appaserver_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appaserver_user`
--

DROP TABLE IF EXISTS `appaserver_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appaserver_user` (
  `login_name` char(50) NOT NULL,
  `person_full_name` char(30) DEFAULT NULL,
  `password` char(56) DEFAULT NULL,
  `user_date_format` char(15) DEFAULT NULL,
  `deactivated_yn` char(1) DEFAULT NULL,
  UNIQUE KEY `appaserver_user` (`login_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appaserver_user`
--

LOCK TABLES `appaserver_user` WRITE;
/*!40000 ALTER TABLE `appaserver_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `appaserver_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `application_constant`
--

DROP TABLE IF EXISTS `application_constant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `application_constant` (
  `application_constant` char(80) NOT NULL,
  `application_constant_value` char(255) DEFAULT NULL,
  UNIQUE KEY `application_constant` (`application_constant`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_constant`
--

LOCK TABLES `application_constant` WRITE;
/*!40000 ALTER TABLE `application_constant` DISABLE KEYS */;
INSERT INTO `application_constant` (`application_constant`, `application_constant_value`) VALUES ('#color4','#ccefff');
INSERT INTO `application_constant` (`application_constant`, `application_constant_value`) VALUES ('easycharts_width','800');
INSERT INTO `application_constant` (`application_constant`, `application_constant_value`) VALUES ('easycharts_height','500');
INSERT INTO `application_constant` (`application_constant`, `application_constant_value`) VALUES ('#color3','#a6e2ff');
INSERT INTO `application_constant` (`application_constant`, `application_constant_value`) VALUES ('#color2','#8cdaff');
INSERT INTO `application_constant` (`application_constant`, `application_constant_value`) VALUES ('#color5','#e6f7ff');
INSERT INTO `application_constant` (`application_constant`, `application_constant_value`) VALUES ('#color1','#73d2ff');
INSERT INTO `application_constant` (`application_constant`, `application_constant_value`) VALUES ('color1','#B4CDCD');
INSERT INTO `application_constant` (`application_constant`, `application_constant_value`) VALUES ('##color2','#94d6e7');
INSERT INTO `application_constant` (`application_constant`, `application_constant_value`) VALUES ('##color3','#c6eff7');
INSERT INTO `application_constant` (`application_constant`, `application_constant_value`) VALUES ('color2','#ffffff');
INSERT INTO `application_constant` (`application_constant`, `application_constant_value`) VALUES ('google_map_key','unknown');
INSERT INTO `application_constant` (`application_constant`, `application_constant_value`) VALUES ('cat_javascript_source','no');
INSERT INTO `application_constant` (`application_constant`, `application_constant_value`) VALUES ('utc_offset','-8');
/*!40000 ALTER TABLE `application_constant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `column_datatype`
--

DROP TABLE IF EXISTS `column_datatype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `column_datatype` (
  `column_datatype` char(20) NOT NULL,
  UNIQUE KEY `column_datatype` (`column_datatype`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `column_datatype`
--

LOCK TABLES `column_datatype` WRITE;
/*!40000 ALTER TABLE `column_datatype` DISABLE KEYS */;
INSERT INTO `column_datatype` (`column_datatype`) VALUES ('character');
INSERT INTO `column_datatype` (`column_datatype`) VALUES ('current_date');
INSERT INTO `column_datatype` (`column_datatype`) VALUES ('current_date_time');
INSERT INTO `column_datatype` (`column_datatype`) VALUES ('current_time');
INSERT INTO `column_datatype` (`column_datatype`) VALUES ('date');
INSERT INTO `column_datatype` (`column_datatype`) VALUES ('date_time');
INSERT INTO `column_datatype` (`column_datatype`) VALUES ('encrypt');
INSERT INTO `column_datatype` (`column_datatype`) VALUES ('float');
INSERT INTO `column_datatype` (`column_datatype`) VALUES ('integer');
INSERT INTO `column_datatype` (`column_datatype`) VALUES ('notepad');
INSERT INTO `column_datatype` (`column_datatype`) VALUES ('password');
INSERT INTO `column_datatype` (`column_datatype`) VALUES ('reference_number');
INSERT INTO `column_datatype` (`column_datatype`) VALUES ('time');
INSERT INTO `column_datatype` (`column_datatype`) VALUES ('timestamp');
INSERT INTO `column_datatype` (`column_datatype`) VALUES ('upload_file');
/*!40000 ALTER TABLE `column_datatype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `column_exclude`
--

DROP TABLE IF EXISTS `column_exclude`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `column_exclude` (
  `role` char(25) NOT NULL,
  `column_name` char(60) NOT NULL,
  `permission` char(10) NOT NULL,
  UNIQUE KEY `column_exclude` (`role`,`column_name`,`permission`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `column_exclude`
--

LOCK TABLES `column_exclude` WRITE;
/*!40000 ALTER TABLE `column_exclude` DISABLE KEYS */;
INSERT INTO `column_exclude` (`role`, `column_name`, `permission`) VALUES ('system','deactivated_yn','insert');
INSERT INTO `column_exclude` (`role`, `column_name`, `permission`) VALUES ('system','execution_count','insert');
/*!40000 ALTER TABLE `column_exclude` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `date_format`
--

DROP TABLE IF EXISTS `date_format`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `date_format` (
  `date_format` char(15) NOT NULL,
  UNIQUE KEY `date_format` (`date_format`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `date_format`
--

LOCK TABLES `date_format` WRITE;
/*!40000 ALTER TABLE `date_format` DISABLE KEYS */;
INSERT INTO `date_format` (`date_format`) VALUES ('american');
INSERT INTO `date_format` (`date_format`) VALUES ('international');
INSERT INTO `date_format` (`date_format`) VALUES ('military');
/*!40000 ALTER TABLE `date_format` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drop_down_prompt`
--

DROP TABLE IF EXISTS `drop_down_prompt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drop_down_prompt` (
  `drop_down_prompt` char(50) NOT NULL,
  `hint_message` text,
  `optional_display` char(40) DEFAULT NULL,
  UNIQUE KEY `drop_down_prompt` (`drop_down_prompt`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drop_down_prompt`
--

LOCK TABLES `drop_down_prompt` WRITE;
/*!40000 ALTER TABLE `drop_down_prompt` DISABLE KEYS */;
INSERT INTO `drop_down_prompt` (`drop_down_prompt`, `hint_message`, `optional_display`) VALUES ('null','Necessary for outter joins to work',NULL);
INSERT INTO `drop_down_prompt` (`drop_down_prompt`, `hint_message`, `optional_display`) VALUES ('export_output',NULL,NULL);
INSERT INTO `drop_down_prompt` (`drop_down_prompt`, `hint_message`, `optional_display`) VALUES ('export_application_export_output',NULL,'export_output');
INSERT INTO `drop_down_prompt` (`drop_down_prompt`, `hint_message`, `optional_display`) VALUES ('execute_select_statement_output_medium',NULL,'output_medium');
/*!40000 ALTER TABLE `drop_down_prompt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drop_down_prompt_data`
--

DROP TABLE IF EXISTS `drop_down_prompt_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drop_down_prompt_data` (
  `drop_down_prompt` char(50) NOT NULL,
  `drop_down_prompt_data` char(50) NOT NULL,
  `display_order` int DEFAULT NULL,
  UNIQUE KEY `drop_down_prompt_data` (`drop_down_prompt`,`drop_down_prompt_data`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drop_down_prompt_data`
--

LOCK TABLES `drop_down_prompt_data` WRITE;
/*!40000 ALTER TABLE `drop_down_prompt_data` DISABLE KEYS */;
INSERT INTO `drop_down_prompt_data` (`drop_down_prompt`, `drop_down_prompt_data`, `display_order`) VALUES ('export_output','shell_script',1);
INSERT INTO `drop_down_prompt_data` (`drop_down_prompt`, `drop_down_prompt_data`, `display_order`) VALUES ('export_output','gzip_file',2);
INSERT INTO `drop_down_prompt_data` (`drop_down_prompt`, `drop_down_prompt_data`, `display_order`) VALUES ('export_application_export_output','shell_script',1);
INSERT INTO `drop_down_prompt_data` (`drop_down_prompt`, `drop_down_prompt_data`, `display_order`) VALUES ('export_application_export_output','spreadsheet',2);
INSERT INTO `drop_down_prompt_data` (`drop_down_prompt`, `drop_down_prompt_data`, `display_order`) VALUES ('execute_select_statement_output_medium','table',1);
INSERT INTO `drop_down_prompt_data` (`drop_down_prompt`, `drop_down_prompt_data`, `display_order`) VALUES ('execute_select_statement_output_medium','spreadsheet',2);
/*!40000 ALTER TABLE `drop_down_prompt_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entity`
--

DROP TABLE IF EXISTS `entity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entity` (
  `full_name` char(60) NOT NULL,
  `street_address` char(60) NOT NULL,
  `city` char(20) DEFAULT NULL,
  `state_code` char(2) DEFAULT NULL,
  `zip_code` char(10) DEFAULT NULL,
  `land_phone_number` char(15) DEFAULT NULL,
  `cell_phone_number` char(15) DEFAULT NULL,
  `email_address` char(50) DEFAULT NULL,
  `notepad` text,
  UNIQUE KEY `entity` (`full_name`,`street_address`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entity`
--

LOCK TABLES `entity` WRITE;
/*!40000 ALTER TABLE `entity` DISABLE KEYS */;
INSERT INTO `entity` (`full_name`, `street_address`, `city`, `state_code`, `zip_code`, `land_phone_number`, `cell_phone_number`, `email_address`, `notepad`) VALUES ('bank_of_america','100 North Tryon Street','Charlotte','NC','28255',NULL,NULL,NULL,NULL);
INSERT INTO `entity` (`full_name`, `street_address`, `city`, `state_code`, `zip_code`, `land_phone_number`, `cell_phone_number`, `email_address`, `notepad`) VALUES ('JP_morgan_chase','270 Park Avenue','New York','NY','10017',NULL,NULL,NULL,NULL);
INSERT INTO `entity` (`full_name`, `street_address`, `city`, `state_code`, `zip_code`, `land_phone_number`, `cell_phone_number`, `email_address`, `notepad`) VALUES ('Set Me','1234 Set Me',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `entity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `financial_institution`
--

DROP TABLE IF EXISTS `financial_institution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `financial_institution` (
  `full_name` char(60) NOT NULL,
  `street_address` char(60) NOT NULL DEFAULT 'unknown',
  UNIQUE KEY `financial_institution` (`full_name`,`street_address`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `financial_institution`
--

LOCK TABLES `financial_institution` WRITE;
/*!40000 ALTER TABLE `financial_institution` DISABLE KEYS */;
INSERT INTO `financial_institution` (`full_name`, `street_address`) VALUES ('bank_of_america','100 North Tryon Street');
INSERT INTO `financial_institution` (`full_name`, `street_address`) VALUES ('JP_morgan_chase','270 Park Avenue');
/*!40000 ALTER TABLE `financial_institution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `foreign_column`
--

DROP TABLE IF EXISTS `foreign_column`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `foreign_column` (
  `table_name` char(50) NOT NULL,
  `related_table` char(50) NOT NULL,
  `related_column` char(60) NOT NULL,
  `foreign_column` char(60) NOT NULL,
  `foreign_key_index` int DEFAULT NULL,
  UNIQUE KEY `foreign_column` (`table_name`,`related_table`,`related_column`,`foreign_column`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `foreign_column`
--

LOCK TABLES `foreign_column` WRITE;
/*!40000 ALTER TABLE `foreign_column` DISABLE KEYS */;
/*!40000 ALTER TABLE `foreign_column` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_default_role`
--

DROP TABLE IF EXISTS `login_default_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_default_role` (
  `login_name` char(50) NOT NULL,
  `role` char(25) DEFAULT NULL,
  UNIQUE KEY `login_default_role` (`login_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_default_role`
--

LOCK TABLES `login_default_role` WRITE;
/*!40000 ALTER TABLE `login_default_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_default_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operation`
--

DROP TABLE IF EXISTS `operation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operation` (
  `operation` char(30) NOT NULL,
  `output_yn` char(1) DEFAULT NULL,
  UNIQUE KEY `operation` (`operation`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operation`
--

LOCK TABLES `operation` WRITE;
/*!40000 ALTER TABLE `operation` DISABLE KEYS */;
INSERT INTO `operation` (`operation`, `output_yn`) VALUES ('delete','n');
INSERT INTO `operation` (`operation`, `output_yn`) VALUES ('drilldown','y');
INSERT INTO `operation` (`operation`, `output_yn`) VALUES ('delete_isa_only',NULL);
INSERT INTO `operation` (`operation`, `output_yn`) VALUES ('null','n');
INSERT INTO `operation` (`operation`, `output_yn`) VALUES ('google_map','y');
/*!40000 ALTER TABLE `operation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission`
--

DROP TABLE IF EXISTS `permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission` (
  `permission` char(10) NOT NULL,
  UNIQUE KEY `permission` (`permission`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission`
--

LOCK TABLES `permission` WRITE;
/*!40000 ALTER TABLE `permission` DISABLE KEYS */;
INSERT INTO `permission` (`permission`) VALUES ('insert');
INSERT INTO `permission` (`permission`) VALUES ('lookup');
INSERT INTO `permission` (`permission`) VALUES ('update');
/*!40000 ALTER TABLE `permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process`
--

DROP TABLE IF EXISTS `process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `process` (
  `process` char(40) NOT NULL,
  `command_line` text,
  `notepad` text,
  `html_help_file_anchor` char(50) DEFAULT NULL,
  `execution_count` int DEFAULT NULL,
  `post_change_javascript` char(50) DEFAULT NULL,
  `process_group` char(20) DEFAULT NULL,
  `process_set_display` char(40) DEFAULT NULL,
  `preprompt_help_text` text,
  `javascript_filename` char(80) DEFAULT NULL,
  UNIQUE KEY `process` (`process`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process`
--

LOCK TABLES `process` WRITE;
/*!40000 ALTER TABLE `process` DISABLE KEYS */;
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('add_column','add_column $process folder attribute execute_yn',NULL,NULL,2,NULL,'alter',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('alter_column_datatype','alter_column_datatype $process folder attribute execute_yn',NULL,NULL,NULL,NULL,'alter',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('clone_table','clone_folder $process table_name column_name old_data new_data delete_yn execute_yn',NULL,NULL,NULL,NULL,'alter',NULL,NULL,'clone_folder.js');
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('populate_account','populate_account.sh $many_table subclassification',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('create_application','create_application $login_name $process destination_application new_application_title execute_yn','This process creates a new application that is a clone of the current application. For security on a public facing website, the source code must be compiled with NON_TEMPLATE_APPLICATION_OKAY set to 1.',NULL,NULL,NULL,'alter',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('create_table','create_table $process folder execute_yn',NULL,NULL,3,NULL,'alter',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('drilldown','drilldown $session $login_name $role $target_frame $folder $primary_data_list $update_results $update_error $dictionary',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('rename_table','rename_table $process old_table table_name execute_yn',NULL,NULL,NULL,NULL,'alter',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('view_documentation','view_diagrams $process',NULL,NULL,NULL,NULL,'view',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('view_source','view_source $process',NULL,NULL,1,NULL,'view',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('rename_column','rename_column $process old_column table_name column_name execute_yn',NULL,NULL,NULL,NULL,'alter',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('export_table','export_table $process table_name export_output',NULL,NULL,8,NULL,'output',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('table_rectification','table_rectification $session $login_name $process','This process compares the Appaserver attributes with the Mysql table columns. It then gives you the opportunity to drop the residual columns.',NULL,11,NULL,'alter',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('export_process','export_process $process process exclude_roles_yn','For a list of processes, this process exports from the following: process, role_process, process_parameter, prompt, drop_down_prompt, and drop_down_prompt_data.',NULL,14,NULL,'output',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('generic_load','generic_load $login $session $process $role',NULL,NULL,NULL,NULL,'load',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('fix_orphans','fix_orphans $process orphans_table delete_yn execute_yn','This process traverses the many-to-one relationships for each table. It inserts the missing primary keys that contain foreign keys in an orphaned table.',NULL,NULL,NULL,'alter',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('export_process_set','export_process_set $process process_set exclude_roles_yn','For a list of process sets, this process exports from the following: process_set, role_process_set_member, process_set_parameter, prompt, drop_down_prompt, and drop_down_prompt_data.',NULL,NULL,NULL,'output',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('delete','delete_folder_row $session $login_name $role $folder $primary_data_list n',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('delete_isa_only','delete_folder_row $session $login_name $role $folder $primary_data_list y',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('appaserver_info','appaserver_info.sh $process',NULL,NULL,NULL,NULL,'view',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('orphans_process_folder_list','orphans_process_folder_list.sh $application',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('export_application','export_application $process system_tables_yn export_output',NULL,NULL,NULL,NULL,'output',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('attribute_list','attribute_list ignored $dictionary',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('change_password','change_password $session $login_name $role $process',NULL,NULL,NULL,NULL,'alter',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('create_empty_application','create_empty_application $session $login_name $process destination_application new_application_title execute_yn','This process creates an empty application. It creates a new database, the Appaserver tables, the data directories, among other application objects. Following this process, you can begin inserting the table rows.',NULL,518,NULL,'alter',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('google_map','google_map_operation $session $login_name $role $folder edit_frame $process latitude longitude utm_easting utm_northing $primary_data_list $process_id $operation_row_count',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('grant_select_to_user','grant_select_to_user $process login_name connect_from_host revoke_only_yn execute_yn',NULL,NULL,NULL,NULL,'alter',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('view_appaserver_log_file','view_appaserver_error_file.sh $process line_count','Most error messages are logged to this file. If you get the Server Error screen, then this file is the first place to find a clue. <big><bold>Warning:</bold></big> this process exposes password changes and session numbers.',NULL,NULL,NULL,'view',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('execute_select_statement','execute_select_statement $process $session $role select_statement_title login_name statement',NULL,NULL,NULL,NULL,'output',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('upload_source_file','upload_source_file ignored $process filename','This process allows you to upload non-executable source files, like javascript. The destination directory is $APPASERVER_HOME/src_$application. However, it may not exist. To have it created, visit <a href=https://appahost.com/contact target=_new>https://appahost.com/contact</a>.',NULL,NULL,NULL,'load',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('merge_purge','merge_purge $session $login_name $role $process','This process allows you to remove duplicate rows. It may be that two rows should really be one row because a spelling is slightly different in one of them.',NULL,NULL,NULL,'alter',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('graphviz_database_schema','graphviz_database_schema_process.sh $process appaserver_yn',NULL,NULL,NULL,NULL,'view',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('folder_list','folder_list.sh $application',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('appaserver_user_trigger','appaserver_user_trigger login_name $state preupdate_password password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('delete_application','delete_application $process delete_application execute_yn',NULL,NULL,28,NULL,'alter',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('import_predictBooks','import_predictbooks $session $login_name $role $process full_name name_of_bank checking_begin_date checking_begin_balance execute_yn','<p>This process imports the PredictBooks home edition.<ol><li>Download all of your checking transactions from your bank.<li>Execute this process.<li>Execute the soon to be installed checking upload process.</ol>',NULL,NULL,'post_change_import_predictbooks()','alter',NULL,NULL,'post_change_import_predictbooks.js');
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('drop_column','drop_column $application $session $login_name $role $process table_name column_name content_type_yn execute_yn',NULL,NULL,1,NULL,'alter',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('drop_table','drop_table $application $session $login_name $role $process table_name content_type_yn execute_yn',NULL,NULL,5,NULL,'alter',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('export_subschema','export_subschema $process table_name exclude_roles_yn','For a list of tables, this process exports from the following: table, relation, table_column, column, table_operation, role_table, row_security_role_update, table_row_level_restriction, and foreign_column.',NULL,11,NULL,'output',NULL,NULL,NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `preprompt_help_text`, `javascript_filename`) VALUES ('self_trigger','self_trigger $state full_name street_address preupdate_credit_card_number credit_card_number',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `process` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_generic`
--

DROP TABLE IF EXISTS `process_generic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `process_generic` (
  `process` char(40) NOT NULL,
  `process_set` char(40) NOT NULL,
  `value_table` char(50) DEFAULT NULL,
  `value_column` char(60) DEFAULT NULL,
  UNIQUE KEY `process_generic` (`process`,`process_set`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_generic`
--

LOCK TABLES `process_generic` WRITE;
/*!40000 ALTER TABLE `process_generic` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_generic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_generic_value`
--

DROP TABLE IF EXISTS `process_generic_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `process_generic_value` (
  `value_table` char(50) DEFAULT NULL,
  `value_column` char(60) DEFAULT NULL,
  `datatype_table` char(50) DEFAULT NULL,
  `foreign_table` char(50) DEFAULT NULL,
  `datatype_column` char(60) DEFAULT NULL,
  `date_column` char(60) DEFAULT NULL,
  `time_column` char(60) DEFAULT NULL,
  `datatype_aggregation_sum_yn` char(1) DEFAULT NULL,
  `datatype_bar_graph_yn` char(1) DEFAULT NULL,
  `datatype_scale_graph_zero_yn` char(1) DEFAULT NULL,
  `datatype_units_yn` char(1) DEFAULT NULL,
  `foreign_units_yn` char(1) DEFAULT NULL,
  UNIQUE KEY `process_generic_value` (`value_table`,`value_column`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_generic_value`
--

LOCK TABLES `process_generic_value` WRITE;
/*!40000 ALTER TABLE `process_generic_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_generic_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_group`
--

DROP TABLE IF EXISTS `process_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `process_group` (
  `process_group` char(20) NOT NULL,
  UNIQUE KEY `process_group` (`process_group`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_group`
--

LOCK TABLES `process_group` WRITE;
/*!40000 ALTER TABLE `process_group` DISABLE KEYS */;
INSERT INTO `process_group` (`process_group`) VALUES ('alter');
INSERT INTO `process_group` (`process_group`) VALUES ('documentation');
INSERT INTO `process_group` (`process_group`) VALUES ('load');
INSERT INTO `process_group` (`process_group`) VALUES ('output');
INSERT INTO `process_group` (`process_group`) VALUES ('view');
/*!40000 ALTER TABLE `process_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_parameter`
--

DROP TABLE IF EXISTS `process_parameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `process_parameter` (
  `process` char(40) NOT NULL,
  `table_name` char(50) NOT NULL,
  `column_name` char(60) NOT NULL,
  `prompt` char(50) NOT NULL,
  `drop_down_prompt` char(50) NOT NULL,
  `display_order` int DEFAULT NULL,
  `drop_down_multi_select_yn` char(1) DEFAULT NULL,
  `drillthru_yn` char(1) DEFAULT NULL,
  `populate_drop_down_process` char(40) DEFAULT NULL,
  `populate_helper_process` char(40) DEFAULT NULL,
  UNIQUE KEY `process_parameter` (`process`,`table_name`,`column_name`,`drop_down_prompt`,`prompt`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_parameter`
--

LOCK TABLES `process_parameter` WRITE;
/*!40000 ALTER TABLE `process_parameter` DISABLE KEYS */;
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('clone_table','table_column','null','null','null',3,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('create_application','null','null','destination_application','null',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('create_table','null','null','execute_yn','null',4,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('drop_column','table','null','null','null',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('rename_table','null','null','execute_yn','null',9,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('add_column','table_column','null','null','null',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('clone_table','null','null','old_data','null',4,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('rename_column','column','null','null','null',1,NULL,'y',NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('rename_column','null','null','old_column','null',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('add_column','null','null','execute_yn','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('clone_table','null','null','execute_yn','null',9,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('clone_table','null','null','new_data','null',5,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('clone_table','column','null','null','null',1,NULL,'y',NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('alter_column_datatype','table_column','null','null','null',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('rename_table','null','null','old_table','null',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('export_process','process','null','null','null',1,'y',NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('rename_column','null','null','execute_yn','null',9,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('clone_table','null','null','delete_yn','null',7,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('export_process_set','process_set','null','null','null',1,'y',NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('export_subschema','null','null','exclude_roles_yn','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('rename_column','table_column','null','null','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('drop_column','null','null','execute_yn','null',9,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('drop_column','null','null','column_name','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('export_process','null','null','exclude_roles_yn','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('alter_column_datatype','null','null','execute_yn','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('rename_table','table','null','null','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('create_application','null','null','new_application_title','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('create_table','table','null','null','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('export_application','null','null','system_tables_yn','null',3,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('export_table','null','null','null','export_output',3,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('execute_select_statement','null','null','statement','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('export_table','table','null','null','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('export_process_set','null','null','exclude_roles_yn','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('fix_orphans','null','null','delete_yn','null',5,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('add_column','column','null','null','null',1,NULL,'y',NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('alter_column_datatype','column','null','null','null',1,NULL,'y',NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('export_application','null','null','null','export_output',4,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('create_application','null','null','execute_yn','null',9,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('create_empty_application','null','null','execute_yn','null',9,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('create_empty_application','null','null','new_application_title','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('upload_source_file','null','null','filename','null',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('create_empty_application','null','null','destination_application','null',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('export_subschema','table','null','null','null',1,'y',NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('import_predictBooks','null','null','execute_yn','null',5,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('execute_select_statement','select_statement','null','null','null',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('grant_select_to_user','null','null','execute_yn','null',3,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('grant_select_to_user','null','null','connect_from_host','null',3,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('grant_select_to_user','appaserver_user','null','null','null',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('view_appaserver_log_file','null','null','line_count','null',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('fix_orphans','null','null','execute_yn','null',9,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('grant_select_to_user','null','null','revoke_only_yn','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('graphviz_database_schema','null','null','appaserver_yn','null',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('import_predictBooks','null','null','checking_begin_balance','null',4,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('import_predictBooks','null','null','checking_begin_date','null',3,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('delete_application','null','null','delete_application','null',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('delete_application','null','null','execute_yn','null',9,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('drop_table','null','null','table_name','null',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('drop_table','null','null','execute_yn','null',9,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('import_predictBooks','financial_institution','null','null','null',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `table_name`, `column_name`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `drillthru_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('import_predictBooks','null','null','name_of_bank','null',2,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `process_parameter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_set`
--

DROP TABLE IF EXISTS `process_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `process_set` (
  `process_set` char(40) NOT NULL,
  `notepad` text,
  `html_help_file_anchor` char(50) DEFAULT NULL,
  `post_change_javascript` char(50) DEFAULT NULL,
  `prompt_display_text` char(25) DEFAULT NULL,
  `prompt_display_bottom_yn` char(1) DEFAULT NULL,
  `process_group` char(20) DEFAULT NULL,
  `preprompt_help_text` text,
  `javascript_filename` char(80) DEFAULT NULL,
  UNIQUE KEY `process_set` (`process_set`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_set`
--

LOCK TABLES `process_set` WRITE;
/*!40000 ALTER TABLE `process_set` DISABLE KEYS */;
INSERT INTO `process_set` (`process_set`, `notepad`, `html_help_file_anchor`, `post_change_javascript`, `prompt_display_text`, `prompt_display_bottom_yn`, `process_group`, `preprompt_help_text`, `javascript_filename`) VALUES ('null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `process_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_set_parameter`
--

DROP TABLE IF EXISTS `process_set_parameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `process_set_parameter` (
  `process_set` char(40) NOT NULL,
  `table_name` char(50) NOT NULL,
  `column_name` char(60) NOT NULL,
  `prompt` char(50) NOT NULL,
  `drop_down_prompt` char(50) NOT NULL,
  `display_order` int DEFAULT NULL,
  `drop_down_multi_select_yn` char(1) DEFAULT NULL,
  `drillthru_yn` char(1) DEFAULT NULL,
  `populate_drop_down_process` char(40) DEFAULT NULL,
  `populate_helper_process` char(40) DEFAULT NULL,
  UNIQUE KEY `process_set_parameter` (`process_set`,`table_name`,`column_name`,`drop_down_prompt`,`prompt`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_set_parameter`
--

LOCK TABLES `process_set_parameter` WRITE;
/*!40000 ALTER TABLE `process_set_parameter` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_set_parameter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prompt`
--

DROP TABLE IF EXISTS `prompt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prompt` (
  `prompt` char(50) NOT NULL,
  `hint_message` text,
  `upload_filename_yn` char(1) DEFAULT NULL,
  `date_yn` char(1) DEFAULT NULL,
  `input_width` int DEFAULT NULL,
  UNIQUE KEY `prompt` (`prompt`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prompt`
--

LOCK TABLES `prompt` WRITE;
/*!40000 ALTER TABLE `prompt` DISABLE KEYS */;
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('delete_yn',NULL,NULL,NULL,1);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('destination_application','Enter in a mnemonic. Mnemonics begin with a lower case letter, have only lower case letters or numbers, and may contain underscores.',NULL,NULL,30);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('filename',NULL,'y',NULL,100);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('new_data',NULL,NULL,NULL,50);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('new_folder',NULL,NULL,NULL,50);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('null',NULL,NULL,NULL,0);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('old_data',NULL,NULL,NULL,50);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('name_of_bank','Enter the name of your bank, if it\'s not in the list above.',NULL,NULL,30);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('execute_yn','\'Yes\' will alter the database; otherwise, a hint message will display.',NULL,NULL,1);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('system_folders_yn',NULL,NULL,NULL,1);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('checking_begin_date','Enter the earliest checking account date from your bank\'s website.',NULL,'y',10);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('old_table',NULL,NULL,NULL,50);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('orphans_table',NULL,NULL,NULL,NULL);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('attribute',NULL,NULL,NULL,50);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('exclude_roles_yn',NULL,NULL,NULL,1);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('old_column',NULL,NULL,NULL,50);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('new_application_title',NULL,NULL,NULL,30);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('statement',NULL,NULL,NULL,2048);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('system_tables_yn',NULL,NULL,NULL,1);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('revoke_only_yn',NULL,NULL,NULL,1);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('line_count','How many lines from the end to include? Defaults to 50.',NULL,NULL,4);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('table_name',NULL,NULL,NULL,50);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('connect_from_host',NULL,NULL,NULL,60);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('appaserver_yn',NULL,NULL,NULL,1);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('column_name',NULL,NULL,NULL,60);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('checking_begin_balance','Enter the earliest checking account balance from your bank\'s website.',NULL,NULL,14);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('delete_application',NULL,NULL,NULL,30);
/*!40000 ALTER TABLE `prompt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relation`
--

DROP TABLE IF EXISTS `relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relation` (
  `table_name` char(50) NOT NULL,
  `related_table` char(50) NOT NULL,
  `related_column` char(60) NOT NULL,
  `pair_one2m_order` int DEFAULT NULL,
  `omit_drilldown_yn` char(1) DEFAULT NULL,
  `relation_type_isa_yn` char(1) DEFAULT NULL,
  `copy_common_columns_yn` char(1) DEFAULT NULL,
  `automatic_preselection_yn` char(1) DEFAULT NULL,
  `drop_down_multi_select_yn` char(1) DEFAULT NULL,
  `hint_message` text,
  `join_one2m_each_row_yn` char(1) DEFAULT NULL,
  `omit_drillthru_yn` char(1) DEFAULT NULL,
  `ajax_fill_drop_down_yn` char(1) DEFAULT NULL,
  `omit_ajax_fill_drop_down_yn` char(1) DEFAULT NULL,
  UNIQUE KEY `relation` (`table_name`,`related_table`,`related_column`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relation`
--

LOCK TABLES `relation` WRITE;
/*!40000 ALTER TABLE `relation` DISABLE KEYS */;
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('column','column_datatype','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('column_exclude','column','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('column_exclude','permission','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('column_exclude','role','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('drop_down_prompt_data','drop_down_prompt','null',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('table','process','post_change_process',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('table','process','populate_drop_down_process',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('table_column','column','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('table_column','table','null',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('table_operation','operation','null',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('table_row_level_restriction','table','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('table_row_level_restriction','row_level_restriction','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('operation','process','operation',NULL,NULL,'y',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_parameter','process','populate_drop_down_process',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_parameter','process','populate_helper_process',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_parameter','table','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_set_parameter','process_set','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_set_parameter','table','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_set_parameter','process','populate_helper_process',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_set_parameter','process','populate_drop_down_process',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('relation','column','related_column',NULL,NULL,NULL,NULL,NULL,NULL,'Normally, the foreign keys are the same names as their corresponding primary keys. Moreover, they are in the same order as their corresponding primary keys. Frequently, the last foreign key may differ. If only the last foreign key differs, then set related_column. Infrequently, the foreign keys are not in the same order, or multiple foreign key names differ. If so, then populate FOREIGN_COLUMN.',NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('relation','table','null',2,NULL,NULL,NULL,NULL,'n',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('relation','table','related_table',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('role_appaserver_user','appaserver_user','null',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('role_appaserver_user','role','null',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('role_table','table','null',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('role_table','permission','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('role_table','role','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('table_operation','table','null',4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('table_operation','role','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('role_process','process','null',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('role_process','role','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('role_process_set_member','process','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('role_process_set_member','role','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('role_process_set_member','process_set','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('application','date_format','user_date_format',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('appaserver_user','date_format','user_date_format',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('session','appaserver_user','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_parameter','process','null',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_set_parameter','column','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('table','appaserver_form','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process','process_group','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_set','process_group','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_parameter','prompt','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_set_parameter','prompt','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_parameter','drop_down_prompt','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_set_parameter','drop_down_prompt','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_parameter','column','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('row_security_role_update','table_column','column_not_null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('login_default_role','role_appaserver_user','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('select_statement','appaserver_user','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('foreign_column','relation','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('foreign_column','table_column','foreign_column',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('table','subschema','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_generic','process','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_generic','process_set','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_generic','process_generic_value','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_generic_value','column','value_column',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_generic_value','column','datatype_column',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_generic_value','column','date_column',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_generic_value','column','time_column',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_generic_value','table','value_table',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_generic_value','table','datatype_table',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('process_generic_value','table','foreign_table',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('self','entity','null',NULL,NULL,'y',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('financial_institution','vendor','null',NULL,NULL,'y',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('table','storage_engine','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`table_name`, `related_table`, `related_column`, `pair_one2m_order`, `omit_drilldown_yn`, `relation_type_isa_yn`, `copy_common_columns_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_one2m_each_row_yn`, `omit_drillthru_yn`, `ajax_fill_drop_down_yn`, `omit_ajax_fill_drop_down_yn`) VALUES ('vendor','entity','null',NULL,NULL,'y',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `role` char(25) NOT NULL,
  `table_count_yn` char(1) DEFAULT NULL,
  `override_row_restrictions_yn` char(1) DEFAULT NULL,
  UNIQUE KEY `role` (`role`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` (`role`, `table_count_yn`, `override_row_restrictions_yn`) VALUES ('system','y','y');
INSERT INTO `role` (`role`, `table_count_yn`, `override_row_restrictions_yn`) VALUES ('supervisor','y','y');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_appaserver_user`
--

DROP TABLE IF EXISTS `role_appaserver_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_appaserver_user` (
  `role` char(25) NOT NULL,
  `login_name` char(50) NOT NULL,
  UNIQUE KEY `role_appaserver_user` (`login_name`,`role`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_appaserver_user`
--

LOCK TABLES `role_appaserver_user` WRITE;
/*!40000 ALTER TABLE `role_appaserver_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_appaserver_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_process`
--

DROP TABLE IF EXISTS `role_process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_process` (
  `role` char(25) NOT NULL,
  `process` char(40) NOT NULL,
  UNIQUE KEY `role_process` (`role`,`process`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_process`
--

LOCK TABLES `role_process` WRITE;
/*!40000 ALTER TABLE `role_process` DISABLE KEYS */;
INSERT INTO `role_process` (`role`, `process`) VALUES ('supervisor','appaserver_info');
INSERT INTO `role_process` (`role`, `process`) VALUES ('supervisor','change_password');
INSERT INTO `role_process` (`role`, `process`) VALUES ('supervisor','execute_select_statement');
INSERT INTO `role_process` (`role`, `process`) VALUES ('supervisor','import_predictBooks');
INSERT INTO `role_process` (`role`, `process`) VALUES ('supervisor','merge_purge');
INSERT INTO `role_process` (`role`, `process`) VALUES ('supervisor','view_documentation');
INSERT INTO `role_process` (`role`, `process`) VALUES ('supervisor','view_source');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','add_column');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','alter_column_datatype');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','appaserver_info');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','change_password');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','clone_table');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','create_application');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','create_empty_application');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','create_table');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','delete_application');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','drop_column');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','drop_table');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','execute_select_statement');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','export_application');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','export_process');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','export_process_set');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','export_subschema');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','export_table');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','fix_orphans');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','generic_load');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','grant_select_to_user');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','graphviz_database_schema');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','import_predictBooks');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','merge_purge');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','rename_column');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','rename_table');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','table_rectification');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','upload_source_file');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','view_appaserver_log_file');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','view_documentation');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','view_source');
/*!40000 ALTER TABLE `role_process` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_process_set_member`
--

DROP TABLE IF EXISTS `role_process_set_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_process_set_member` (
  `process` char(40) NOT NULL,
  `process_set` char(40) NOT NULL,
  `role` char(25) NOT NULL,
  UNIQUE KEY `role_process_set_member` (`process`,`process_set`,`role`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_process_set_member`
--

LOCK TABLES `role_process_set_member` WRITE;
/*!40000 ALTER TABLE `role_process_set_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_process_set_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_table`
--

DROP TABLE IF EXISTS `role_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_table` (
  `table_name` char(50) NOT NULL,
  `role` char(25) NOT NULL,
  `permission` char(10) NOT NULL,
  UNIQUE KEY `role_table` (`role`,`table_name`,`permission`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_table`
--

LOCK TABLES `role_table` WRITE;
/*!40000 ALTER TABLE `role_table` DISABLE KEYS */;
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('appaserver_user','supervisor','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('entity','supervisor','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('entity','supervisor','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('financial_institution','supervisor','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('financial_institution','supervisor','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('select_statement','supervisor','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('select_statement','supervisor','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('self','supervisor','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('self','supervisor','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('vendor','supervisor','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('vendor','supervisor','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('appaserver_form','system','lookup');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('appaserver_user','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('appaserver_user','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('application','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('application','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('application_constant','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('application_constant','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('column','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('column','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('column_datatype','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('column_datatype','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('column_exclude','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('column_exclude','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('date_format','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('date_format','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('drop_down_prompt','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('drop_down_prompt','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('drop_down_prompt_data','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('drop_down_prompt_data','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('foreign_column','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('foreign_column','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('login_default_role','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('login_default_role','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('operation','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('operation','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('permission','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('permission','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('process','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('process','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('process_generic','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('process_generic','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('process_generic_value','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('process_generic_value','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('process_group','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('process_group','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('process_parameter','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('process_parameter','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('process_set','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('process_set','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('process_set_parameter','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('process_set_parameter','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('prompt','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('prompt','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('relation','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('relation','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('role','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('role','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('role_appaserver_user','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('role_appaserver_user','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('role_process','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('role_process','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('role_process_set_member','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('role_process_set_member','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('role_table','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('role_table','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('row_level_restriction','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('row_level_restriction','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('row_security_role_update','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('row_security_role_update','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('select_statement','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('select_statement','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('session','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('session','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('storage_engine','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('storage_engine','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('subschema','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('subschema','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('table','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('table','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('table_column','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('table_column','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('table_operation','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('table_operation','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('table_row_level_restriction','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('table_row_level_restriction','system','update');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('upgrade_script','system','insert');
INSERT INTO `role_table` (`table_name`, `role`, `permission`) VALUES ('upgrade_script','system','update');
/*!40000 ALTER TABLE `role_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `row_level_restriction`
--

DROP TABLE IF EXISTS `row_level_restriction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `row_level_restriction` (
  `row_level_restriction` char(30) NOT NULL,
  UNIQUE KEY `row_level_restriction` (`row_level_restriction`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `row_level_restriction`
--

LOCK TABLES `row_level_restriction` WRITE;
/*!40000 ALTER TABLE `row_level_restriction` DISABLE KEYS */;
INSERT INTO `row_level_restriction` (`row_level_restriction`) VALUES ('row_level_non_owner_forbid');
INSERT INTO `row_level_restriction` (`row_level_restriction`) VALUES ('row_level_non_owner_view_only');
/*!40000 ALTER TABLE `row_level_restriction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `row_security_role_update`
--

DROP TABLE IF EXISTS `row_security_role_update`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `row_security_role_update` (
  `table_name` char(50) NOT NULL,
  `column_not_null` char(60) DEFAULT NULL,
  UNIQUE KEY `row_security_role_update` (`table_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `row_security_role_update`
--

LOCK TABLES `row_security_role_update` WRITE;
/*!40000 ALTER TABLE `row_security_role_update` DISABLE KEYS */;
/*!40000 ALTER TABLE `row_security_role_update` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `select_statement`
--

DROP TABLE IF EXISTS `select_statement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `select_statement` (
  `select_statement_title` char(80) NOT NULL,
  `login_name` char(50) NOT NULL,
  `select_statement` text,
  UNIQUE KEY `select_statement` (`select_statement_title`,`login_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `select_statement`
--

LOCK TABLES `select_statement` WRITE;
/*!40000 ALTER TABLE `select_statement` DISABLE KEYS */;
/*!40000 ALTER TABLE `select_statement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `self`
--

DROP TABLE IF EXISTS `self`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `self` (
  `full_name` char(60) NOT NULL,
  `street_address` char(60) NOT NULL,
  `credit_card_number` char(20) DEFAULT NULL,
  `credit_card_expiration_month_year` char(4) DEFAULT NULL,
  `credit_card_security_code` char(3) DEFAULT NULL,
  `credit_provider` char(30) DEFAULT NULL,
  `credit_provider_not_supported_yn` char(1) DEFAULT NULL,
  `invoice_amount_due` double(10,2) DEFAULT NULL,
  `invoice_statement_current` char(50) DEFAULT NULL,
  UNIQUE KEY `self` (`full_name`,`street_address`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `self`
--

LOCK TABLES `self` WRITE;
/*!40000 ALTER TABLE `self` DISABLE KEYS */;
INSERT INTO `self` (`full_name`, `street_address`, `credit_card_number`, `credit_card_expiration_month_year`, `credit_card_security_code`, `credit_provider`, `credit_provider_not_supported_yn`, `invoice_amount_due`, `invoice_statement_current`) VALUES ('Set Me','1234 Set Me',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `self` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `session` (
  `session` char(10) NOT NULL,
  `login_name` char(50) DEFAULT NULL,
  `login_date` date DEFAULT NULL,
  `login_time` char(4) DEFAULT NULL,
  `last_access_date` date DEFAULT NULL,
  `last_access_time` char(4) DEFAULT NULL,
  `http_user_agent` char(80) DEFAULT NULL,
  `remote_ip_address` char(15) DEFAULT NULL,
  UNIQUE KEY `session` (`session`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storage_engine`
--

DROP TABLE IF EXISTS `storage_engine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `storage_engine` (
  `storage_engine` char(10) NOT NULL,
  UNIQUE KEY `storage_engine` (`storage_engine`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storage_engine`
--

LOCK TABLES `storage_engine` WRITE;
/*!40000 ALTER TABLE `storage_engine` DISABLE KEYS */;
INSERT INTO `storage_engine` (`storage_engine`) VALUES ('Federated');
INSERT INTO `storage_engine` (`storage_engine`) VALUES ('InnoDB');
INSERT INTO `storage_engine` (`storage_engine`) VALUES ('memory');
INSERT INTO `storage_engine` (`storage_engine`) VALUES ('MyISAM');
INSERT INTO `storage_engine` (`storage_engine`) VALUES ('NDB');
/*!40000 ALTER TABLE `storage_engine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subschema`
--

DROP TABLE IF EXISTS `subschema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subschema` (
  `subschema` char(30) NOT NULL,
  UNIQUE KEY `subschema` (`subschema`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subschema`
--

LOCK TABLES `subschema` WRITE;
/*!40000 ALTER TABLE `subschema` DISABLE KEYS */;
INSERT INTO `subschema` (`subschema`) VALUES ('activity');
INSERT INTO `subschema` (`subschema`) VALUES ('application');
INSERT INTO `subschema` (`subschema`) VALUES ('entity');
INSERT INTO `subschema` (`subschema`) VALUES ('ethernet');
INSERT INTO `subschema` (`subschema`) VALUES ('operation');
INSERT INTO `subschema` (`subschema`) VALUES ('process');
INSERT INTO `subschema` (`subschema`) VALUES ('process_generic');
INSERT INTO `subschema` (`subschema`) VALUES ('process_set');
INSERT INTO `subschema` (`subschema`) VALUES ('schema');
INSERT INTO `subschema` (`subschema`) VALUES ('security');
INSERT INTO `subschema` (`subschema`) VALUES ('static');
/*!40000 ALTER TABLE `subschema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `table_column`
--

DROP TABLE IF EXISTS `table_column`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `table_column` (
  `table_name` char(50) NOT NULL,
  `column_name` char(60) NOT NULL,
  `primary_key_index` int DEFAULT NULL,
  `display_order` int DEFAULT NULL,
  `omit_insert_prompt_yn` char(1) DEFAULT NULL,
  `omit_insert_yn` char(1) DEFAULT NULL,
  `additional_unique_index_yn` char(1) DEFAULT NULL,
  `additional_index_yn` char(1) DEFAULT NULL,
  `lookup_required_yn` char(1) DEFAULT NULL,
  `insert_required_yn` char(1) DEFAULT NULL,
  `omit_update_yn` char(1) DEFAULT NULL,
  `default_value` char(10) DEFAULT NULL,
  UNIQUE KEY `table_column` (`table_name`,`column_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `table_column`
--

LOCK TABLES `table_column` WRITE;
/*!40000 ALTER TABLE `table_column` DISABLE KEYS */;
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('permission','permission',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('role_table','permission',3,NULL,'y',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('date_format','date_format',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table','populate_drop_down_process',NULL,6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('column','column_name',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table_column','column_name',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_parameter','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'null');
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_set_parameter','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'null');
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('column','column_datatype',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('column_datatype','column_datatype',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process','command_line',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('column','float_decimal_places',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table_column','display_order',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_parameter','process',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_set_parameter','process_set',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_parameter','drillthru_yn',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_set_parameter','drillthru_yn',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('drop_down_prompt','drop_down_prompt',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('drop_down_prompt_data','drop_down_prompt',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_parameter','populate_drop_down_process',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_set_parameter','populate_drop_down_process',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('drop_down_prompt_data','drop_down_prompt_data',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('application','application',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table','no_initial_capital_yn',NULL,12,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table_column','table_name',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_parameter','drop_down_prompt',4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'null');
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_set_parameter','drop_down_prompt',4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'null');
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('relation','table_name',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('role_table','table_name',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table_operation','table_name',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('role','table_count_yn',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('relation','pair_one2m_order',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table','notepad',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('appaserver_form','appaserver_form',1,NULL,NULL,'n',NULL,NULL,NULL,NULL,'n',NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('column','hint_message',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('drop_down_prompt','hint_message',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('prompt','hint_message',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('prompt','input_width',NULL,9,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table','insert_rows_number',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('appaserver_user','login_name',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('role_appaserver_user','login_name',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('session','login_name',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('relation','ajax_fill_drop_down_yn',0,9,'n','n',NULL,NULL,NULL,NULL,'n',NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table','html_help_file_anchor',NULL,16,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('application','next_session_number',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('null','null',0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table','drillthru_yn',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('operation','operation',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table_operation','operation',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('operation','output_yn',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('prompt','upload_filename_yn',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('appaserver_user','password',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table','exclude_application_export_yn',NULL,11,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table_column','primary_key_index',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process','process',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_parameter','display_order',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('role_process','process',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('role_process_set_member','process',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_set','process_set',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_set_parameter','display_order',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('role_process_set_member','process_set',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_parameter','column_name',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'null');
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_set_parameter','column_name',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'null');
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('prompt','prompt',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('relation','related_column',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'null');
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('relation','related_table',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('role','role',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('role_table','role',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table_operation','role',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('role_appaserver_user','role',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('role_process','role',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('role_process_set_member','role',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('session','session',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table','subschema',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('column','width',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('application','application_title',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('appaserver_user','person_full_name',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('application','relative_source_directory',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('application','next_reference_number',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('application','background_color',NULL,6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table','data_directory',0,13,'n','n',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('column_exclude','column_name',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('relation','omit_drilldown_yn',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('relation','relation_type_isa_yn',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('appaserver_user','deactivated_yn',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('column_exclude','role',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table_row_level_restriction','row_level_restriction',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('application','grace_execution_directory',NULL,10,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table_row_level_restriction','table_name',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process','preprompt_help_text',NULL,7,'n','n',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('column_exclude','permission',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table_column','omit_insert_yn',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('drop_down_prompt_data','display_order',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('drop_down_prompt','optional_display',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process','notepad',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_set','notepad',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table','appaserver_form',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('session','last_access_date',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('session','last_access_time',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('application','grace_home_directory',NULL,9,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_set','prompt_display_text',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_set','prompt_display_bottom_yn',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_set','html_help_file_anchor',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process','html_help_file_anchor',NULL,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table','create_view_statement',0,15,'n','n','n','n','n','n','n',NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table_column','insert_required_yn',NULL,9,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('relation','copy_common_columns_yn',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table_column','additional_unique_index_yn',NULL,6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table_column','additional_index_yn',NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('application','ssl_support_yn',NULL,13,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('application','max_drop_down_size',NULL,13,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process','execution_count',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('relation','automatic_preselection_yn',NULL,6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('role','override_row_restrictions_yn',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('row_level_restriction','row_level_restriction',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table_column','omit_insert_prompt_yn',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process','post_change_javascript',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_set','post_change_javascript',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_parameter','drop_down_multi_select_yn',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_set_parameter','drop_down_multi_select_yn',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('application','user_date_format',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('appaserver_user','user_date_format',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('prompt','date_yn',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table_column','lookup_required_yn',NULL,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('session','http_user_agent',NULL,6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_set','preprompt_help_text',0,8,'n','n',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process','process_set_display',NULL,9,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('session','remote_ip_address',NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('session','login_date',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('session','login_time',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_parameter','table_name',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'null');
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_set_parameter','table_name',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'null');
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('application','max_query_rows_for_drop_downs',NULL,14,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('application_constant','application_constant',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('application_constant','application_constant_value',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('relation','hint_message',0,12,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('relation','drop_down_multi_select_yn',0,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table','index_directory',0,14,'n','n',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('relation','join_one2m_each_row_yn',NULL,8,'n','n',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process','javascript_filename',NULL,6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_set','javascript_filename',NULL,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('relation','omit_drillthru_yn',0,2,'n','n',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('subschema','subschema',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_group','process_group',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process','process_group',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_set','process_group',NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('application','menu_horizontal_yn',NULL,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('upgrade_script','upgrade_script',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('upgrade_script','appaserver_version',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table','table_name',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_parameter','populate_helper_process',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_set_parameter','populate_helper_process',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('row_security_role_update','column_not_null',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('row_security_role_update','table_name',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table','post_change_javascript',NULL,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('login_default_role','login_name',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('login_default_role','role',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table_column','omit_update_yn',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('select_statement','login_name',2,NULL,NULL,'y',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('select_statement','select_statement',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('select_statement','select_statement_title',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('foreign_column','table_name',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('foreign_column','foreign_column',4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('foreign_column','foreign_key_index',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('foreign_column','related_column',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('foreign_column','related_table',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table','post_change_process',NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table','javascript_filename',NULL,9,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table_column','default_value',NULL,10,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('entity','cell_phone_number',NULL,6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('entity','city',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('entity','email_address',NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('entity','full_name',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('entity','notepad',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('entity','land_phone_number',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('entity','state_code',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('entity','street_address',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'null');
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('entity','zip_code',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_generic','process',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_generic','process_set',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_generic','value_column',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_generic','value_table',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_generic_value','datatype_aggregation_sum_yn',NULL,6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_generic_value','datatype_column',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_generic_value','datatype_bar_graph_yn',NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_generic_value','datatype_table',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_generic_value','datatype_scale_graph_zero_yn',NULL,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_generic_value','datatype_units_yn',NULL,9,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_generic_value','date_column',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_generic_value','foreign_table',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_generic_value','foreign_units_yn',NULL,10,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_generic_value','time_column',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_generic_value','value_column',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('process_generic_value','value_table',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('self','street_address',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('self','invoice_statement_current',NULL,6,NULL,'y',NULL,NULL,NULL,NULL,'y',NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('self','invoice_amount_due',NULL,5,NULL,'y',NULL,NULL,NULL,NULL,'y',NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('self','full_name',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('self','credit_card_number',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('self','credit_provider',NULL,4,NULL,'y',NULL,NULL,NULL,NULL,'y',NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('self','credit_card_security_code',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('self','credit_card_expiration_month_year',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('financial_institution','full_name',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('financial_institution','street_address',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'unknown');
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('table','storage_engine',NULL,10,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('storage_engine','storage_engine',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('vendor','full_name',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('vendor','street_address',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'unknown');
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('vendor','website_address',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('vendor','website_login',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `table_column` (`table_name`, `column_name`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`, `default_value`) VALUES ('vendor','website_password',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `table_column` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `table_operation`
--

DROP TABLE IF EXISTS `table_operation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `table_operation` (
  `table_name` char(50) NOT NULL,
  `role` char(25) NOT NULL,
  `operation` char(30) NOT NULL,
  UNIQUE KEY `table_operation` (`table_name`,`role`,`operation`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `table_operation`
--

LOCK TABLES `table_operation` WRITE;
/*!40000 ALTER TABLE `table_operation` DISABLE KEYS */;
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('appaserver_form','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('appaserver_user','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('appaserver_user','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('application','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('application_constant','supervisor','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('application_constant','supervisor','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('application_constant','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('column','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('column','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('column_exclude','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('date_format','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('date_format','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('drop_down_prompt','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('drop_down_prompt','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('drop_down_prompt_data','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('drop_down_prompt_data','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('entity','supervisor','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('entity','supervisor','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('financial_institution','supervisor','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('financial_institution','supervisor','delete_isa_only');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('financial_institution','supervisor','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('foreign_column','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('foreign_column','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('login_default_role','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('login_default_role','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('operation','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('operation','system','delete_isa_only');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('operation','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('permission','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('process','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('process','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('process_generic','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('process_generic','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('process_generic_value','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('process_generic_value','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('process_group','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('process_group','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('process_parameter','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('process_parameter','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('process_set','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('process_set','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('process_set_parameter','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('process_set_parameter','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('prompt','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('prompt','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('relation','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('relation','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('role','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('role','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('role_appaserver_user','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('role_process','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('role_process_set_member','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('role_process_set_member','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('role_table','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('row_level_restriction','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('row_security_role_update','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('row_security_role_update','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('select_statement','supervisor','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('self','supervisor','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('self','supervisor','delete_isa_only');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('self','supervisor','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('session','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('session','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('storage_engine','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('storage_engine','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('subschema','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('subschema','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('table','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('table','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('table_column','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('table_column','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('table_operation','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('table_row_level_restriction','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('table_row_level_restriction','system','drilldown');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('upgrade_script','system','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('vendor','supervisor','delete');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('vendor','supervisor','delete_isa_only');
INSERT INTO `table_operation` (`table_name`, `role`, `operation`) VALUES ('vendor','supervisor','drilldown');
/*!40000 ALTER TABLE `table_operation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `table_row_level_restriction`
--

DROP TABLE IF EXISTS `table_row_level_restriction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `table_row_level_restriction` (
  `table_name` char(50) NOT NULL,
  `row_level_restriction` char(30) DEFAULT NULL,
  UNIQUE KEY `table_row_level_restriction` (`table_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `table_row_level_restriction`
--

LOCK TABLES `table_row_level_restriction` WRITE;
/*!40000 ALTER TABLE `table_row_level_restriction` DISABLE KEYS */;
INSERT INTO `table_row_level_restriction` (`table_name`, `row_level_restriction`) VALUES ('appaserver_user','row_level_non_owner_forbid');
/*!40000 ALTER TABLE `table_row_level_restriction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `upgrade_script`
--

DROP TABLE IF EXISTS `upgrade_script`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `upgrade_script` (
  `appaserver_version` char(10) NOT NULL,
  `upgrade_script` char(80) NOT NULL,
  UNIQUE KEY `upgrade_script` (`appaserver_version`,`upgrade_script`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `upgrade_script`
--

LOCK TABLES `upgrade_script` WRITE;
/*!40000 ALTER TABLE `upgrade_script` DISABLE KEYS */;
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.1','02rename_subschemas.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.1','03restructure_folder_javascript_filename.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.1','04restructure_process_javascript_filename.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.1','05restructure_javascript_files.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.1','06restructure_javascript_subschema.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.10','01drop_old_process_generic.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.10','add_folder_attribute_default_value.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.10','create_ethernet_device_template.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.10','create_table_entity.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.10','create_table_process_generic.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.10','create_table_process_generic_value.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.10','fix_cost_recovery.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.10','fix_fixed_asset_purchase.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.10','rebuild_process_generic.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.10','recreate_index_account_balance.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.10','set_notepad_datatype_text.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.10','set_street_address_width.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.10','set_work_hours_width.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.11','01rename_application.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.11','02rename_folder.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.11','03rename_attribute.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.11','04rename_folder_attribute.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.11','05rename_foreign_attribute.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.11','06rename_attribute_datatype.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.11','07rename_role_folder.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.11','08rename_attribute_exclude.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.11','09rename_row_security_role_update.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.11','10rename_relation.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.11','11rename_folder_row_level_restriction.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.11','12rename_process_parameter.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.11','13rename_process_set_parameter.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.11','14rename_folder_operation.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.11','15rename_process_generic.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.11','16rename_process_generic_value.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.11','17rename_folder_count_yn.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.11','18rename_copy_common_attributes_yn.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.12','create_table_self.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.12','delete_unused_drop_down_prompt.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.12','delete_unused_prompt.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.12','insert_entity_self_subschema.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.12','insert_process_drop_column.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.12','insert_process_drop_table.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.12','reinsert_process_execute_select_statement.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.12','reinsert_process_export_application.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.12','reinsert_process_export_process.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.12','reinsert_process_export_process_set.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.12','reinsert_process_export_subschema.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.12','reinsert_process_export_table.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.12','reinsert_process_rename_column.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.12','reinsert_process_rename_table.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.12','rename_entity_phone_number.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.12','update_process_fix_orphans.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.12','update_process_view_appaserver_error.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.12','update_relation_hint_messages.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.12','update_table_foreign_column_notepad.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.13','add_column_relation_omit_ajax_fill_drop_down_yn.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.13','add_column_relation_trigger_insert_update_yn.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.13','create_table_financial_institution.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.13','insert_process_import_predictbooks.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.13','insert_table_column_ajax_fill_drop_down.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.13','reinsert_predictbooks_populate_account.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.13','update_relation_display_order.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.14','add_column_table_storage_engine.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.14','alter_table_session_storage_engine.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.14','create_table_storage_engine.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.14','insert_schema_storage_engine.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.14','insert_table_storage_engine.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.15','recreate_index_transaction.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.15','recreate_primary_index_transaction.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.15','reinsert_process_account_balance.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.15','reinsert_process_budget_report.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.15','rename_table_form.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.16','1create_table_vendor.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.16','2insert_subschema_vendor.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.16','3insert_rows_vendor.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.16','4drop_column_entity_website_address.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.16','5drop_column_entity_website_login.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.16','6drop_column_entity_website_password.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.17','add_columns_to_self.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.17','insert_process_self_trigger.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.17','reinsert_process_insert_cash_expense_transaction.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.17','reinsert_subschema_self.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.17','rename_datatype_text.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.18','remove_insert_update_yn.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.18','remove_omit_ajax_fill_drop_down.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','01create_cost_recovery.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','01create_cost_recovery_conversion.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','01create_cost_recovery_method.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','01create_cost_recovery_period.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','01create_depreciation.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','01create_depreciation_method.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','01create_fixed_asset.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','01create_fixed_asset_purchase.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','01create_vendor.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','01insert_cost_recovery_conversion.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','01insert_cost_recovery_method.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','01insert_cost_recovery_period.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','01insert_depreciation_method.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','01insert_fixed_asset_subschema.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','1create_account_balance.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','1create_financial_institution.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','1create_investment_account.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','1create_investment_classification.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','1create_investment_purpose.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','1create_liability_account_entity.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','1insert_appaserver_user_trigger.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','1insert_investment_classification.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','1insert_investment_purpose.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','1insert_subschema_investment.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','1insert_subschema_liability_account_entity.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','2insert_investment_classification.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','2insert_investment_purpose.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.2','alter_password_column.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.3','1create_feeder_phrase.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.3','1creel_day_of_week.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.3','1insert_subschema_feeder_phrase.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.3','1update_reoccurring_transaction_subschema.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.3','2creel_update_day_of_week_process.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.3','2insert_feeder_phrase.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.3','3delete_reoccurring_transaction.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.3','4delete_donner_role.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.3','4drop_bank_upload_transaction.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.3','4drop_reoccurring_transaction_feeder_phrase.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.3','4drop_transaction_count.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.3','5create_feeder_account.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.3','7rename_feeder_row.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.3','hydrology_cubic_feet_per_second.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.4','1delete_feeder_row.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.4','change_feeder_load_usage.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.4','insert_budget_report.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.4','predictive_insert_financial.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.4','predictive_tax_form_report.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.4','reinsert_close_nominal_accounts.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.4','reinsert_generic_load.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.4','remove_appaserver_yn.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.4','rename_lookup_drillthru.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.4','rename_preprompt_drillthru.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.5','1restructure_application.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.5','1restructure_relation.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.5','2drop_grace_output.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.5','reinsert_change_password_process.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.5','rename_date_format.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.6','insert_delete_application.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.6','rename_detail_to_drilldown.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.6','rename_process_groups.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.6','restructure_application_constants.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.6','set_relative_source_directory_src_system.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.6','update_create_empty_application_command_line.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.6','update_empty_process_group_to_manipulate.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.6','update_export_process_command_line.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.6','update_export_process_set_command_line.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.6','update_export_subschema_command_line.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.6','update_grant_select_command_line.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.6','update_merge_purge_command_line.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.6','update_process_delete_command_line.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.6','update_process_group_administer.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.6','update_process_rectification_command_line.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.6','update_process_rename_column_command_line.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.6','update_process_rename_table_command_line.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.7','rename_role_operation.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.7','update_attribute_datatype.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.7','update_feeder_load_event_filename.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.8','add_appaserver_user_deactivated.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.8','alter_feeder_load_date_time.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.8','rename_appaserver_sessions.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.8','rename_folder_row_level_restrictions.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.8','rename_permissions.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.8','rename_row_level_restrictions.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','add_date_formats.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','change_password_datatype.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','change_website_password_datatype.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','delete_attribute_datatype_hidden.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','drop_unused_attributes.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','reindex_role_appaserver_user.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','rename_export_folder.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','rename_journal_ledger.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','rename_subschema_process_generic_output.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','update_add_column_command_line.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','update_alter_column_datatype_command_line.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','update_appaserver_info_command_line.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','update_appaserver_user_trigger.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','update_clone_folder_command_line.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','update_closing_entry_memo.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','update_create_application_command_line.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','update_create_table_command_line.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','update_export_application_command_line.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','update_fix_orphans_command_line.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','update_graphviz_process_group.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','update_investment_account_balance.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','update_ledger_propagate_command_line.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','update_view_diagrams_command_line.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','update_view_error_command_line.sh');
INSERT INTO `upgrade_script` (`appaserver_version`, `upgrade_script`) VALUES ('0.9','update_view_source_command_line.sh');
/*!40000 ALTER TABLE `upgrade_script` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendor`
--

DROP TABLE IF EXISTS `vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vendor` (
  `full_name` char(60) NOT NULL,
  `street_address` char(60) NOT NULL,
  `website_address` char(50) DEFAULT NULL,
  `website_login` char(50) DEFAULT NULL,
  `website_password` char(20) DEFAULT NULL,
  UNIQUE KEY `vendor_unique` (`full_name`,`street_address`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendor`
--

LOCK TABLES `vendor` WRITE;
/*!40000 ALTER TABLE `vendor` DISABLE KEYS */;
INSERT INTO `vendor` (`full_name`, `street_address`, `website_address`, `website_login`, `website_password`) VALUES ('bank_of_america','100 North Tryon Street',NULL,NULL,NULL);
INSERT INTO `vendor` (`full_name`, `street_address`, `website_address`, `website_login`, `website_password`) VALUES ('JP_morgan_chase','270 Park Avenue',NULL,NULL,NULL);
/*!40000 ALTER TABLE `vendor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-09 16:39:16
