-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: home
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.22.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account` (
  `account` char(60) NOT NULL,
  `subclassification` char(35) DEFAULT NULL,
  `hard_coded_account_key` char(40) DEFAULT NULL,
  `annual_budget` int DEFAULT NULL,
  UNIQUE KEY `account` (`account`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('account_payable','current_liability','account_payable_key',NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('net_asset','net_asset','equity_key',NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('loss','loss','loss_key',NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('repairs','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Interest','revenue',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Gift','entertainment',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('uncleared_checks','current_liability','uncleared_checks',NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('investment','cash_or_equivalent','investment',NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('mortgage','long-term liability',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('investment_decrease','loss','investment_loss',NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Groceries','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Healthcare premium','Medical',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Healthcare consumption','Medical',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Phone/Internet/TV','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Electricity','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('fuel/snacks','transportation',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Medication','Medical',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Alarm','Home',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Garbage/Water','Home',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Sewage','Home',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Car Insurance','transportation',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Home Insurance','Home',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Flood Insurance','Home',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Restaurant/Takeout/Delivery','entertainment',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('car registration/driver license','transportation',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('plumbing_services','Home',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('property_tax','Home',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('donation_cash','donation',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('donation_property','donation',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('alarm_permit','Home',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Error gain','gain',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Error loss','loss',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Natural gas','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Miscellaneous expense','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('house','fixed_asset',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('vehicle','fixed_asset',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('car_maintenance','transportation',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('income_tax','tax_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('grooming','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('unclassified_entertainment','entertainment',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('clothing','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('pet','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('cash_withdrawal','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('computers/electronics','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('big_box_expense','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('car_parking','transportation',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Shoes','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('show','entertainment',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('house_maintenance','Home',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('public_transportation','transportation',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('utilities','Home',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Concerts','entertainment',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Travel','entertainment',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Dental','Medical',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('news','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('bank_fees','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Eyecare','Medical',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('gain','gain',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('amazon expense','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Exercise','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Postage','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('tolls','transportation',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('investment_increase','gain','investment_gain',NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('drycleaning','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('salary/wage','revenue',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('fixed_asset','fixed_asset',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('credit_card_passthru','net_asset','credit_card_passthru',NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('pharmacy','Medical',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('appliance','Home',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('donation_political','donation',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('petty_cash','cash_or_equivalent',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('IRA_tax_payable','current_liability','IRA_tax_payable',NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('office','operating_expense',NULL,NULL);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_balance`
--

DROP TABLE IF EXISTS `account_balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_balance` (
  `full_name` char(60) NOT NULL,
  `account_number` char(50) NOT NULL,
  `date` date NOT NULL,
  `balance` double(11,2) DEFAULT NULL,
  `balance_change` double(11,2) DEFAULT NULL,
  `balance_change_percent` int DEFAULT NULL,
  UNIQUE KEY `account_balance_unique` (`full_name`,`account_number`,`date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_balance`
--

LOCK TABLES `account_balance` WRITE;
/*!40000 ALTER TABLE `account_balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `element`
--

DROP TABLE IF EXISTS `element`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `element` (
  `element` char(20) NOT NULL,
  `accumulate_debit_yn` char(1) DEFAULT NULL,
  UNIQUE KEY `element` (`element`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `element`
--

LOCK TABLES `element` WRITE;
/*!40000 ALTER TABLE `element` DISABLE KEYS */;
INSERT INTO `element` (`element`, `accumulate_debit_yn`) VALUES ('asset','y');
INSERT INTO `element` (`element`, `accumulate_debit_yn`) VALUES ('equity','n');
INSERT INTO `element` (`element`, `accumulate_debit_yn`) VALUES ('expense','y');
INSERT INTO `element` (`element`, `accumulate_debit_yn`) VALUES ('gain','n');
INSERT INTO `element` (`element`, `accumulate_debit_yn`) VALUES ('liability','n');
INSERT INTO `element` (`element`, `accumulate_debit_yn`) VALUES ('loss','y');
INSERT INTO `element` (`element`, `accumulate_debit_yn`) VALUES ('revenue','n');
/*!40000 ALTER TABLE `element` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feeder_account`
--

DROP TABLE IF EXISTS `feeder_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feeder_account` (
  `feeder_account` char(30) NOT NULL,
  `full_name` char(60) DEFAULT NULL,
  UNIQUE KEY `feeder_account_unique` (`feeder_account`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feeder_account`
--

LOCK TABLES `feeder_account` WRITE;
/*!40000 ALTER TABLE `feeder_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `feeder_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feeder_load_event`
--

DROP TABLE IF EXISTS `feeder_load_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feeder_load_event` (
  `feeder_account` char(30) NOT NULL,
  `feeder_load_date_time` char(19) NOT NULL,
  `feeder_load_filename` char(80) DEFAULT NULL,
  `account_end_date` char(10) DEFAULT NULL,
  `account_end_balance` double(12,2) DEFAULT NULL,
  `appaserver_full_name` char(60) DEFAULT NULL,
  UNIQUE KEY `feeder_load_event_unique` (`feeder_account`,`feeder_load_date_time`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feeder_load_event`
--

LOCK TABLES `feeder_load_event` WRITE;
/*!40000 ALTER TABLE `feeder_load_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `feeder_load_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feeder_phrase`
--

DROP TABLE IF EXISTS `feeder_phrase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feeder_phrase` (
  `feeder_phrase` char(80) NOT NULL,
  `nominal_account` char(60) DEFAULT NULL,
  `full_name` char(60) DEFAULT NULL,
  UNIQUE KEY `feeder_phrase_unique` (`feeder_phrase`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feeder_phrase`
--

LOCK TABLES `feeder_phrase` WRITE;
/*!40000 ALTER TABLE `feeder_phrase` DISABLE KEYS */;
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('HOME DEPOT','house_maintenance','Home Depot');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('KAISER HPS','Healthcare premium','Kaiser');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('ADT','Alarm','ADT');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('SAFEWAY STORE','Groceries','Safeway Supermarket');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('SHELL Service|SHELL OIL','fuel/snacks','Shell Service');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('BEL AIR|RALEY','Groceries','Raley\'s Bel Air');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('LIBERTY MUTUAL DES','Car Insurance','Liberty Mutual Group');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('PACIFIC GAS','Natural gas','PG&E');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('TARGET','big_box_expense','Target');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('JIFFY LUBE','car_maintenance','Jiffy Lube');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('CHEVRON','fuel/snacks','Chevron');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('SUPERCUTS','grooming','Supercuts');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('ARCO','fuel/snacks','Arco');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('SAFEWAY FUEL','fuel/snacks','Safeway Gas Station');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('WENDY\'S','Restaurant/Takeout/Delivery','Wendy\'s Restaurant');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('CVS','pharmacy','CVS');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('BEST BUY|BESTBUY','computers/electronics','Best Buy');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('STARBUCKS','Restaurant/Takeout/Delivery','Starbucks');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('PEPBOYS','car_maintenance','Pepboy\'s Store');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('WALGREENS','Groceries','Walgreens');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('7-ELEVEN','fuel/snacks','7-Eleven');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('WAL-MART|WM SUPERCENTER','big_box_expense','Wal Mart');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('UPS STORE','Postage','UPS Store');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('CARLS JR','Restaurant/Takeout/Delivery','CARLS JR');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('UNITED','Travel','United Airlines');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('AT&T PREPAID|ATT DES|ATT*BILL PAYMENT','Phone/Internet/TV','AT&T');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('AMAZON.COM|AMZN','amazon expense','Amazon');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('JAMBA JUICE','Restaurant/Takeout/Delivery','Jamba Juice');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('Speedway','fuel/snacks','Speedway');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('KAISER ONLINE PAY','Healthcare consumption','Kaiser');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('lowes|lowe\'s','house_maintenance','Lowe\'s Home Improvement');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('KAISER PHARM','Healthcare consumption','Kaiser');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('TACO BELL','Restaurant/Takeout/Delivery','Taco Bell');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('interest','Interest','Financial Institution Full Name Placeholder');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('OLD NAVY','clothing','OLD NAVY');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('MCDONALD\'S','Restaurant/Takeout/Delivery','McDonald\'s');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('USPS','Postage','Post Office');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('GEICO *AUTO','Car Insurance','GIECO');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('CALIF DMV|CA DMV','car registration/driver license','California Department of Motor Vehicles');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('BURGER KING','Restaurant/Takeout/Delivery','Burger King');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('CIRCLE K','fuel/snacks','GIECO');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('DOMINO\'S','Restaurant/Takeout/Delivery','DOMINO\'S');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`) VALUES ('STAPLES','office','Staples');
/*!40000 ALTER TABLE `feeder_phrase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feeder_row`
--

DROP TABLE IF EXISTS `feeder_row`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feeder_row` (
  `feeder_account` char(30) NOT NULL,
  `feeder_load_date_time` char(19) DEFAULT NULL,
  `feeder_row_number` int NOT NULL,
  `feeder_date` date DEFAULT NULL,
  `full_name` char(60) DEFAULT NULL,
  `transaction_date_time` datetime DEFAULT NULL,
  `file_row_description` char(140) DEFAULT NULL,
  `file_row_amount` double(12,2) DEFAULT NULL,
  `file_row_balance` double(12,2) DEFAULT NULL,
  `calculate_balance` double(12,2) DEFAULT NULL,
  `check_number` int DEFAULT NULL,
  `feeder_phrase` char(80) DEFAULT NULL,
  UNIQUE KEY `feeder_row_additional_unique` (`feeder_account`,`full_name`,`transaction_date_time`),
  UNIQUE KEY `feeder_row_unique` (`feeder_account`,`feeder_load_date_time`,`feeder_row_number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feeder_row`
--

LOCK TABLES `feeder_row` WRITE;
/*!40000 ALTER TABLE `feeder_row` DISABLE KEYS */;
/*!40000 ALTER TABLE `feeder_row` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `financial_institution`
--

DROP TABLE IF EXISTS `financial_institution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `financial_institution` (
  `full_name` char(60) NOT NULL,
  UNIQUE KEY `financial_institution_unique` (`full_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `financial_institution`
--

LOCK TABLES `financial_institution` WRITE;
/*!40000 ALTER TABLE `financial_institution` DISABLE KEYS */;
INSERT INTO `financial_institution` (`full_name`) VALUES ('Financial Institution Full Name Placeholder');
/*!40000 ALTER TABLE `financial_institution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fixed_asset`
--

DROP TABLE IF EXISTS `fixed_asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fixed_asset` (
  `asset_name` char(40) NOT NULL,
  `full_name` char(60) DEFAULT NULL,
  `purchase_date_time` datetime DEFAULT NULL,
  `fixed_asset_cost` double(12,2) DEFAULT NULL,
  `asset_account` char(60) DEFAULT NULL,
  `credit_account` char(60) DEFAULT NULL,
  `notepad` text,
  UNIQUE KEY `fixed_asset_unique` (`asset_name`),
  UNIQUE KEY `fixed_asset_additional_unique` (`purchase_date_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fixed_asset`
--

LOCK TABLES `fixed_asset` WRITE;
/*!40000 ALTER TABLE `fixed_asset` DISABLE KEYS */;
/*!40000 ALTER TABLE `fixed_asset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `investment_account`
--

DROP TABLE IF EXISTS `investment_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `investment_account` (
  `full_name` char(60) NOT NULL,
  `account_number` char(50) NOT NULL,
  `investment_medium` char(15) DEFAULT NULL,
  `certificate_maturity_months` int DEFAULT NULL,
  `certificate_maturity_date` date DEFAULT NULL,
  `interest_rate` double(5,2) DEFAULT NULL,
  `investment_purpose` char(30) DEFAULT NULL,
  `balance_latest` double(14,2) DEFAULT NULL,
  `as_of_date` date DEFAULT NULL,
  UNIQUE KEY `investment_account_unique` (`full_name`,`account_number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `investment_account`
--

LOCK TABLES `investment_account` WRITE;
/*!40000 ALTER TABLE `investment_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `investment_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `investment_medium`
--

DROP TABLE IF EXISTS `investment_medium`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `investment_medium` (
  `investment_medium` char(15) DEFAULT NULL,
  UNIQUE KEY `investment_medium_unique` (`investment_medium`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `investment_medium`
--

LOCK TABLES `investment_medium` WRITE;
/*!40000 ALTER TABLE `investment_medium` DISABLE KEYS */;
INSERT INTO `investment_medium` (`investment_medium`) VALUES ('certificate');
INSERT INTO `investment_medium` (`investment_medium`) VALUES ('checking');
INSERT INTO `investment_medium` (`investment_medium`) VALUES ('money_market');
INSERT INTO `investment_medium` (`investment_medium`) VALUES ('mutual_fund');
INSERT INTO `investment_medium` (`investment_medium`) VALUES ('savings');
INSERT INTO `investment_medium` (`investment_medium`) VALUES ('stock');
/*!40000 ALTER TABLE `investment_medium` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `investment_purpose`
--

DROP TABLE IF EXISTS `investment_purpose`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `investment_purpose` (
  `investment_purpose` char(30) NOT NULL,
  UNIQUE KEY `investment_purpose` (`investment_purpose`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `investment_purpose`
--

LOCK TABLES `investment_purpose` WRITE;
/*!40000 ALTER TABLE `investment_purpose` DISABLE KEYS */;
INSERT INTO `investment_purpose` (`investment_purpose`) VALUES ('available');
INSERT INTO `investment_purpose` (`investment_purpose`) VALUES ('retirement');
/*!40000 ALTER TABLE `investment_purpose` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal`
--

DROP TABLE IF EXISTS `journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `journal` (
  `full_name` char(60) NOT NULL,
  `transaction_date_time` datetime NOT NULL,
  `account` char(60) NOT NULL,
  `previous_balance` double(10,2) DEFAULT NULL,
  `debit_amount` double(10,2) DEFAULT NULL,
  `credit_amount` double(10,2) DEFAULT NULL,
  `balance` double(11,2) DEFAULT NULL,
  UNIQUE KEY `journal_unique` (`full_name`,`transaction_date_time`,`account`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal`
--

LOCK TABLES `journal` WRITE;
/*!40000 ALTER TABLE `journal` DISABLE KEYS */;
/*!40000 ALTER TABLE `journal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `select_statement`
--

DROP TABLE IF EXISTS `select_statement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `select_statement` (
  `select_statement_title` char(80) NOT NULL,
  `select_statement` text,
  UNIQUE KEY `select_statement_unique` (`select_statement_title`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `select_statement`
--

LOCK TABLES `select_statement` WRITE;
/*!40000 ALTER TABLE `select_statement` DISABLE KEYS */;
INSERT INTO `select_statement` (`select_statement_title`, `select_statement`) VALUES ('account_without_tax_form','select account, element from account, subclassification where subclassification.element in (\'revenue\',\'expense\',\'gain\',\'loss\') and account.subclassification = subclassification.subclassification and not exists ( select 1 from tax_form_line_account where account.account = tax_form_line_account.account ) order by account');
/*!40000 ALTER TABLE `select_statement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subclassification`
--

DROP TABLE IF EXISTS `subclassification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subclassification` (
  `subclassification` char(35) NOT NULL,
  `element` char(20) DEFAULT NULL,
  `display_order` int DEFAULT NULL,
  UNIQUE KEY `subclassification` (`subclassification`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subclassification`
--

LOCK TABLES `subclassification` WRITE;
/*!40000 ALTER TABLE `subclassification` DISABLE KEYS */;
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('cash_or_equivalent','asset',1);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('net_asset','equity',15);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('donation','expense',7);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('current_liability','liability',3);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('gain','gain',13);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('transportation','expense',9);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('long-term liability','liability',4);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('loss','loss',14);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('operating_expense','expense',5);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('fixed_asset','asset',2);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('entertainment','expense',10);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('revenue','revenue',12);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('Home','expense',6);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('tax_expense','expense',11);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('Medical','expense',8);
/*!40000 ALTER TABLE `subclassification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tax_form`
--

DROP TABLE IF EXISTS `tax_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tax_form` (
  `tax_form` char(20) NOT NULL,
  UNIQUE KEY `tax_form` (`tax_form`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tax_form`
--

LOCK TABLES `tax_form` WRITE;
/*!40000 ALTER TABLE `tax_form` DISABLE KEYS */;
INSERT INTO `tax_form` (`tax_form`) VALUES ('1040');
INSERT INTO `tax_form` (`tax_form`) VALUES ('540');
INSERT INTO `tax_form` (`tax_form`) VALUES ('8829');
INSERT INTO `tax_form` (`tax_form`) VALUES ('Schedule 1');
INSERT INTO `tax_form` (`tax_form`) VALUES ('Schedule A');
/*!40000 ALTER TABLE `tax_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tax_form_line`
--

DROP TABLE IF EXISTS `tax_form_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tax_form_line` (
  `tax_form` char(20) NOT NULL,
  `tax_form_line` char(5) NOT NULL,
  `tax_form_description` char(40) DEFAULT NULL,
  UNIQUE KEY `tax_form_line` (`tax_form`,`tax_form_line`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tax_form_line`
--

LOCK TABLES `tax_form_line` WRITE;
/*!40000 ALTER TABLE `tax_form_line` DISABLE KEYS */;
INSERT INTO `tax_form_line` (`tax_form`, `tax_form_line`, `tax_form_description`) VALUES ('Schedule A','5a','Real estate taxes');
INSERT INTO `tax_form_line` (`tax_form`, `tax_form_line`, `tax_form_description`) VALUES ('Schedule A','11','Gifts by cash or check');
INSERT INTO `tax_form_line` (`tax_form`, `tax_form_line`, `tax_form_description`) VALUES ('8829','17','Real estate taxes');
INSERT INTO `tax_form_line` (`tax_form`, `tax_form_line`, `tax_form_description`) VALUES ('8829','18','Insurance');
INSERT INTO `tax_form_line` (`tax_form`, `tax_form_line`, `tax_form_description`) VALUES ('8829','21','Utilities');
INSERT INTO `tax_form_line` (`tax_form`, `tax_form_line`, `tax_form_description`) VALUES ('1040','29','Self-employed health insurance deduction');
INSERT INTO `tax_form_line` (`tax_form`, `tax_form_line`, `tax_form_description`) VALUES ('Schedule A','1','Medical and dental expenses');
INSERT INTO `tax_form_line` (`tax_form`, `tax_form_line`, `tax_form_description`) VALUES ('8829','20b','Home repairs and maintenance');
/*!40000 ALTER TABLE `tax_form_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tax_form_line_account`
--

DROP TABLE IF EXISTS `tax_form_line_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tax_form_line_account` (
  `tax_form` char(20) NOT NULL,
  `tax_form_line` char(5) NOT NULL,
  `account` char(60) NOT NULL,
  UNIQUE KEY `tax_form_line_account` (`tax_form`,`tax_form_line`,`account`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tax_form_line_account`
--

LOCK TABLES `tax_form_line_account` WRITE;
/*!40000 ALTER TABLE `tax_form_line_account` DISABLE KEYS */;
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('8829','17','property_tax');
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('8829','18','Flood Insurance');
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('8829','18','Home Insurance');
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('8829','20b','house_maintenance');
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('8829','21','Alarm');
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('8829','21','alarm_permit');
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('8829','21','Garbage/Water');
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('8829','21','Sewage');
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('8829','21','utilities');
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('Schedule A','1','Dental');
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('Schedule A','1','Healthcare consumption');
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('Schedule A','11','donation_cash');
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('Schedule A','5a','property_tax');
/*!40000 ALTER TABLE `tax_form_line_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction` (
  `full_name` char(60) NOT NULL,
  `transaction_date_time` datetime NOT NULL,
  `memo` char(60) DEFAULT NULL,
  `transaction_amount` double(10,2) DEFAULT NULL,
  `check_number` int DEFAULT NULL,
  `transaction_lock_y` char(1) DEFAULT NULL,
  UNIQUE KEY `transaction_date_time_additional_unique` (`transaction_date_time`),
  UNIQUE KEY `transaction_unique` (`full_name`,`transaction_date_time`),
  UNIQUE KEY `check_number_additional_unique` (`check_number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction`
--

LOCK TABLES `transaction` WRITE;
/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-18 23:18:10
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('appaserver_info','appaserver_info.sh \$process','view',null,null,null,null,null,null);
insert into role_process (role,process) values ('supervisor','appaserver_info');
insert into role_process (role,process) values ('system','appaserver_info');
insert into process_group (process_group) values ('view');
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('BofA_checking_upload','feeder_upload_csv \$process \$login_name fund_name bank_of_america_checking filename 1 2 3 credit_column 4 reference_column reverse_order_yn account_end_balance execute_yn','BofA','<ol><li>Download your checking transactions from Bank of America.<li>Choose the file type of Excel.<li>Hint: do not first load them into Excel and then save them to your computer. Instead, save them and then, optionally, load them into Excel.<li> Use a begin date as the end date of your last download. The end date of your last download will display if you submit this form without a file. Use \'Final Feeder Date\' as the begin date.<li>Hint: [Right Click] the browser\'s tab above and select \'Duplicate Tab\'. Use the new PredictBooks instance to:<ul><li>Feeder --> Insert Expense Transaction or<li>Feeder --> Insert Feeder Phrase</ul></ol>',null,null,'50',null,null);
insert into role_process (role,process) values ('supervisor','BofA_checking_upload');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('BofA_checking_upload','null','null','null','execute_yn','9',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('BofA_checking_upload','null','null','null','filename','1',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('execute_yn','Omit execute for display.',null,null,'1');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('filename',null,'y',null,'100');
insert into process_group (process_group) values ('BofA');
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('BofA_credit_upload','feeder_upload_csv \$process \$login_name fund_name bank_of_america_credit_card filename 1 3 5 credit_column balance_column 2 y account_end_balance execute_yn','BofA','The bank\'s begin date will display if you submit this form without a file. Use \'Final Feeder Date\' as the begin date.',null,null,'37',null,null);
insert into role_process (role,process) values ('supervisor','BofA_credit_upload');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('BofA_credit_upload','null','null','null','account_end_balance','2',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('BofA_credit_upload','null','null','null','execute_yn','9',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('BofA_credit_upload','null','null','null','filename','1',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('account_end_balance','For Credit Card accounts, this will be a negative number.',null,null,'10');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('execute_yn','Omit execute for display.',null,null,'1');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('filename',null,'y',null,'100');
insert into process_group (process_group) values ('BofA');
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('budget_forecast','budget_report \$session \$process output_medium','output',null,null,null,null,null,null);
insert into role_process (role,process) values ('supervisor','budget_forecast');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('budget_forecast','null','null','output_medium','null','2',null,null,null,null);
insert into drop_down_prompt (drop_down_prompt,hint_message,optional_display) values ('output_medium',null,null);
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('output_medium','PDF','2');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('output_medium','spreadsheet','3');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('output_medium','table','1');
insert into process_group (process_group) values ('output');
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('change_password','change_password \$session \$login_name \$role \$process','alter',null,null,null,null,null,null);
insert into role_process (role,process) values ('supervisor','change_password');
insert into role_process (role,process) values ('system','change_password');
insert into process_group (process_group) values ('alter');
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('close_nominal_accounts','close_nominal_accounts \$process fund_name as_of_date undo_yn execute_yn','alter',null,'post_change_close_nominal_accounts()','post_change_close_nominal_accounts.js',null,null,null);
insert into role_process (role,process) values ('supervisor','close_nominal_accounts');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('close_nominal_accounts','null','null','null','as_of_date','1',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('close_nominal_accounts','null','null','null','execute_yn','9',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('close_nominal_accounts','null','null','null','undo_yn','2',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('as_of_date',null,null,'y','10');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('execute_yn','Omit execute for display.',null,null,'1');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('undo_yn',null,null,null,'1');
insert into process_group (process_group) values ('alter');
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('execute_select_statement','execute_select_statement \$process \$session \$role select_statement_title login_name statement','output',null,null,null,null,null,null);
insert into role_process (role,process) values ('supervisor','execute_select_statement');
insert into role_process (role,process) values ('system','execute_select_statement');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('execute_select_statement','null','null','null','statement','2',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('execute_select_statement','select_statement','null','null','null','1',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('statement',null,null,null,'2048');
insert into process_group (process_group) values ('output');
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('feeder_journal_orphan_audit','feeder_journal_orphan_audit.sh \$process feeder_account minimum_transaction_date','audit','This process outputs Journal rows connected to a Feeder Account that lack a corresponding Feeder Row. After executing a feeder load process, you may get a Status of "Different" instead of "Okay". The cause is a duplicated transaction. Two possible duplication vulnerabilities are: <ol><li>You manually inserted in a restaurant transaction using a receipt that didn\'t include the tip. The feeder load then inserted a duplicate transaction by matching the feeder phrase.<ul><li>The solution is to seek out the manually inserted transaction and delete it.</ul><li>A transaction was inserted on a prior feeder load. However, on your last feeder load, the bank changed the description column a little. Therefore, the feeder phrase matching algorithm didn\'t match the existing transaction and inserted a new one.<ul><li>The solution is to seek out either transaction and delete it.</ul></ol>',null,null,null,null,null);
insert into role_process (role,process) values ('supervisor','feeder_journal_orphan_audit');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('feeder_journal_orphan_audit','feeder_account','null','null','null','1',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('feeder_journal_orphan_audit','null','null','null','minimum_transaction_date','1',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('minimum_transaction_date',null,null,'y','10');
insert into process_group (process_group) values ('audit');
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('feeder_row_journal_audit','feeder_row_journal_audit.sh \$process feeder_account minimum_transaction_date','audit','<ul><li>When you execute a feeder upload process, there are multiple attempts to ensure your PredictBooks\' transactions are synchronized with your Financial Institution\'s transactions. If your Financial Institution\'s download file contains a running balance column, then there are two safeguards in place. If your Financial Institution\'s download file lacks a running balance column, then there is one safeguard in place. This process joins the PredictBooks\' Journal rows with the Financial Institution\'s Feeder Rows. Three running balance columns are displayed: File Row Balance, Calculate Balance, and Ledger Balance.<li>It is natural for a temporary difference to appear when a check clears. A temporary difference will appear between the date you cut the check until the date the check clears. However, the ledger balance Difference should be zero as of 11:59:59 PM yesterday.</ul>',null,null,null,null,null);
insert into role_process (role,process) values ('supervisor','feeder_row_journal_audit');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('feeder_row_journal_audit','feeder_account','null','null','null','1',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('feeder_row_journal_audit','null','null','null','minimum_transaction_date','1',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('minimum_transaction_date',null,null,'y','10');
insert into process_group (process_group) values ('audit');
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('feeder_upload','feeder_upload \$process \$login_name fund_name feeder_account exchange_format_filename execute_yn','feeder','<ol><li>Download your transactions from your Financial Institution using a begin date as the end date of your last download. The end date of your last download will display if you submit this form without a file. Use \'Final Feeder Date\' as the begin date.<li>Hint: [Right Click] the browser\'s tab above and select \'Duplicate Tab\'. Use the new PredictBooks instance to:<ul><li>Feeder --> Insert Expense Transaction or<li>Feeder --> Insert Feeder Phrase</ul></ol>',null,null,'73',null,null);
insert into role_process (role,process) values ('supervisor','feeder_upload');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('feeder_upload','feeder_account','null','null','null','1',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('feeder_upload','null','null','null','exchange_format_filename','2',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('feeder_upload','null','null','null','execute_yn','9',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('exchange_format_filename','Log into your bank\'s website and download your transactions. Choose the format option likely to be the Exchange Format. It will probably be the top row in the format selection list. It will also probably have a filename that ends with xf.','y',null,'255');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('execute_yn','Omit execute for display.',null,null,'1');
insert into process_group (process_group) values ('feeder');
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('financial_position','financial_position \$session \$login_name \$role \$process as_of_date prior_year_count subclassification_option output_medium contra_account_yn fund_name','output','<table border=1><tr><th>Total Debit</th><th>=</th><th>Total Credit</th><tr><th>Asset</th><th>=</th><th>Liability + Equity</th><tr><td>Asset, Expense, Loss<td><td>Liability, Revenue, Equity, Gain</table>',null,null,null,null,null);
insert into role_process (role,process) values ('supervisor','financial_position');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('financial_position','null','null','finance_output_medium','null','5',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('financial_position','null','null','null','as_of_date','1',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('financial_position','null','null','null','contra_account_yn','4',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('financial_position','null','null','null','prior_year_count','2',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('financial_position','null','null','subclassification_option','null','3',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('as_of_date',null,null,'y','10');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('contra_account_yn',null,null,null,'1');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('prior_year_count',null,null,null,'3');
insert into drop_down_prompt (drop_down_prompt,hint_message,optional_display) values ('finance_output_medium',null,'output_medium');
insert into drop_down_prompt (drop_down_prompt,hint_message,optional_display) values ('subclassification_option',null,null);
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('finance_output_medium','PDF','2');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('finance_output_medium','table','1');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('subclassification_option','aggregate','2');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('subclassification_option','display','1');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('subclassification_option','omit','3');
insert into process_group (process_group) values ('output');
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('import_predictbooks','import_predictbooks \$session \$login \$role \$process execute_yn','alter','This process imports the PredictBooks home edition.',null,null,null,null,null);
insert into role_process (role,process) values ('supervisor','import_predictbooks');
insert into role_process (role,process) values ('system','import_predictbooks');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('import_predictbooks','null','null','null','execute_yn','9',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('execute_yn','Omit execute for display.',null,null,'1');
insert into process_group (process_group) values ('alter');
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('initialize_BofA_checking_account','feeder_init_csv_execute \$session \$login \$role \$process fund_name bank_of_america \'\' checking filename 1 2 3 credit_column 4 reference_column reverse_order_yn account_end_balance execute_yn','BofA','<ol><li>Bank of America does not support the Open Financial eXchange file format. Therefore, on the bank\'s website, you must select the Excel output option.<li>This process generates an opening entry transaction.<li>The transaction is assigned to the entity stored in the Self table. When you first install Appaserver, the Self table has a placeholder full name. Change this placeholder to your full name. The menu path is:<br>Lookup --> Entity --> Self<li>This process creates an asset account. The account name is a variation of bank_of_america. When you first import PredictBooks, the Financial Institution table has a placeholder full name. Change this placeholder to <i>bank_of_america</i>. The menu path is:<br>Lookup --> Entity --> Financial Institution<li>This process also generates useful bookkeeping tips. You can view the tips without generating an opening entry by leaving the Filename blank.</ol>',null,null,null,null,null);
insert into role_process (role,process) values ('supervisor','initialize_BofA_checking_account');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('initialize_BofA_checking_account','null','null','null','execute_yn','9',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('initialize_BofA_checking_account','null','null','null','filename','1',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('execute_yn','Omit execute for display.',null,null,'1');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('filename',null,'y',null,'100');
insert into process_group (process_group) values ('BofA');
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('initialize_BofA_credit_account','feeder_init_csv_execute \$session \$login \$role \$process fund_name bank_of_america \'\' credit_card filename 1 3 5 credit_column balance_column 2 y account_end_balance execute_yn','BofA','<ol><li>Bank of America does not support the Open Financial eXchange file format. Therefore, on the bank\'s website, you must select the Excel output option.<li>This process generates an opening entry transaction.<li>The transaction is assigned to the entity stored in the Self table. When you first install Appaserver, the Self table has a placeholder full name. Change this placeholder to your full name. The menu path is:<br>Lookup --> Entity --> Self<li>This process creates a liability account. The account name is a variation of bank_of_america. When you first import PredictBooks, the Financial Institution table has a placeholder full name. Change this placeholder to <i>bank_of_america</i>. The menu path is:<br>Lookup --> Entity --> Financial Institution<li>This process also generates useful bookkeeping tips. You can view the tips without generating an opening entry by leaving at least one choice blank.</ol>',null,null,null,null,null);
insert into role_process (role,process) values ('supervisor','initialize_BofA_credit_account');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('initialize_BofA_credit_account','null','null','null','account_end_balance','2',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('initialize_BofA_credit_account','null','null','null','execute_yn','9',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('initialize_BofA_credit_account','null','null','null','filename','1',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('account_end_balance','For Credit Card accounts, this will be a negative number.',null,null,'10');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('execute_yn','Omit execute for display.',null,null,'1');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('filename',null,'y',null,'100');
insert into process_group (process_group) values ('BofA');
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('initialize_feeder_account','feeder_init_execute \$session \$login \$role \$process fund_name full_name contact_key account_type exchange_format_filename execute_yn','feeder','<ol><li>This process generates an opening entry transaction.<li>The transaction is assigned to the entity stored in the Self table. When you first install Appaserver, the Self table has a placeholder full name. Change this placeholder to your full name. The menu path is:<br>Lookup --> Entity --> Self<li>This process creates: <ul><li>an asset account, if the Account Type is Checking or<li>a liability account, if the Account Type is Credit Card</ul> The account name is derived from the financial institution\'s full name. When you first import PredictBooks, the Financial Institution table has a placeholder full name. Change this placeholder to your financial institution\'s full name. The menu path is:<br>Lookup --> Entity --> Financial Institution<li>This process also generates useful bookkeeping tips. You can view the tips without generating an opening entry by leaving at least one choice blank.</ol>',null,null,null,null,null);
insert into role_process (role,process) values ('supervisor','initialize_feeder_account');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('initialize_feeder_account','financial_institution','null','null','null','1',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('initialize_feeder_account','null','null','account_type','null','2',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('initialize_feeder_account','null','null','null','exchange_format_filename','3',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('initialize_feeder_account','null','null','null','execute_yn','9',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('exchange_format_filename','Log into your bank\'s website and download your transactions. Choose the format option likely to be the Exchange Format. It will probably be the top row in the format selection list. It will also probably have a filename that ends with xf.','y',null,'255');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('execute_yn','Omit execute for display.',null,null,'1');
insert into drop_down_prompt (drop_down_prompt,hint_message,optional_display) values ('account_type',null,null);
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('account_type','checking','1');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('account_type','credit_card','2');
insert into process_group (process_group) values ('feeder');
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('insert_expense_transaction','insert_expense_transaction_execute \$process fund_name feeder_account full_name contact_key new_full_name account transaction_date transaction_amount check_number memo','feeder','<ul><li>This is a shortcut process instead of executing:<br>Insert --> Transaction --> Transaction<li>If your account isn\'t in the list below, then insert it using the path:<br>Insert --> Account --> Account.</ul>','post_change_insert_expense_transaction( this )','post_change_insert_expense_transaction.js',null,null,null);
insert into role_process (role,process) values ('supervisor','insert_expense_transaction');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('insert_expense_transaction','account','null','null','null','4',null,null,'populate_expense_account',null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('insert_expense_transaction','entity','null','null','null','2',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('insert_expense_transaction','feeder_account','null','null','null','1',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('insert_expense_transaction','null','null','null','check_number','7',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('insert_expense_transaction','null','null','null','memo','8',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('insert_expense_transaction','null','null','null','new_full_name','3',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('insert_expense_transaction','null','null','null','transaction_amount','6',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('insert_expense_transaction','null','null','null','transaction_date','5',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('check_number',null,null,null,'10');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('memo',null,null,null,'60');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('new_full_name',null,null,null,'60');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('transaction_amount',null,null,null,'10');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('transaction_date',null,null,'y','10');
insert into process_group (process_group) values ('feeder');
insert into process (process,command_line) values ('populate_expense_account','populate_expense_account.sh');
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('insert_feeder_phrase','insert_feeder_phrase \$process account new_full_name feeder_phrase','feeder','<ul><li>This is a shortcut process instead of executing:<br>Insert --> Feeder --> Feeder Phrase<li>If your account isn\'t in the list below, then insert it using the path:<br>Insert --> Account --> Account.<li>Both the feeder phrase and the full name may be the vendor\'s name copied from the feeder file\'s description cell.<br>However, the feeder phrase may need to include an adjoining keyword to remove ambiguity.<li>If the vendor already exists as an entity and already has an existing, but sightly different, feeder phrase, then:<ol><li>Lookup --> Feeder --> Feeder Phrase<li>query the entity<li>set the additional feeder phrase to the right of the existing feeder phrase, separated with a \'|\'</ol></ul>',null,null,null,null,null);
insert into role_process (role,process) values ('supervisor','insert_feeder_phrase');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('insert_feeder_phrase','account','null','null','null','3',null,null,'populate_expense_revenue_account',null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('insert_feeder_phrase','null','null','null','feeder_phrase','1',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('insert_feeder_phrase','null','null','null','new_full_name','2',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('feeder_phrase',null,null,null,'80');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('new_full_name',null,null,null,'60');
insert into process_group (process_group) values ('feeder');
insert into process (process,command_line) values ('populate_expense_revenue_account','populate_expense_revenue_account.sh');
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('ledger_debit_credit_audit','ledger_debit_credit_audit.sh \$process minimum_transaction_date delete_no_journal_yn','audit','<ol><li>One Transaction has two or more Journal entries. Each Journal entry has a debit amount or credit amount, but not both. Also, the total of the debit amounts must equal the total of the credit amounts. Unfortunately, it is a common mistake for Total Debit to not equal Total Credit. If this mistake occurs, then the last line of your Trial Balance will be off. If your Trial Balance is off, then run this process to find the out-of-balance Transactions.<li>It is also a common mistake to start entering a Transaction but not finish it. If you need to assign a Journal entry to an Account that is not there, then you need to interrupt your flow to insert the new Account. When you return to the insert Transaction screen, remember to press the [Recall] button. If you forget to press the [Recall] button, then the unfinished Transaction will linger. Not to worry, select Yes for \'Delete No Journal yn\'. Unfinished Transactions will be deleted.</ol>',null,null,null,null,null);
insert into role_process (role,process) values ('supervisor','ledger_debit_credit_audit');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('ledger_debit_credit_audit','null','null','null','delete_no_journal_yn','2',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('ledger_debit_credit_audit','null','null','null','minimum_transaction_date','1',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('delete_no_journal_yn',null,null,null,'1');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('minimum_transaction_date',null,null,'y','10');
insert into process_group (process_group) values ('audit');
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('mark_to_market_investments','account_balance_execute \$process fund_name as_of_date full_name contact_key investment_purpose execute_yn','alter',null,null,null,null,null,null);
insert into role_process (role,process) values ('supervisor','mark_to_market_investments');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('mark_to_market_investments','null','null','null','execute_yn','9',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('execute_yn','Omit execute for display.',null,null,'1');
insert into process_group (process_group) values ('alter');
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('merge_purge','merge_purge \$session \$login_name \$role \$process','alter','This process allows you to remove duplicate rows. It may be that two rows should really be one row because a spelling is slightly different in one of them.',null,null,'5',null,null);
insert into role_process (role,process) values ('supervisor','merge_purge');
insert into role_process (role,process) values ('system','merge_purge');
insert into process_group (process_group) values ('alter');
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('pay_liabilities','pay_liabilities_process \$process \$session fund_name account full_name contact_key starting_check_number memo payment_amount execute_yn','alter','<h2>Print Checks</h2><ol><li>Open in Evince, also known as Document Viewer (recommended)<li>Papersize width = 8.5 inches<li>Papersize height = 3 inches<li>Orientation = Portrait<li>Turn off scaling and other automatic formatting<li>Set all margins to zero<li>Stack all the checks face down on white paper<li>Print the checks<li>Print a blank page to eject the last check</ol>','post_change_pay_liabilities( this )','post_change_pay_liabilities.js',null,null,null);
insert into role_process (role,process) values ('supervisor','pay_liabilities');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('pay_liabilities','account','null','null','null','1',null,null,'populate_checking_account',null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('pay_liabilities','entity','null','null','null','2','y',null,'populate_print_checks_entity',null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('pay_liabilities','null','null','null','execute_yn','9',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('pay_liabilities','null','null','null','memo','5',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('pay_liabilities','null','null','null','payment_amount','4',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('pay_liabilities','null','null','null','starting_check_number','3',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('execute_yn','Omit execute for display.',null,null,'1');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('memo',null,null,null,'60');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('payment_amount',null,null,null,'10');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('starting_check_number','If printing one or more checks, enter a Starting Check Number. Otherwise, select a cash account.',null,null,'5');
insert into process_group (process_group) values ('alter');
insert into process (process,command_line) values ('populate_checking_account','populate_checking_account.sh');
insert into process (process,command_line) values ('populate_print_checks_entity','populate_print_checks_entity');
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('statement_of_activities','statement_of_activities \$session \$login_name \$role \$process as_of_date prior_year_count  subclassification_option output_medium contra_account_yn fund_name','output','<table border=1><tr><th>Total Debit</th><th>=</th><th>Total Credit</th><tr><th>Asset</th><th>=</th><th>Liability + Equity</th><tr><td>Asset, Expense, Loss<td><td>Liability, Revenue, Equity, Gain</table>',null,null,null,null,null);
insert into role_process (role,process) values ('supervisor','statement_of_activities');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('statement_of_activities','null','null','finance_output_medium','null','5',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('statement_of_activities','null','null','null','as_of_date','1',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('statement_of_activities','null','null','null','contra_account_yn','4',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('statement_of_activities','null','null','null','prior_year_count','2',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('statement_of_activities','null','null','subclassification_option','null','3',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('as_of_date',null,null,'y','10');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('contra_account_yn',null,null,null,'1');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('prior_year_count',null,null,null,'3');
insert into drop_down_prompt (drop_down_prompt,hint_message,optional_display) values ('finance_output_medium',null,'output_medium');
insert into drop_down_prompt (drop_down_prompt,hint_message,optional_display) values ('subclassification_option',null,null);
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('finance_output_medium','PDF','2');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('finance_output_medium','table','1');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('subclassification_option','aggregate','2');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('subclassification_option','display','1');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('subclassification_option','omit','3');
insert into process_group (process_group) values ('output');
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('tax_form_report','tax_form_report \$process tax_form tax_year 0 output_medium','output',null,null,null,null,null,null);
insert into role_process (role,process) values ('supervisor','tax_form_report');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('tax_form_report','null','null','null','tax_year','2',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('tax_form_report','null','null','tax_report_output_medium','null','9',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('tax_form_report','tax_form','null','null','null','1',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('tax_year',null,null,null,'4');
insert into drop_down_prompt (drop_down_prompt,hint_message,optional_display) values ('tax_report_output_medium',null,'output_medium');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('tax_report_output_medium','PDF','2');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('tax_report_output_medium','table','1');
insert into process_group (process_group) values ('output');
insert into process (process,command_line,process_group,notepad,post_change_javascript,javascript_filename,execution_count,preprompt_help_text,html_help_file_anchor) values ('trial_balance','trial_balance_output \$session \$login_name \$role \$process as_of_date prior_year_count subclassification_option output_medium','output','<table border=1><tr><th>Total Debit</th><th>=</th><th>Total Credit</th><tr><th>Asset</th><th>=</th><th>Liability + Equity</th><tr><td>Asset, Expense, Loss<td><td>Liability, Revenue, Equity, Gain</table>',null,null,null,null,null);
insert into role_process (role,process) values ('supervisor','trial_balance');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('trial_balance','null','null','finance_output_medium','null','9',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('trial_balance','null','null','null','as_of_date','1',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('trial_balance','null','null','null','prior_year_count','2',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('trial_balance','null','null','trial_balance_subclassification_option','null','3',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('as_of_date',null,null,'y','10');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('prior_year_count',null,null,null,'3');
insert into drop_down_prompt (drop_down_prompt,hint_message,optional_display) values ('finance_output_medium',null,'output_medium');
insert into drop_down_prompt (drop_down_prompt,hint_message,optional_display) values ('trial_balance_subclassification_option',null,'subclassification_option');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('finance_output_medium','PDF','2');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('finance_output_medium','table','1');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('trial_balance_subclassification_option','display','1');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('trial_balance_subclassification_option','omit','2');
insert into process_group (process_group) values ('output');
insert into appaserver_table (table_name,appaserver_form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('account','prompt','5','account','populate_account',null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('account','subclassification','null',null,null,null,null,null,null,null,null,'y',null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('contra_account','account','contra_to_account',null,null,null,null,null,null,null,null,'y',null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('contra_account','account','null',null,null,null,null,null,null,null,null,'y',null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('feeder_account','account','feeder_account',null,null,null,'y',null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('feeder_phrase','account','nominal_account',null,null,null,null,null,null,null,null,'n',null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('fixed_asset','account','asset_account',null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('fixed_asset','account','credit_account',null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('journal','account','null',null,null,null,null,null,null,'n',null,'y',null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('tax_form_line_account','account','null',null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('account','account','1',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('account','annual_budget',null,'5',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('account','hard_coded_account_key',null,'3','y',null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('account','subclassification',null,'1',null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('account','character','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('annual_budget','integer','7',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('hard_coded_account_key','character','40',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('subclassification','character','35',null,null);
insert into table_operation (table_name,role,operation) values ('account','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('account','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row \$session \$login_name \$role \$folder \$primary_data_list \$row_number \$row_count n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown \$session \$login_name \$role \$target_frame \$folder \$primary_data_list \$update_results \$update_error \$process_id \$row_count \$dictionary');
insert into table_operation (table_name,role,operation) values ('account','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('account','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','account','insert');
insert into role_table (role,table_name,permission) values ('supervisor','account','update');
insert into subschema (subschema) values ('account');
insert into process (process,command_line) values ('populate_account','populate_account.sh \$many_table \$related_column subclassification');
insert into appaserver_table (table_name,appaserver_form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('account_balance','prompt','5','investment',null,'post_change_account_balance',null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('account_balance','investment_account','null',null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('account_balance','account_number','2',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('account_balance','balance',null,'2',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('account_balance','balance_change',null,'3','y',null,'y',null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('account_balance','balance_change_percent',null,'3','y',null,'y',null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('account_balance','date','3',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('account_balance','full_name','1',null,null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('account_number','character','50',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('balance','float','11','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('balance_change','float','11','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('balance_change_percent','integer','3',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('date','current_date','10',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('full_name','character','60',null,null);
insert into table_operation (table_name,role,operation) values ('account_balance','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('account_balance','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row \$session \$login_name \$role \$folder \$primary_data_list \$row_number \$row_count n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown \$session \$login_name \$role \$target_frame \$folder \$primary_data_list \$update_results \$update_error \$process_id \$row_count \$dictionary');
insert into table_operation (table_name,role,operation) values ('account_balance','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('account_balance','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','account_balance','insert');
insert into role_table (role,table_name,permission) values ('supervisor','account_balance','update');
insert into subschema (subschema) values ('investment');
insert into process (process,command_line) values ('post_change_account_balance','post_change_account_balance fund_name full_name contact_key account_number date \$state');
insert into appaserver_table (table_name,appaserver_form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('element','table','5','account',null,null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('subclassification','element','null',null,null,null,null,null,null,'n',null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('element','accumulate_debit_yn',null,'1',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('element','element','1',null,null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('accumulate_debit_yn','character','1',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('element','character','20',null,null);
insert into table_operation (table_name,role,operation) values ('element','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('element','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row \$session \$login_name \$role \$folder \$primary_data_list \$row_number \$row_count n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown \$session \$login_name \$role \$target_frame \$folder \$primary_data_list \$update_results \$update_error \$process_id \$row_count \$dictionary');
insert into table_operation (table_name,role,operation) values ('element','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('element','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','element','lookup');
insert into appaserver_table (table_name,appaserver_form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('feeder_account','table','5','feeder',null,null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('feeder_account','account','feeder_account',null,null,null,'y',null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('feeder_account','financial_institution','null',null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('feeder_load_event','feeder_account','null',null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('feeder_account','feeder_account','1',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('feeder_account','full_name',null,'1',null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('feeder_account','character','30',null,'External accounts like credit card and Pay Pal that feed in transactions.');
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('full_name','character','60',null,null);
insert into table_operation (table_name,role,operation) values ('feeder_account','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('feeder_account','supervisor','delete_isa_only');
insert into table_operation (table_name,role,operation) values ('feeder_account','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row \$session \$login_name \$role \$folder \$primary_data_list \$row_number \$row_count n');
insert into operation (operation,output_yn) values ('delete_isa_only','n');
insert into process (process,command_line) values ('delete_isa_only','delete_folder_row \$session \$login_name \$role \$folder \$primary_data_list \$row_number \$row_count y');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown \$session \$login_name \$role \$target_frame \$folder \$primary_data_list \$update_results \$update_error \$process_id \$row_count \$dictionary');
insert into table_operation (table_name,role,operation) values ('feeder_account','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('feeder_account','supervisor','delete_isa_only');
insert into table_operation (table_name,role,operation) values ('feeder_account','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','feeder_account','insert');
insert into role_table (role,table_name,permission) values ('supervisor','feeder_account','update');
insert into subschema (subschema) values ('feeder');
insert into appaserver_table (table_name,appaserver_form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('feeder_load_event','prompt','5','feeder',null,null,null,'y',null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('feeder_load_event','appaserver_user','null',null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('feeder_load_event','feeder_account','null',null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('feeder_row','feeder_load_event','null',null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('feeder_load_event','account_end_balance',null,'5',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('feeder_load_event','account_end_date',null,'4',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('feeder_load_event','appaserver_full_name',null,'1',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('feeder_load_event','feeder_account','1',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('feeder_load_event','feeder_load_date_time','2',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('feeder_load_event','feeder_load_filename',null,'3',null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('account_end_balance','float','12','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('account_end_date','date','10',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('appaserver_full_name','character','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('feeder_account','character','30',null,'External accounts like credit card and Pay Pal that feed in transactions.');
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('feeder_load_date_time','date_time','19',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('feeder_load_filename','upload_file','80',null,null);
insert into table_operation (table_name,role,operation) values ('feeder_load_event','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('feeder_load_event','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row \$session \$login_name \$role \$folder \$primary_data_list \$row_number \$row_count n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown \$session \$login_name \$role \$target_frame \$folder \$primary_data_list \$update_results \$update_error \$process_id \$row_count \$dictionary');
insert into table_operation (table_name,role,operation) values ('feeder_load_event','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('feeder_load_event','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','feeder_load_event','update');
insert into appaserver_table (table_name,appaserver_form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('feeder_phrase','prompt','5','feeder',null,null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('feeder_phrase','account','nominal_account',null,null,null,null,null,null,null,null,'n',null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('feeder_phrase','entity','null',null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('feeder_row','feeder_phrase','null',null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('feeder_phrase','feeder_phrase','1',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('feeder_phrase','full_name',null,'2',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('feeder_phrase','nominal_account',null,'1',null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('feeder_phrase','character','80',null,'Separate multiple phrases with a vertical bar \'|\'.');
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('full_name','character','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('nominal_account','character','60',null,null);
insert into table_operation (table_name,role,operation) values ('feeder_phrase','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('feeder_phrase','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row \$session \$login_name \$role \$folder \$primary_data_list \$row_number \$row_count n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown \$session \$login_name \$role \$target_frame \$folder \$primary_data_list \$update_results \$update_error \$process_id \$row_count \$dictionary');
insert into table_operation (table_name,role,operation) values ('feeder_phrase','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('feeder_phrase','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','feeder_phrase','insert');
insert into role_table (role,table_name,permission) values ('supervisor','feeder_phrase','update');
insert into appaserver_table (table_name,appaserver_form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('feeder_row','prompt','5','feeder',null,null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('feeder_row','feeder_load_event','null',null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('feeder_row','feeder_phrase','null',null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('feeder_row','journal','null',null,'n',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('feeder_row','calculate_balance',null,'8',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('feeder_row','check_number',null,'9',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('feeder_row','feeder_account','1',null,null,null,null,'y',null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('feeder_row','feeder_date',null,'1',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('feeder_row','feeder_load_date_time','2',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('feeder_row','feeder_phrase',null,'10',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('feeder_row','feeder_row_number','3',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('feeder_row','file_row_amount',null,'6',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('feeder_row','file_row_balance',null,'7',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('feeder_row','file_row_description',null,'5',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('feeder_row','full_name',null,'2',null,null,null,'y',null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('feeder_row','transaction_date_time',null,'4',null,null,null,'y',null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('calculate_balance','float','12','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('check_number','integer','6',null,'<ul><li>If you wrote out a check and are inserting the transaction, then enter the check number.<li>If you are inserting the account payable to print the check later, then leave this blank. The Pay Liabilities process will set the check number.</ul>');
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('feeder_account','character','30',null,'External accounts like credit card and Pay Pal that feed in transactions.');
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('feeder_date','date','10',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('feeder_load_date_time','date_time','19',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('feeder_phrase','character','80',null,'Separate multiple phrases with a vertical bar \'|\'.');
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('feeder_row_number','integer','5',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('file_row_amount','float','12','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('file_row_balance','float','12','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('file_row_description','character','140',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('full_name','character','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('transaction_date_time','current_date_time','19',null,'Must be unique throughout all transactions.');
insert into table_operation (table_name,role,operation) values ('feeder_row','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('feeder_row','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row \$session \$login_name \$role \$folder \$primary_data_list \$row_number \$row_count n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown \$session \$login_name \$role \$target_frame \$folder \$primary_data_list \$update_results \$update_error \$process_id \$row_count \$dictionary');
insert into table_operation (table_name,role,operation) values ('feeder_row','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('feeder_row','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','feeder_row','update');
insert into foreign_column (table_name,related_table,related_column,foreign_column,foreign_key_index) values ('feeder_row','journal','null','feeder_account','4');
insert into foreign_column (table_name,related_table,related_column,foreign_column,foreign_key_index) values ('feeder_row','journal','null','full_name','1');
insert into foreign_column (table_name,related_table,related_column,foreign_column,foreign_key_index) values ('feeder_row','journal','null','transaction_date_time','3');
insert into appaserver_table (table_name,appaserver_form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('financial_institution','table','5','entity',null,null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('financial_institution','vendor','null',null,null,null,'y',null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('feeder_account','financial_institution','null',null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('investment_account','financial_institution','null',null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('financial_institution','full_name','1',null,null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('full_name','character','60',null,null);
insert into table_operation (table_name,role,operation) values ('financial_institution','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('financial_institution','supervisor','delete_isa_only');
insert into table_operation (table_name,role,operation) values ('financial_institution','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row \$session \$login_name \$role \$folder \$primary_data_list \$row_number \$row_count n');
insert into operation (operation,output_yn) values ('delete_isa_only','n');
insert into process (process,command_line) values ('delete_isa_only','delete_folder_row \$session \$login_name \$role \$folder \$primary_data_list \$row_number \$row_count y');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown \$session \$login_name \$role \$target_frame \$folder \$primary_data_list \$update_results \$update_error \$process_id \$row_count \$dictionary');
insert into table_operation (table_name,role,operation) values ('financial_institution','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('financial_institution','supervisor','delete_isa_only');
insert into table_operation (table_name,role,operation) values ('financial_institution','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','financial_institution','insert');
insert into role_table (role,table_name,permission) values ('supervisor','financial_institution','update');
insert into subschema (subschema) values ('entity');
insert into appaserver_table (table_name,appaserver_form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('fixed_asset','prompt','5','transaction',null,'fixed_asset_trigger',null,null,null,null,null,null,null,null,null,'post_change_fixed_asset_purchase.js',null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('fixed_asset','account','asset_account',null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('fixed_asset','account','credit_account',null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('fixed_asset','entity','null',null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('fixed_asset','transaction','purchase_date_time',null,'y',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('fixed_asset','asset_account',null,'5','n',null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('fixed_asset','asset_name','1',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('fixed_asset','credit_account',null,'5',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('fixed_asset','fixed_asset_cost',null,'3',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('fixed_asset','full_name',null,'1',null,null,null,null,'n',null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('fixed_asset','notepad',null,'6',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('fixed_asset','purchase_date_time',null,'2',null,null,null,'y',null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('asset_account','character','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('asset_name','character','40',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('credit_account','character','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('fixed_asset_cost','float','12','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('full_name','character','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('notepad','notepad','4096',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('purchase_date_time','current_date_time','19',null,null);
insert into table_operation (table_name,role,operation) values ('fixed_asset','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('fixed_asset','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row \$session \$login_name \$role \$folder \$primary_data_list \$row_number \$row_count n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown \$session \$login_name \$role \$target_frame \$folder \$primary_data_list \$update_results \$update_error \$process_id \$row_count \$dictionary');
insert into table_operation (table_name,role,operation) values ('fixed_asset','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('fixed_asset','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','fixed_asset','insert');
insert into role_table (role,table_name,permission) values ('supervisor','fixed_asset','update');
insert into subschema (subschema) values ('transaction');
insert into process (process,command_line) values ('fixed_asset_trigger','fixed_asset_home_trigger asset_name \$state preupdate_full_name preupdate_purchase_date_time');
insert into appaserver_table (table_name,appaserver_form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('investment_account','prompt','5','investment','populate_investment_account',null,'post_change_investment_account( $row )','y',null,null,null,null,null,null,null,'post_change_investment_account.js',null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('investment_account','financial_institution','null',null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('investment_account','investment_medium','null',null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('investment_account','investment_purpose','null',null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('account_balance','investment_account','null',null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('investment_account','account_number','2',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('investment_account','as_of_date',null,'4','y',null,'y',null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('investment_account','balance_latest',null,'3','y',null,'y',null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('investment_account','certificate_maturity_date',null,'6',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('investment_account','certificate_maturity_months',null,'5',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('investment_account','full_name','1',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('investment_account','interest_rate',null,'7',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('investment_account','investment_medium',null,'2',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('investment_account','investment_purpose',null,'3',null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('account_number','character','50',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('as_of_date','date','10',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('balance_latest','float','14','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('certificate_maturity_date','date','11',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('certificate_maturity_months','integer','3',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('full_name','character','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('interest_rate','float','5','2','0.0 rate < 10.0');
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('investment_medium','character','15',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('investment_purpose','character','30',null,null);
insert into table_operation (table_name,role,operation) values ('investment_account','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('investment_account','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row \$session \$login_name \$role \$folder \$primary_data_list \$row_number \$row_count n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown \$session \$login_name \$role \$target_frame \$folder \$primary_data_list \$update_results \$update_error \$process_id \$row_count \$dictionary');
insert into table_operation (table_name,role,operation) values ('investment_account','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('investment_account','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','investment_account','insert');
insert into role_table (role,table_name,permission) values ('supervisor','investment_account','update');
insert into process (process,command_line) values ('populate_investment_account','populate_investment_account.sh \$where');
insert into appaserver_table (table_name,appaserver_form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('investment_medium','table','5','investment',null,null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('investment_account','investment_medium','null',null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('investment_medium','investment_medium','1',null,null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('investment_medium','character','15',null,null);
insert into table_operation (table_name,role,operation) values ('investment_medium','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('investment_medium','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row \$session \$login_name \$role \$folder \$primary_data_list \$row_number \$row_count n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown \$session \$login_name \$role \$target_frame \$folder \$primary_data_list \$update_results \$update_error \$process_id \$row_count \$dictionary');
insert into table_operation (table_name,role,operation) values ('investment_medium','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('investment_medium','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','investment_medium','insert');
insert into role_table (role,table_name,permission) values ('supervisor','investment_medium','update');
insert into appaserver_table (table_name,appaserver_form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('investment_purpose','table','5','investment',null,null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('investment_account','investment_purpose','null',null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('investment_purpose','investment_purpose','1',null,null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('investment_purpose','character','30',null,null);
insert into table_operation (table_name,role,operation) values ('investment_purpose','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('investment_purpose','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row \$session \$login_name \$role \$folder \$primary_data_list \$row_number \$row_count n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown \$session \$login_name \$role \$target_frame \$folder \$primary_data_list \$update_results \$update_error \$process_id \$row_count \$dictionary');
insert into table_operation (table_name,role,operation) values ('investment_purpose','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('investment_purpose','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','investment_purpose','insert');
insert into role_table (role,table_name,permission) values ('supervisor','investment_purpose','update');
insert into appaserver_table (table_name,appaserver_form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('journal','prompt','10','transaction',null,'post_change_journal_ledger','post_change_journal_ledger( \'$state\' )','y','<table border=1><tr><th>Total Debit</th><th>=</th><th>Total Credit</th><tr><th>Asset</th><th>=</th><th>Liability + Equity</th><tr><td>Asset, Expense, Loss<td><td>Liability, Revenue, Equity, Gain</table>',null,null,null,null,null,null,'post_change_journal_ledger.js',null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('journal','account','null',null,null,null,null,null,null,'n',null,'y',null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('journal','transaction','null','1',null,null,null,null,null,'n','y',null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('feeder_row','journal','null',null,'n',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('journal','account','3',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('journal','balance',null,'10','y','y','y',null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('journal','credit_amount',null,'9',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('journal','debit_amount',null,'8',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('journal','full_name','1',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('journal','previous_balance',null,'7','y','y','y',null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('journal','transaction_date_time','2',null,null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('account','character','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('balance','float','11','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('credit_amount','float','10','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('debit_amount','float','10','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('full_name','character','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('previous_balance','float','10','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('transaction_date_time','current_date_time','19',null,'Must be unique throughout all transactions.');
insert into table_operation (table_name,role,operation) values ('journal','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('journal','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row \$session \$login_name \$role \$folder \$primary_data_list \$row_number \$row_count n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown \$session \$login_name \$role \$target_frame \$folder \$primary_data_list \$update_results \$update_error \$process_id \$row_count \$dictionary');
insert into table_operation (table_name,role,operation) values ('journal','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('journal','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','journal','insert');
insert into role_table (role,table_name,permission) values ('supervisor','journal','update');
insert into process (process,command_line) values ('post_change_journal_ledger','journal_trigger fund_name full_name contact_key transaction_date_time account debit_amount credit_amount \$state preupdate_fund_name preupdate_transaction_date_time preupdate_account preupdate_debit_amount preupdate_credit_amount');
insert into appaserver_table (table_name,appaserver_form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('select_statement','prompt',null,'application',null,null,null,null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('select_statement','select_statement',null,'1',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('select_statement','select_statement_title','1',null,null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('select_statement','notepad','4096',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('select_statement_title','character','80',null,null);
insert into table_operation (table_name,role,operation) values ('select_statement','supervisor','delete');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row \$session \$login_name \$role \$folder \$primary_data_list \$row_number \$row_count n');
insert into table_operation (table_name,role,operation) values ('select_statement','supervisor','delete');
insert into role_table (role,table_name,permission) values ('supervisor','select_statement','insert');
insert into role_table (role,table_name,permission) values ('supervisor','select_statement','update');
insert into role_table (role,table_name,permission) values ('system','select_statement','insert');
insert into role_table (role,table_name,permission) values ('system','select_statement','update');
insert into subschema (subschema) values ('application');
insert into appaserver_table (table_name,appaserver_form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('subclassification','prompt','5','account',null,null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('subclassification','element','null',null,null,null,null,null,null,'n',null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('account','subclassification','null',null,null,null,null,null,null,null,null,'y',null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('subclassification','display_order',null,'2',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('subclassification','element',null,'1',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('subclassification','subclassification','1',null,null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('display_order','integer','3',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('element','character','20',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('subclassification','character','35',null,null);
insert into table_operation (table_name,role,operation) values ('subclassification','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('subclassification','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row \$session \$login_name \$role \$folder \$primary_data_list \$row_number \$row_count n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown \$session \$login_name \$role \$target_frame \$folder \$primary_data_list \$update_results \$update_error \$process_id \$row_count \$dictionary');
insert into table_operation (table_name,role,operation) values ('subclassification','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('subclassification','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','subclassification','insert');
insert into role_table (role,table_name,permission) values ('supervisor','subclassification','update');
insert into appaserver_table (table_name,appaserver_form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('tax_form','table','5','tax',null,null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('tax_form_line','tax_form','null',null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('tax_form','tax_form','1',null,null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('tax_form','character','20',null,null);
insert into table_operation (table_name,role,operation) values ('tax_form','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('tax_form','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row \$session \$login_name \$role \$folder \$primary_data_list \$row_number \$row_count n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown \$session \$login_name \$role \$target_frame \$folder \$primary_data_list \$update_results \$update_error \$process_id \$row_count \$dictionary');
insert into table_operation (table_name,role,operation) values ('tax_form','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('tax_form','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','tax_form','insert');
insert into role_table (role,table_name,permission) values ('supervisor','tax_form','update');
insert into subschema (subschema) values ('tax');
insert into appaserver_table (table_name,appaserver_form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('tax_form_line','prompt','20','tax','populate_tax_form_line',null,null,'y',null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('tax_form_line','tax_form','null',null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('tax_form_line_account','tax_form_line','null','1',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('tax_form_line','tax_form','1',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('tax_form_line','tax_form_description',null,'1',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('tax_form_line','tax_form_line','2',null,null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('tax_form','character','20',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('tax_form_description','character','40',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('tax_form_line','character','5',null,null);
insert into table_operation (table_name,role,operation) values ('tax_form_line','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('tax_form_line','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row \$session \$login_name \$role \$folder \$primary_data_list \$row_number \$row_count n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown \$session \$login_name \$role \$target_frame \$folder \$primary_data_list \$update_results \$update_error \$process_id \$row_count \$dictionary');
insert into table_operation (table_name,role,operation) values ('tax_form_line','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('tax_form_line','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','tax_form_line','insert');
insert into role_table (role,table_name,permission) values ('supervisor','tax_form_line','update');
insert into process (process,command_line) values ('populate_tax_form_line','populate_tax_form_line.sh ignored \$where');
insert into appaserver_table (table_name,appaserver_form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('tax_form_line_account','prompt','5','tax',null,null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('tax_form_line_account','account','null',null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('tax_form_line_account','tax_form_line','null','1',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('tax_form_line_account','account','3',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('tax_form_line_account','tax_form','1',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('tax_form_line_account','tax_form_line','2',null,null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('account','character','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('tax_form','character','20',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('tax_form_line','character','5',null,null);
insert into table_operation (table_name,role,operation) values ('tax_form_line_account','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('tax_form_line_account','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row \$session \$login_name \$role \$folder \$primary_data_list \$row_number \$row_count n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown \$session \$login_name \$role \$target_frame \$folder \$primary_data_list \$update_results \$update_error \$process_id \$row_count \$dictionary');
insert into table_operation (table_name,role,operation) values ('tax_form_line_account','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('tax_form_line_account','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','tax_form_line_account','insert');
insert into role_table (role,table_name,permission) values ('supervisor','tax_form_line_account','update');
insert into appaserver_table (table_name,appaserver_form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('transaction','prompt','1','transaction',null,null,null,'y',null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('transaction','entity','null',null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('fixed_asset','transaction','purchase_date_time',null,'y',null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,hint_message) values ('journal','transaction','null','1',null,null,null,null,null,'n','y',null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('transaction','check_number',null,'3',null,null,null,'y',null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('transaction','full_name','1',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('transaction','memo',null,'1',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('transaction','transaction_amount',null,'1','y',null,'y',null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('transaction','transaction_date_time','2',null,null,null,null,'y',null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_yn,omit_insert_prompt_yn,omit_update_yn,additional_unique_index_yn,additional_index_yn,insert_required_yn,lookup_required_yn,default_value) values ('transaction','transaction_lock_y',null,'4','y',null,'y',null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('check_number','integer','6',null,'<ul><li>If you wrote out a check and are inserting the transaction, then enter the check number.<li>If you are inserting the account payable to print the check later, then leave this blank. The Pay Liabilities process will set the check number.</ul>');
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('full_name','character','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('memo','character','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('transaction_amount','float','10','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('transaction_date_time','current_date_time','19',null,'Must be unique throughout all transactions.');
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('transaction_lock_y','character','1',null,null);
insert into table_operation (table_name,role,operation) values ('transaction','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('transaction','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row \$session \$login_name \$role \$folder \$primary_data_list \$row_number \$row_count n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown \$session \$login_name \$role \$target_frame \$folder \$primary_data_list \$update_results \$update_error \$process_id \$row_count \$dictionary');
insert into table_operation (table_name,role,operation) values ('transaction','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('transaction','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','transaction','insert');
insert into role_table (role,table_name,permission) values ('supervisor','transaction','update');
insert into row_security_role_update (table_name,column_not_null,no_override_yn) values ('transaction','transaction_lock_y',null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('7-Eleven',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('ADT','265 Thruway Park Drive, Suite 1','West Henrietta','NY','14586',null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Amazon','410 Terry Ave N.','Seattle','WA','98109',null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('American Airlines','1 Skyview Dr','Fort Worth','TX','76155-1801',null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('American Red Cross','430 17th St NW.','Washington','DC','20006',null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Amtrak','1 Massachusetts Ave NW','Washington','DC','20001',null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Arco',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('AT&T','208 S. Akard St.','Dallas','TX','75202',null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Best Buy',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Burger King',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('California Department of Motor Vehicles','2415 1st Ave','Sacramento','CA','95818',null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('CARLS JR',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Chevron','5001 Executive Parkway, Suite 200','San Ramon','CA','94583',null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('CIRCLE K',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('CVS',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Day\'s Inn',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Denny\'s Restaurant',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('DOMINO\'S',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('eBay','2025 Hamilton Ave','San Jose','CA','95125',null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Financial Institution Full Name Placeholder',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('GIECO','5260 Western Avenue','Chevy Chase','MD','20815',null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Home Depot',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Internal Revenue Service','1111 Constitution Avenue, NW','Washington','DC','20224',null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Jamba Juice',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Jiffy Lube',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Kaiser','1 Kaiser Plaza','Oakland','CA','94612-3610',null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Liberty Mutual Group','PO Box 91018','Chicago','IL','60680-1176',null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Lowe\'s Home Improvement',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('McDonald\'s',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('OLD NAVY',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Pepboy\'s Store',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('PG&E','300 Lakeside Drive, Suite 210','Oakland','CA','94612',null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Post Office',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Raley\'s Bel Air',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Rite Aid',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Safeway Gas Station',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Safeway Supermarket',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Shell Service',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Speedway',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Staples',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Starbucks',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Supercuts',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Taco Bell',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Target',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('U.S. Treasury','1500 Pennsylvania Avenue, NW','Washington','DC','20220',null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('United Airlines','233 South Wacker Drive','Chicago','IL','60606',null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Unknown',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('UPS Store',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Wal Mart','702 SW 8th St','Bentonville','AR','72716-6209',null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Walgreens',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address) values ('Wendy\'s Restaurant',null,null,null,null,null,null,null);
insert into vendor (full_name,website_address,website_login,website_password,notepad) values ('ADT','https://myadt.com',null,null,null);
insert into vendor (full_name,website_address,website_login,website_password,notepad) values ('Amazon','https://amazon.com',null,null,null);
insert into vendor (full_name,website_address,website_login,website_password,notepad) values ('AT&T','https://att.com',null,null,null);
insert into vendor (full_name,website_address,website_login,website_password,notepad) values ('Financial Institution Full Name Placeholder',null,null,null,null);
insert into vendor (full_name,website_address,website_login,website_password,notepad) values ('Internal Revenue Service','https://www.eftps.gov/eftps/',null,null,null);
insert into vendor (full_name,website_address,website_login,website_password,notepad) values ('Kaiser','https://kp.org',null,null,null);
insert into vendor (full_name,website_address,website_login,website_password,notepad) values ('Liberty Mutual Group','https://libertymutual.com',null,null,null);
insert into vendor (full_name,website_address,website_login,website_password,notepad) values ('PG&E',null,null,null,null);
insert into vendor (full_name,website_address,website_login,website_password,notepad) values ('Staples',null,null,null,null);
insert into vendor (full_name,website_address,website_login,website_password,notepad) values ('United Airlines',null,null,null,null);
insert into financial_institution (full_name) values ('Financial Institution Full Name Placeholder');
