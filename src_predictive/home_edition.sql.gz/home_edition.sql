-- MySQL dump 10.13  Distrib 8.0.40, for Linux (x86_64)
--
-- Host: localhost    Database: home
-- ------------------------------------------------------
-- Server version	8.0.40-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account` (
  `account` char(60) NOT NULL,
  `subclassification` char(35) DEFAULT NULL,
  `hard_coded_account_key` char(40) DEFAULT NULL,
  `annual_budget` int DEFAULT NULL,
  UNIQUE KEY `account` (`account`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('account_payable','current_liability','account_payable_key',NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('checking','cash','cash_key',NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('net_asset','net_asset','equity_key',NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('loss','loss','loss_key',NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('repairs_maintenance_expense','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Interest','revenue',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Gift','entertainment',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('uncleared_checks','current_liability','uncleared_checks',NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('investment','cash','investment',NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('mortgage','long-term liability',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('investment_decrease','loss','investment_loss',NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Groceries','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Healthcare premium','Medical',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Healthcare consumption','Medical',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Phone/Internet/TV','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Electricity','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Car fuel/Convenient groceries','transportation',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Medication','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Alarm','Home',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Garbage/Water','Home',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Sewage','Home',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Car Insurance','transportation',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Home Insurance','Home',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Flood Insurance','Home',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Restaurant/Takeout','entertainment',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('car/driver license','transportation',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('plumbing_services','Home',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('property_tax','Home',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('donation_cash','donation',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('donation_property','donation',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('alarm_permit','Home',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Error gain','gain',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Error loss','loss',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Natural gas','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Miscellaneous expense','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('house','fixed_asset',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('vehicle','fixed_asset',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Car maintenance','transportation',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('income_tax','tax_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Haircut','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('entertainment_expense','entertainment',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('outside_maintenance','Home',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('clothing','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('pet','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('cash_withdrawal','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('computers/electronics','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('big_box_expense','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('car_parking','transportation',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Shoes','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('show','entertainment',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('house_maintenance','Home',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('public_transportation','transportation',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('city_utility_tax','Home',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Concerts','entertainment',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Travel','entertainment',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Dental','Medical',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('news','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('bank_fees','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Eyecare','Medical',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('gain','gain',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('amazon expense','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Exercise','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('Postage','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('tolls','transportation',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('investment_increase','gain','investment_gain',NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('drycleaning','operating_expense',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('salary/wage','revenue',NULL,NULL);
INSERT INTO `account` (`account`, `subclassification`, `hard_coded_account_key`, `annual_budget`) VALUES ('fixed_asset','fixed_asset',NULL,NULL);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_balance`
--

DROP TABLE IF EXISTS `account_balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_balance` (
  `full_name` char(60) NOT NULL,
  `street_address` char(60) DEFAULT NULL,
  `account_number` char(50) NOT NULL,
  `date` date NOT NULL,
  `balance` double(11,2) DEFAULT NULL,
  `balance_change` double(11,2) DEFAULT NULL,
  `balance_change_percent` int DEFAULT NULL,
  UNIQUE KEY `account_balance` (`full_name`,`street_address`,`account_number`,`date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_balance`
--

LOCK TABLES `account_balance` WRITE;
/*!40000 ALTER TABLE `account_balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `element`
--

DROP TABLE IF EXISTS `element`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `element` (
  `element` char(20) NOT NULL,
  `accumulate_debit_yn` char(1) DEFAULT NULL,
  UNIQUE KEY `element` (`element`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `element`
--

LOCK TABLES `element` WRITE;
/*!40000 ALTER TABLE `element` DISABLE KEYS */;
INSERT INTO `element` (`element`, `accumulate_debit_yn`) VALUES ('asset','y');
INSERT INTO `element` (`element`, `accumulate_debit_yn`) VALUES ('equity','n');
INSERT INTO `element` (`element`, `accumulate_debit_yn`) VALUES ('expense','y');
INSERT INTO `element` (`element`, `accumulate_debit_yn`) VALUES ('gain','n');
INSERT INTO `element` (`element`, `accumulate_debit_yn`) VALUES ('liability','n');
INSERT INTO `element` (`element`, `accumulate_debit_yn`) VALUES ('loss','y');
INSERT INTO `element` (`element`, `accumulate_debit_yn`) VALUES ('revenue','n');
/*!40000 ALTER TABLE `element` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feeder_account`
--

DROP TABLE IF EXISTS `feeder_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feeder_account` (
  `feeder_account` char(30) NOT NULL,
  UNIQUE KEY `feeder_account` (`feeder_account`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feeder_account`
--

LOCK TABLES `feeder_account` WRITE;
/*!40000 ALTER TABLE `feeder_account` DISABLE KEYS */;
INSERT INTO `feeder_account` (`feeder_account`) VALUES ('checking');
/*!40000 ALTER TABLE `feeder_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feeder_load_event`
--

DROP TABLE IF EXISTS `feeder_load_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feeder_load_event` (
  `feeder_account` char(30) NOT NULL,
  `feeder_load_date_time` char(19) DEFAULT NULL,
  `login_name` char(50) DEFAULT NULL,
  `feeder_load_filename` char(80) DEFAULT NULL,
  `account_end_date` char(10) DEFAULT NULL,
  `account_end_balance` double(12,2) DEFAULT NULL,
  UNIQUE KEY `feeder_load_event` (`feeder_account`,`feeder_load_date_time`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feeder_load_event`
--

LOCK TABLES `feeder_load_event` WRITE;
/*!40000 ALTER TABLE `feeder_load_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `feeder_load_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feeder_phrase`
--

DROP TABLE IF EXISTS `feeder_phrase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feeder_phrase` (
  `feeder_phrase` char(80) NOT NULL,
  `nominal_account` char(60) DEFAULT NULL,
  `full_name` char(60) DEFAULT NULL,
  `street_address` char(60) DEFAULT NULL,
  UNIQUE KEY `feeder_phrase` (`feeder_phrase`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feeder_phrase`
--

LOCK TABLES `feeder_phrase` WRITE;
/*!40000 ALTER TABLE `feeder_phrase` DISABLE KEYS */;
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('HOME DEPOT','outside_maintenance','Home Depot','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('KAISER HPS','Healthcare premium','Kaiser','1 Kaiser Plaza');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('ADT','Alarm','ADT','265 Thruway Park Drive, Suite 1');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('SAFEWAY STORE','Groceries','Safeway Supermarket','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('SHELL Service|SHELL OIL','Car fuel/Convenient groceries','Shell Service','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('BEL AIR,RALEY','Groceries','Raley\'s Bel Air','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('LIBERTY MUTUAL DES','Car Insurance','Liberty Mutual Group','PO Box 91018');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('PACIFIC GAS','Natural gas','PG&E',' 300 Lakeside Drive, Suite 210');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('TARGET','big_box_expense','Target','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('JIFFY LUBE','Car maintenance','Jiffy Lube','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('CHEVRON','Car fuel/Convenient groceries','Chevron',' 5001 Executive Parkway, Suite 200');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('SUPERCUTS','Haircut','Supercuts','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('ARCO','Car fuel/Convenient groceries','Arco','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('SAFEWAY FUEL','Car fuel/Convenient groceries','Safeway Gas Station','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('WENDY\'S','Restaurant/Takeout','Wendy\'s Restaurant','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('CVS/PHARM,CVS/PHARMACY','Groceries','CVS','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('BEST BUY|BESTBUY','computers/electronics','Best Buy','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('STARBUCKS','Restaurant/Takeout','Starbucks','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('PEPBOYS','Car maintenance','Pepboy\'s Store','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('WALGREENS','Groceries','Walgreens','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('7-ELEVEN','Car fuel/Convenient groceries','7-Eleven','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('WAL-MART','big_box_expense','Wal Mart','702 SW 8th St');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('UPS STORE','Postage','UPS Store','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('CARLS JR','Restaurant/Takeout','CARLS JR','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('UNITED','Travel','United Airlines','233 South Wacker Drive');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('AT&T PREPAID,ATT DES','Phone/Internet/TV','AT&T','208 S. Akard St.');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('AMAZON.COM|AMZN','amazon expense','Amazon','410 Terry Ave N.');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('JAMBA JUICE','Restaurant/Takeout','Jamba Juice','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('Speedway','Car fuel/Convenient groceries','Speedway','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('KAISER ONLINE PAY','Healthcare consumption','Kaiser','1 Kaiser Plaza');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('BKOFAMERICA ATM','entertainment_expense','bank_of_america','100 North Tryon Street');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('KAISER PHARM','Healthcare consumption','Kaiser','1 Kaiser Plaza');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('TACO BELL','Restaurant/Takeout','Taco Bell','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('Interest Earned','Interest','bank_of_america','100 North Tryon Street');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('OLD NAVY','clothing','OLD NAVY','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('MCDONALD\'S','Restaurant/Takeout','McDonald\'s','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('USPS','Postage','Post Office','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('LOWE\'S','outside_maintenance','Lowe\'s Hardware','any');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('CALIF DMV,CA DMV','car/driver license','California Department of Motor Vehicles','2415 1st Ave');
INSERT INTO `feeder_phrase` (`feeder_phrase`, `nominal_account`, `full_name`, `street_address`) VALUES ('BURGER KING','Restaurant/Takeout','Burger King','any');
/*!40000 ALTER TABLE `feeder_phrase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feeder_row`
--

DROP TABLE IF EXISTS `feeder_row`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feeder_row` (
  `feeder_account` char(30) NOT NULL,
  `feeder_load_date_time` char(19) DEFAULT NULL,
  `feeder_row_number` int NOT NULL,
  `feeder_date` date DEFAULT NULL,
  `full_name` char(60) DEFAULT NULL,
  `street_address` char(60) DEFAULT NULL,
  `transaction_date_time` datetime DEFAULT NULL,
  `file_row_description` char(140) DEFAULT NULL,
  `file_row_amount` double(12,2) DEFAULT NULL,
  `file_row_balance` double(12,2) DEFAULT NULL,
  `calculate_balance` double(12,2) DEFAULT NULL,
  `check_number` int DEFAULT NULL,
  `feeder_phrase` char(80) DEFAULT NULL,
  UNIQUE KEY `feeder_row` (`feeder_account`,`feeder_load_date_time`,`feeder_row_number`),
  UNIQUE KEY `feeder_row_additional_unique` (`feeder_account`,`full_name`,`street_address`,`transaction_date_time`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feeder_row`
--

LOCK TABLES `feeder_row` WRITE;
/*!40000 ALTER TABLE `feeder_row` DISABLE KEYS */;
/*!40000 ALTER TABLE `feeder_row` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `financial_institution`
--

DROP TABLE IF EXISTS `financial_institution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `financial_institution` (
  `full_name` char(60) NOT NULL,
  `street_address` char(60) DEFAULT NULL,
  UNIQUE KEY `financial_institution` (`full_name`,`street_address`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `financial_institution`
--

LOCK TABLES `financial_institution` WRITE;
/*!40000 ALTER TABLE `financial_institution` DISABLE KEYS */;
INSERT INTO `financial_institution` (`full_name`, `street_address`) VALUES ('bank_of_america','100 North Tryon Street');
/*!40000 ALTER TABLE `financial_institution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `investment_account`
--

DROP TABLE IF EXISTS `investment_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `investment_account` (
  `full_name` char(60) NOT NULL,
  `street_address` char(60) DEFAULT NULL,
  `account_number` char(50) NOT NULL,
  `investment_classification` char(15) DEFAULT NULL,
  `certificate_maturity_months` int DEFAULT NULL,
  `certificate_maturity_date` date DEFAULT NULL,
  `interest_rate` double(5,2) DEFAULT NULL,
  `investment_purpose` char(30) DEFAULT NULL,
  `balance_latest` double(14,2) DEFAULT NULL,
  UNIQUE KEY `investment_account` (`full_name`,`street_address`,`account_number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `investment_account`
--

LOCK TABLES `investment_account` WRITE;
/*!40000 ALTER TABLE `investment_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `investment_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `investment_classification`
--

DROP TABLE IF EXISTS `investment_classification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `investment_classification` (
  `investment_classification` char(15) NOT NULL,
  UNIQUE KEY `investment_classification` (`investment_classification`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `investment_classification`
--

LOCK TABLES `investment_classification` WRITE;
/*!40000 ALTER TABLE `investment_classification` DISABLE KEYS */;
INSERT INTO `investment_classification` (`investment_classification`) VALUES ('certificate');
INSERT INTO `investment_classification` (`investment_classification`) VALUES ('checking');
INSERT INTO `investment_classification` (`investment_classification`) VALUES ('money_market');
INSERT INTO `investment_classification` (`investment_classification`) VALUES ('mutual_fund');
INSERT INTO `investment_classification` (`investment_classification`) VALUES ('savings');
INSERT INTO `investment_classification` (`investment_classification`) VALUES ('stock');
/*!40000 ALTER TABLE `investment_classification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `investment_purpose`
--

DROP TABLE IF EXISTS `investment_purpose`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `investment_purpose` (
  `investment_purpose` char(30) NOT NULL,
  UNIQUE KEY `investment_purpose` (`investment_purpose`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `investment_purpose`
--

LOCK TABLES `investment_purpose` WRITE;
/*!40000 ALTER TABLE `investment_purpose` DISABLE KEYS */;
INSERT INTO `investment_purpose` (`investment_purpose`) VALUES ('appahost');
INSERT INTO `investment_purpose` (`investment_purpose`) VALUES ('available');
INSERT INTO `investment_purpose` (`investment_purpose`) VALUES ('retirement');
/*!40000 ALTER TABLE `investment_purpose` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal`
--

DROP TABLE IF EXISTS `journal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `journal` (
  `full_name` char(60) NOT NULL,
  `street_address` char(60) DEFAULT NULL,
  `transaction_date_time` datetime NOT NULL,
  `account` char(60) NOT NULL,
  `previous_balance` double(10,2) DEFAULT NULL,
  `debit_amount` double(10,2) DEFAULT NULL,
  `credit_amount` double(10,2) DEFAULT NULL,
  `balance` double(11,2) DEFAULT NULL,
  UNIQUE KEY `journal` (`full_name`,`street_address`,`transaction_date_time`,`account`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal`
--

LOCK TABLES `journal` WRITE;
/*!40000 ALTER TABLE `journal` DISABLE KEYS */;
/*!40000 ALTER TABLE `journal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prior_fixed_asset`
--

DROP TABLE IF EXISTS `prior_fixed_asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prior_fixed_asset` (
  `asset_name` char(40) NOT NULL,
  `full_name` char(60) DEFAULT NULL,
  `street_address` char(60) DEFAULT NULL,
  `purchase_date_time` datetime DEFAULT NULL,
  `fixed_asset_cost` double(12,2) DEFAULT NULL,
  `asset_account` char(60) DEFAULT NULL,
  UNIQUE KEY `prior_fixed_asset` (`asset_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prior_fixed_asset`
--

LOCK TABLES `prior_fixed_asset` WRITE;
/*!40000 ALTER TABLE `prior_fixed_asset` DISABLE KEYS */;
/*!40000 ALTER TABLE `prior_fixed_asset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subclassification`
--

DROP TABLE IF EXISTS `subclassification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subclassification` (
  `subclassification` char(35) NOT NULL,
  `element` char(20) DEFAULT NULL,
  `display_order` int DEFAULT NULL,
  UNIQUE KEY `subclassification` (`subclassification`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subclassification`
--

LOCK TABLES `subclassification` WRITE;
/*!40000 ALTER TABLE `subclassification` DISABLE KEYS */;
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('cash','asset',1);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('net_asset','equity',16);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('donation','expense',8);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('current_liability','liability',4);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('gain','gain',14);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('transportation','expense',10);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('long-term liability','liability',5);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('loss','loss',15);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('operating_expense','expense',6);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('fixed_asset','asset',3);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('entertainment','expense',11);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('revenue','revenue',13);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('Home','expense',7);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('tax_expense','expense',12);
INSERT INTO `subclassification` (`subclassification`, `element`, `display_order`) VALUES ('Medical','expense',9);
/*!40000 ALTER TABLE `subclassification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tax_form`
--

DROP TABLE IF EXISTS `tax_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tax_form` (
  `tax_form` char(20) NOT NULL,
  UNIQUE KEY `tax_form` (`tax_form`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tax_form`
--

LOCK TABLES `tax_form` WRITE;
/*!40000 ALTER TABLE `tax_form` DISABLE KEYS */;
INSERT INTO `tax_form` (`tax_form`) VALUES ('1040');
INSERT INTO `tax_form` (`tax_form`) VALUES ('540');
INSERT INTO `tax_form` (`tax_form`) VALUES ('8829');
INSERT INTO `tax_form` (`tax_form`) VALUES ('Schedule 1');
INSERT INTO `tax_form` (`tax_form`) VALUES ('Schedule A');
/*!40000 ALTER TABLE `tax_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tax_form_line`
--

DROP TABLE IF EXISTS `tax_form_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tax_form_line` (
  `tax_form` char(20) NOT NULL,
  `tax_form_line` char(5) NOT NULL,
  `tax_form_description` char(40) DEFAULT NULL,
  UNIQUE KEY `tax_form_line` (`tax_form`,`tax_form_line`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tax_form_line`
--

LOCK TABLES `tax_form_line` WRITE;
/*!40000 ALTER TABLE `tax_form_line` DISABLE KEYS */;
INSERT INTO `tax_form_line` (`tax_form`, `tax_form_line`, `tax_form_description`) VALUES ('Schedule A','5a','Real estate taxes');
INSERT INTO `tax_form_line` (`tax_form`, `tax_form_line`, `tax_form_description`) VALUES ('Schedule A','11','Gifts by cash or check');
INSERT INTO `tax_form_line` (`tax_form`, `tax_form_line`, `tax_form_description`) VALUES ('8829','17','Real estate taxes');
INSERT INTO `tax_form_line` (`tax_form`, `tax_form_line`, `tax_form_description`) VALUES ('8829','18','Insurance');
INSERT INTO `tax_form_line` (`tax_form`, `tax_form_line`, `tax_form_description`) VALUES ('8829','21','Utilities');
INSERT INTO `tax_form_line` (`tax_form`, `tax_form_line`, `tax_form_description`) VALUES ('1040','29','Self-employed health insurance deduction');
INSERT INTO `tax_form_line` (`tax_form`, `tax_form_line`, `tax_form_description`) VALUES ('Schedule A','1','Medical and dental expenses');
/*!40000 ALTER TABLE `tax_form_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tax_form_line_account`
--

DROP TABLE IF EXISTS `tax_form_line_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tax_form_line_account` (
  `tax_form` char(20) NOT NULL,
  `tax_form_line` char(5) NOT NULL,
  `account` char(60) NOT NULL,
  UNIQUE KEY `tax_form_line_account` (`tax_form`,`tax_form_line`,`account`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tax_form_line_account`
--

LOCK TABLES `tax_form_line_account` WRITE;
/*!40000 ALTER TABLE `tax_form_line_account` DISABLE KEYS */;
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('8829','17','property_tax');
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('8829','18','Flood Insurance');
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('8829','18','Home Insurance');
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('8829','21','Alarm');
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('8829','21','alarm_permit');
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('8829','21','city_utility_tax');
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('8829','21','Garbage/Water');
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('8829','21','Sewage');
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('Schedule A','1','Dental');
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('Schedule A','1','Healthcare consumption');
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('Schedule A','11','donation_cash');
INSERT INTO `tax_form_line_account` (`tax_form`, `tax_form_line`, `account`) VALUES ('Schedule A','5a','property_tax');
/*!40000 ALTER TABLE `tax_form_line_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction` (
  `full_name` char(60) NOT NULL,
  `street_address` char(60) DEFAULT NULL,
  `transaction_date_time` datetime NOT NULL,
  `memo` char(60) DEFAULT NULL,
  `transaction_amount` double(10,2) DEFAULT NULL,
  `check_number` int DEFAULT NULL,
  UNIQUE KEY `transaction_additional_unique` (`transaction_date_time`),
  UNIQUE KEY `transaction` (`full_name`,`street_address`,`transaction_date_time`),
  UNIQUE KEY `transaction_check_number` (`check_number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction`
--

LOCK TABLES `transaction` WRITE;
/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-25 21:53:51
insert into process (process,command_line,notepad,html_help_file_anchor,execution_count,post_change_javascript,process_group,process_set_display,javascript_filename,preprompt_help_text) values ('account_balance','account_balance.sh \$process as_of_date full_name street_address investment_purpose execute_yn',null,null,null,null,'output',null,null,null);
insert into role_process (role,process) values ('supervisor','account_balance');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('account_balance','financial_institution','null','null','null','2',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('account_balance','investment_purpose','null','null','null','3',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('account_balance','null','null','null','as_of_date','1',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('account_balance','null','null','null','execute_yn','9',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('as_of_date',null,null,'y','10');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('execute_yn','Omit execute for display.',null,null,'1');
insert into process_group (process_group) values ('output');
insert into process (process,command_line,notepad,html_help_file_anchor,execution_count,post_change_javascript,process_group,process_set_display,javascript_filename,preprompt_help_text) values ('appaserver_info','appaserver_info.sh \$process',null,null,null,null,'view',null,null,null);
insert into role_process (role,process) values ('supervisor','appaserver_info');
insert into role_process (role,process) values ('system','appaserver_info');
insert into process_group (process_group) values ('view');
insert into process (process,command_line,notepad,html_help_file_anchor,execution_count,post_change_javascript,process_group,process_set_display,javascript_filename,preprompt_help_text) values ('budget_report','budget_report \$process as_of_date output_medium',null,null,null,null,'output',null,null,null);
insert into role_process (role,process) values ('supervisor','budget_report');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('budget_report','null','null','null','as_of_date','1',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('budget_report','null','null','output_medium','null','2',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('as_of_date',null,null,'y','10');
insert into drop_down_prompt (drop_down_prompt,hint_message,optional_display) values ('output_medium',null,null);
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('output_medium','PDF','2');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('output_medium','spreadsheet','3');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('output_medium','table','1');
insert into process_group (process_group) values ('output');
insert into process (process,command_line,notepad,html_help_file_anchor,execution_count,post_change_javascript,process_group,process_set_display,javascript_filename,preprompt_help_text) values ('change_password','change_password \$session \$login_name \$role \$process',null,null,null,null,'alter',null,null,null);
insert into role_process (role,process) values ('supervisor','change_password');
insert into role_process (role,process) values ('system','change_password');
insert into process_group (process_group) values ('alter');
insert into process (process,command_line,notepad,html_help_file_anchor,execution_count,post_change_javascript,process_group,process_set_display,javascript_filename,preprompt_help_text) values ('close_nominal_accounts','close_nominal_accounts \$process as_of_date undo_yn execute_yn',null,null,null,'post_change_close_nominal_accounts()','alter',null,'post_change_close_nominal_accounts.js',null);
insert into role_process (role,process) values ('supervisor','close_nominal_accounts');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('close_nominal_accounts','null','null','null','as_of_date','1',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('close_nominal_accounts','null','null','null','execute_yn','9',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('close_nominal_accounts','null','null','null','undo_yn','2',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('as_of_date',null,null,'y','10');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('execute_yn','Omit execute for display.',null,null,'1');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('undo_yn',null,null,null,'1');
insert into process_group (process_group) values ('alter');
insert into process (process,command_line,notepad,html_help_file_anchor,execution_count,post_change_javascript,process_group,process_set_display,javascript_filename,preprompt_help_text) values ('execute_select_statement','execute_select_statement \$process \$session \$role select_statement_title login_name statement',null,null,null,null,'output',null,null,null);
insert into role_process (role,process) values ('supervisor','execute_select_statement');
insert into role_process (role,process) values ('system','execute_select_statement');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('execute_select_statement','null','null','null','statement','2',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('execute_select_statement','select_statement','null','null','null','1',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('statement',null,null,null,'2048');
insert into process_group (process_group) values ('output');
insert into process (process,command_line,notepad,html_help_file_anchor,execution_count,post_change_javascript,process_group,process_set_display,javascript_filename,preprompt_help_text) values ('feeder_journal_orphan_audit','feeder_journal_orphan_audit.sh \$process feeder_account minimum_transaction_date',null,null,null,null,'reconcile',null,null,null);
insert into role_process (role,process) values ('supervisor','feeder_journal_orphan_audit');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('feeder_journal_orphan_audit','feeder_account','null','null','null','1',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('feeder_journal_orphan_audit','null','null','null','minimum_transaction_date','1',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('minimum_transaction_date',null,null,'y','10');
insert into process_group (process_group) values ('reconcile');
insert into process (process,command_line,notepad,html_help_file_anchor,execution_count,post_change_javascript,process_group,process_set_display,javascript_filename,preprompt_help_text) values ('feeder_row_journal_audit','feeder_row_journal_audit.sh \$process feeder_account minimum_transaction_date',null,null,null,null,'reconcile',null,null,null);
insert into role_process (role,process) values ('supervisor','feeder_row_journal_audit');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('feeder_row_journal_audit','feeder_account','null','null','null','1',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('feeder_row_journal_audit','null','null','null','minimum_transaction_date','1',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('minimum_transaction_date',null,null,'y','10');
insert into process_group (process_group) values ('reconcile');
insert into process (process,command_line,notepad,html_help_file_anchor,execution_count,post_change_javascript,process_group,process_set_display,javascript_filename,preprompt_help_text) values ('financial_position','financial_position \$session \$login_name \$role \$process as_of_date prior_year_count subclassification_option output_medium',null,null,null,null,'output',null,null,null);
insert into role_process (role,process) values ('supervisor','financial_position');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('financial_position','null','null','finance_output_medium','null','9',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('financial_position','null','null','null','as_of_date','1',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('financial_position','null','null','null','prior_year_count','2',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('financial_position','null','null','subclassification_option','null','3',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('as_of_date',null,null,'y','10');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('prior_year_count',null,null,null,'3');
insert into drop_down_prompt (drop_down_prompt,hint_message,optional_display) values ('finance_output_medium',null,'output_medium');
insert into drop_down_prompt (drop_down_prompt,hint_message,optional_display) values ('subclassification_option',null,null);
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('finance_output_medium','PDF','2');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('finance_output_medium','table','1');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('subclassification_option','aggregate','2');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('subclassification_option','display','1');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('subclassification_option','omit','3');
insert into process_group (process_group) values ('output');
insert into process (process,command_line,notepad,html_help_file_anchor,execution_count,post_change_javascript,process_group,process_set_display,javascript_filename,preprompt_help_text) values ('import_predictbooks','import_predictbooks \$process full_name name_of_bank checking_begin_date checking_begin_balance execute_yn','This process imports the PredictBooks home edition.',null,null,'post_change_import_predictbooks()','alter',null,'post_change_import_predictbooks.js',null);
insert into role_process (role,process) values ('supervisor','import_predictbooks');
insert into role_process (role,process) values ('system','import_predictbooks');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('import_predictbooks','financial_institution','null','null','null','1',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('import_predictbooks','null','null','null','checking_begin_balance','4',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('import_predictbooks','null','null','null','checking_begin_date','3',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('import_predictbooks','null','null','null','execute_yn','5',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('import_predictbooks','null','null','null','name_of_bank','2',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('checking_begin_balance','<ol><li>Enter the earliest checking account balance from your bank\'s website.<li>Download all of your checking transactions from your bank.<li>Execute the soon to be installed checking upload process.</ol>',null,null,'14');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('checking_begin_date',null,null,'y','10');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('execute_yn','Omit execute for display.',null,null,'1');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('name_of_bank','Enter the name of your bank if it\'s not in the list above.',null,null,'30');
insert into process_group (process_group) values ('alter');
insert into process (process,command_line,notepad,html_help_file_anchor,execution_count,post_change_javascript,process_group,process_set_display,javascript_filename,preprompt_help_text) values ('insert_cash_expense_transaction','insert_cash_transaction.sh \$process full_name street_address transaction_date account transaction_amount check_number memo program_name',null,null,null,'post_change_insert_cash_transaction( this )','reconcile',null,'post_change_insert_cash_transaction.js',null);
insert into role_process (role,process) values ('supervisor','insert_cash_expense_transaction');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('insert_cash_expense_transaction','account','null','null','null','5',null,null,'populate_expense_account',null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('insert_cash_expense_transaction','entity','null','null','null','1',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('insert_cash_expense_transaction','null','null','null','check_number','8',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('insert_cash_expense_transaction','null','null','null','full_name','2',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('insert_cash_expense_transaction','null','null','null','memo','9',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('insert_cash_expense_transaction','null','null','null','street_address','3',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('insert_cash_expense_transaction','null','null','null','transaction_amount','7',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('insert_cash_expense_transaction','null','null','null','transaction_date','6',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('check_number',null,null,null,'10');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('full_name',null,null,null,'60');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('memo',null,null,null,'60');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('street_address',null,null,null,'60');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('transaction_amount',null,null,null,'10');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('transaction_date',null,null,'y','10');
insert into process_group (process_group) values ('reconcile');
insert into process (process,command_line) values ('populate_expense_account','populate_expense_account.sh');
insert into process (process,command_line,notepad,html_help_file_anchor,execution_count,post_change_javascript,process_group,process_set_display,javascript_filename,preprompt_help_text) values ('ledger_debit_credit_audit','ledger_debit_credit_audit.sh \$process minimum_transaction_date delete_no_journal_yn',null,null,null,null,'reconcile',null,null,null);
insert into role_process (role,process) values ('supervisor','ledger_debit_credit_audit');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('ledger_debit_credit_audit','null','null','null','delete_no_journal_yn','2',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('ledger_debit_credit_audit','null','null','null','minimum_transaction_date','1',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('delete_no_journal_yn',null,null,null,'1');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('minimum_transaction_date',null,null,'y','10');
insert into process_group (process_group) values ('reconcile');
insert into process (process,command_line,notepad,html_help_file_anchor,execution_count,post_change_javascript,process_group,process_set_display,javascript_filename,preprompt_help_text) values ('ledger_propagate','ledger_propagate.sh \$process',null,null,null,null,'reconcile',null,null,null);
insert into role_process (role,process) values ('supervisor','ledger_propagate');
insert into process_group (process_group) values ('reconcile');
insert into process (process,command_line,notepad,html_help_file_anchor,execution_count,post_change_javascript,process_group,process_set_display,javascript_filename,preprompt_help_text) values ('merge_purge','merge_purge \$session \$login_name \$role \$process','This process allows you to remove duplicate rows. It may be that two rows should really be one row because a spelling is slightly different in one of them.',null,'5',null,'alter',null,null,null);
insert into role_process (role,process) values ('supervisor','merge_purge');
insert into role_process (role,process) values ('system','merge_purge');
insert into process_group (process_group) values ('alter');
insert into process (process,command_line,notepad,html_help_file_anchor,execution_count,post_change_javascript,process_group,process_set_display,javascript_filename,preprompt_help_text) values ('pay_liabilities','pay_liabilities_process \$process \$session full_name street_address starting_check_number memo payment_amount execute_yn','<h2>Print Checks</h2><ol><li>Open in Evince (Also called \'Document Viewer\')<li>Papersize width = 8.5 inches<li>Papersize height = 3 inches<li>Orientation = Portrait<li>Page order = Back to front<li>Reverse = Yes<li>Place first check face down on white paper<li>Print the checks<li>Print a blank page to eject the last check</ol>',null,null,'post_change_pay_liabilities( this )','alter',null,'post_change_pay_liabilities.js',null);
insert into role_process (role,process) values ('supervisor','pay_liabilities');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('pay_liabilities','entity','null','null','null','1','y',null,'populate_print_checks_entity',null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('pay_liabilities','null','null','null','execute_yn','9',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('pay_liabilities','null','null','null','memo','4',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('pay_liabilities','null','null','null','payment_amount','3',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('pay_liabilities','null','null','null','starting_check_number','2',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('execute_yn','Omit execute for display.',null,null,'1');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('memo',null,null,null,'60');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('payment_amount',null,null,null,'10');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('starting_check_number',null,null,null,'5');
insert into process_group (process_group) values ('alter');
insert into process (process,command_line) values ('populate_print_checks_entity','populate_print_checks_entity');
insert into process (process,command_line,notepad,html_help_file_anchor,execution_count,post_change_javascript,process_group,process_set_display,javascript_filename,preprompt_help_text) values ('statement_of_activities','statement_of_activities \$session \$login_name \$role \$process as_of_date prior_year_count  subclassification_option output_medium',null,null,null,null,'output',null,null,null);
insert into role_process (role,process) values ('supervisor','statement_of_activities');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('statement_of_activities','null','null','finance_output_medium','null','9',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('statement_of_activities','null','null','null','as_of_date','1',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('statement_of_activities','null','null','null','prior_year_count','2',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('statement_of_activities','null','null','subclassification_option','null','3',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('as_of_date',null,null,'y','10');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('prior_year_count',null,null,null,'3');
insert into drop_down_prompt (drop_down_prompt,hint_message,optional_display) values ('finance_output_medium',null,'output_medium');
insert into drop_down_prompt (drop_down_prompt,hint_message,optional_display) values ('subclassification_option',null,null);
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('finance_output_medium','PDF','2');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('finance_output_medium','table','1');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('subclassification_option','aggregate','2');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('subclassification_option','display','1');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('subclassification_option','omit','3');
insert into process_group (process_group) values ('output');
insert into process (process,command_line,notepad,html_help_file_anchor,execution_count,post_change_javascript,process_group,process_set_display,javascript_filename,preprompt_help_text) values ('tax_form_report','tax_form_report \$process tax_form tax_year 0 output_medium',null,null,null,null,'output',null,null,null);
insert into role_process (role,process) values ('supervisor','tax_form_report');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('tax_form_report','null','null','null','tax_year','2',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('tax_form_report','null','null','tax_report_output_medium','null','9',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('tax_form_report','tax_form','null','null','null','1',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('tax_year',null,null,null,'4');
insert into drop_down_prompt (drop_down_prompt,hint_message,optional_display) values ('tax_report_output_medium',null,'output_medium');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('tax_report_output_medium','PDF','2');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('tax_report_output_medium','table','1');
insert into process_group (process_group) values ('output');
insert into process (process,command_line,notepad,html_help_file_anchor,execution_count,post_change_javascript,process_group,process_set_display,javascript_filename,preprompt_help_text) values ('trial_balance','trial_balance_output \$session \$login_name \$role \$process as_of_date prior_year_count subclassification_option output_medium',null,null,null,null,'output',null,null,null);
insert into role_process (role,process) values ('supervisor','trial_balance');
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('trial_balance','null','null','finance_output_medium','null','9',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('trial_balance','null','null','null','as_of_date','1',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('trial_balance','null','null','null','prior_year_count','2',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('trial_balance','null','null','trial_balance_subclassification_option','null','3',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('as_of_date',null,null,'y','10');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('prior_year_count',null,null,null,'3');
insert into drop_down_prompt (drop_down_prompt,hint_message,optional_display) values ('finance_output_medium',null,'output_medium');
insert into drop_down_prompt (drop_down_prompt,hint_message,optional_display) values ('trial_balance_subclassification_option',null,'subclassification_option');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('finance_output_medium','PDF','2');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('finance_output_medium','table','1');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('trial_balance_subclassification_option','display','1');
insert into drop_down_prompt_data (drop_down_prompt,drop_down_prompt_data,display_order) values ('trial_balance_subclassification_option','omit','2');
insert into process_group (process_group) values ('output');
insert into process (process,command_line,notepad,html_help_file_anchor,execution_count,post_change_javascript,process_group,process_set_display,javascript_filename,preprompt_help_text) values ('BofA_checking_upload','feeder_load \$process \$login_name checking filename 1 2 3 0 4 0 reverse_order_yn account_end_balance execute_yn','<h3>Input format:</h3><table border=1><tr><th>Date<th>Description<th>Amount<th>Running Bal.</table><p>The bank\'s begin date will display if you submit this form without a file. Use \'Final Feeder Date\' as the begin date.',null,'42',null,'reconcile',null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('BofA_checking_upload','null','null','null','execute_yn','9',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('BofA_checking_upload','null','null','null','filename','1',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('execute_yn','Omit execute for display.',null,null,'1');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('filename',null,'y',null,'100');
insert into process_group (process_group) values ('reconcile');
insert into process (process,command_line,notepad,html_help_file_anchor,execution_count,post_change_javascript,process_group,process_set_display,javascript_filename,preprompt_help_text) values ('chase_checking_upload','feeder_load \$process \$login_name checking filename 2 3 4 0 6 0 y account_end_balance execute_yn','<h3>Input format:</h3><table border=1><tr><th>Details<th>Posting Date<th>Description<th>Amount<th>Type<th>Balance<th>Check or Slip #<tr><td><td>Descending</table><p>The bank\'s begin date will display if you submit this form without a file. Use \'Final Feeder Date\' as the begin date.',null,null,null,'reconcile',null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('chase_checking_upload','null','null','null','execute_yn','2',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('chase_checking_upload','null','null','null','filename','1',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('execute_yn','Omit execute for display.',null,null,'1');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('filename',null,'y',null,'100');
insert into process_group (process_group) values ('reconcile');
insert into process (process,command_line,notepad,html_help_file_anchor,execution_count,post_change_javascript,process_group,process_set_display,javascript_filename,preprompt_help_text) values ('generic_checking_upload','feeder_load \$process \$login_name checking filename 1 2 3 0 4 0 reverse_order_yn account_end_balance execute_yn','<h3>Input format:</h3><table border=1><tr><th>Date<th>Description<th>Amount<th>Running Balance</table><p>The bank\'s begin date will display if you submit this form without a file. Use \'Final Feeder Date\' as the begin date.',null,null,null,'reconcile',null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('generic_checking_upload','null','null','null','execute_yn','2',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('generic_checking_upload','null','null','null','filename','1',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('execute_yn','Omit execute for display.',null,null,'1');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('filename',null,'y',null,'100');
insert into process_group (process_group) values ('reconcile');
insert into process (process,command_line,notepad,html_help_file_anchor,execution_count,post_change_javascript,process_group,process_set_display,javascript_filename,preprompt_help_text) values ('BofA_credit_upload','feeder_load \$process \$login_name bank_of_america_credit_card filename 1 3 5 0 0 2 y account_end_balance execute_yn','<h3>Input format:</h3><table border=1><tr><th>Posted Date<th>Reference Number<th>Payee<th>Address<th>Amount<tr><td>Descending</table><ul><li>The current-month file may have a description that will change when BofA posts that transaction to the corresponding full-month file. Therefore, if a current-month file is loaded, then delete the Feeder Load Event of that file before uploading the corresponding full-month file.<li>The bank\'s begin date will display if you submit this form without a file. Use \'Final Feeder Date\' as the begin date.</ul>',null,'37',null,'reconcile',null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('BofA_credit_upload','null','null','null','account_end_balance','2',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('BofA_credit_upload','null','null','null','execute_yn','9',null,null,null,null);
insert into process_parameter (process,table_name,column_name,drop_down_prompt,prompt,display_order,drop_down_multi_select_yn,drillthru_yn,populate_drop_down_process,populate_helper_process) values ('BofA_credit_upload','null','null','null','filename','1',null,null,null,null);
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('account_end_balance',null,null,null,'10');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('execute_yn','Omit execute for display.',null,null,'1');
insert into prompt (prompt,hint_message,upload_filename_yn,date_yn,input_width) values ('filename',null,'y',null,'100');
insert into process_group (process_group) values ('reconcile');
insert into appaserver_table (table_name,form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,lookup_email_output_yn,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('account','prompt','5','PB&J','populate_account',null,null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('account','subclassification','null',null,null,null,null,null,null,null,null,'y',null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('feeder_account','account','feeder_account',null,null,null,'y',null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('feeder_phrase','account','nominal_account',null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('journal','account','null',null,null,null,null,null,null,'y',null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('prior_fixed_asset','account','asset_account',null,null,null,null,null,null,null,null,null,'y',null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('tax_form_line_account','account','null',null,null,null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('account','account','1',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('account','annual_budget',null,'5',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('account','hard_coded_account_key',null,'3',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('account','subclassification',null,'1',null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('account','text','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('annual_budget','integer','7',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('hard_coded_account_key','text','40',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('subclassification','text','35',null,null);
insert into table_operation (table_name,role,operation) values ('account','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('account','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row $session $login_name $role $folder $primary_data_list n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown $session $login_name $role $target_frame $folder $primary_data_list $update_results $update_error $dictionary');
insert into table_operation (table_name,role,operation) values ('account','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('account','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','account','insert');
insert into role_table (role,table_name,permission) values ('supervisor','account','update');
insert into process (process,command_line) values ('populate_account','populate_account.sh $many_table subclassification');
insert into appaserver_table (table_name,form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,lookup_email_output_yn,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('account_balance','prompt','5','investment',null,'post_change_account_balance',null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('account_balance','investment_account','null',null,null,null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('account_balance','account_number','3',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('account_balance','balance',null,'2',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('account_balance','balance_change',null,'3',null,'y',null,null,'y',null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('account_balance','balance_change_percent',null,'3',null,'y',null,null,'y',null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('account_balance','date','4',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('account_balance','full_name','1',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('account_balance','street_address','2',null,null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('account_number','text','50',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('balance','float','11','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('balance_change','float','11','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('balance_change_percent','integer','3',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('date','current_date','10',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('full_name','text','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('street_address','text','60',null,null);
insert into table_operation (table_name,role,operation) values ('account_balance','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('account_balance','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row $session $login_name $role $folder $primary_data_list n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown $session $login_name $role $target_frame $folder $primary_data_list $update_results $update_error $dictionary');
insert into table_operation (table_name,role,operation) values ('account_balance','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('account_balance','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','account_balance','insert');
insert into role_table (role,table_name,permission) values ('supervisor','account_balance','update');
insert into process (process,command_line) values ('post_change_account_balance','post_change_account_balance full_name street_address account_number date $state');
insert into appaserver_table (table_name,form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,lookup_email_output_yn,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('element','table','5','PB&J',null,null,null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('subclassification','element','null',null,null,null,null,null,null,'y',null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('element','accumulate_debit_yn',null,'1',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('element','element','1',null,null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('accumulate_debit_yn','text','1',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('element','text','20',null,null);
insert into table_operation (table_name,role,operation) values ('element','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('element','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row $session $login_name $role $folder $primary_data_list n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown $session $login_name $role $target_frame $folder $primary_data_list $update_results $update_error $dictionary');
insert into table_operation (table_name,role,operation) values ('element','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('element','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','element','lookup');
insert into appaserver_table (table_name,form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,lookup_email_output_yn,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('feeder_account','table','5','feeder',null,null,null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('feeder_account','account','feeder_account',null,null,null,'y',null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('feeder_load_event','feeder_account','null',null,null,null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_account','feeder_account','1',null,null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('feeder_account','text','30',null,'External accounts like credit card and Pay Pal that feed in transactions.');
insert into table_operation (table_name,role,operation) values ('feeder_account','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('feeder_account','supervisor','delete_isa_only');
insert into table_operation (table_name,role,operation) values ('feeder_account','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row $session $login_name $role $folder $primary_data_list n');
insert into operation (operation,output_yn) values ('delete_isa_only','n');
insert into process (process,command_line) values ('delete_isa_only','delete_folder_row $session $login_name $role $folder $primary_data_list y');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown $session $login_name $role $target_frame $folder $primary_data_list $update_results $update_error $dictionary');
insert into table_operation (table_name,role,operation) values ('feeder_account','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('feeder_account','supervisor','delete_isa_only');
insert into table_operation (table_name,role,operation) values ('feeder_account','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','feeder_account','insert');
insert into role_table (role,table_name,permission) values ('supervisor','feeder_account','update');
insert into appaserver_table (table_name,form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,lookup_email_output_yn,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('feeder_load_event','prompt','5','feeder',null,null,null,'y',null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('feeder_load_event','appaserver_user','null',null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('feeder_load_event','feeder_account','null',null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('feeder_row','feeder_load_event','null',null,null,null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_load_event','account_end_balance',null,'4',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_load_event','account_end_date',null,'3',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_load_event','feeder_account','1',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_load_event','feeder_load_date_time','2',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_load_event','feeder_load_filename',null,'2',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_load_event','login_name',null,'1',null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('account_end_balance','float','12','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('account_end_date','date','10',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('feeder_account','text','30',null,'External accounts like credit card and Pay Pal that feed in transactions.');
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('feeder_load_date_time','date_time','19',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('feeder_load_filename','upload_file','80',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('login_name','text','50',null,null);
insert into table_operation (table_name,role,operation) values ('feeder_load_event','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('feeder_load_event','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row $session $login_name $role $folder $primary_data_list n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown $session $login_name $role $target_frame $folder $primary_data_list $update_results $update_error $dictionary');
insert into table_operation (table_name,role,operation) values ('feeder_load_event','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('feeder_load_event','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','feeder_load_event','update');
insert into appaserver_table (table_name,form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,lookup_email_output_yn,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('feeder_phrase','prompt','5','feeder',null,null,null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('feeder_phrase','account','nominal_account',null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('feeder_phrase','entity','null',null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('feeder_row','feeder_phrase','null',null,null,null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_phrase','feeder_phrase','1',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_phrase','full_name',null,'2',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_phrase','nominal_account',null,'1',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_phrase','street_address',null,'3',null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('feeder_phrase','text','80',null,'Separate multiple phrases with a comma.');
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('full_name','text','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('nominal_account','text','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('street_address','text','60',null,null);
insert into table_operation (table_name,role,operation) values ('feeder_phrase','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('feeder_phrase','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row $session $login_name $role $folder $primary_data_list n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown $session $login_name $role $target_frame $folder $primary_data_list $update_results $update_error $dictionary');
insert into table_operation (table_name,role,operation) values ('feeder_phrase','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('feeder_phrase','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','feeder_phrase','insert');
insert into role_table (role,table_name,permission) values ('supervisor','feeder_phrase','update');
insert into appaserver_table (table_name,form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,lookup_email_output_yn,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('feeder_row','prompt','5','feeder',null,null,null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('feeder_row','feeder_load_event','null',null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('feeder_row','feeder_phrase','null',null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('feeder_row','journal','null',null,'n',null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_row','calculate_balance',null,'8',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_row','check_number',null,'9',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_row','feeder_account','1',null,null,null,'y',null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_row','feeder_date',null,'1',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_row','feeder_load_date_time','2',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_row','feeder_phrase',null,'10',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_row','feeder_row_number','3',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_row','file_row_amount',null,'6',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_row','file_row_balance',null,'7',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_row','file_row_description',null,'5',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_row','full_name',null,'2',null,null,'y',null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_row','street_address',null,'3',null,null,'y',null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('feeder_row','transaction_date_time',null,'4',null,null,'y',null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('calculate_balance','float','12','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('check_number','integer','6',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('feeder_account','text','30',null,'External accounts like credit card and Pay Pal that feed in transactions.');
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('feeder_date','date','10',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('feeder_load_date_time','date_time','19',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('feeder_phrase','text','80',null,'Separate multiple phrases with a comma.');
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('feeder_row_number','integer','5',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('file_row_amount','float','12','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('file_row_balance','float','12','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('file_row_description','text','140',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('full_name','text','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('street_address','text','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('transaction_date_time','current_date_time','19',null,'Must be unique throughout all transactions.');
insert into table_operation (table_name,role,operation) values ('feeder_row','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('feeder_row','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row $session $login_name $role $folder $primary_data_list n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown $session $login_name $role $target_frame $folder $primary_data_list $update_results $update_error $dictionary');
insert into table_operation (table_name,role,operation) values ('feeder_row','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('feeder_row','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','feeder_row','update');
insert into foreign_column (table_name,related_table,related_column,foreign_column,foreign_key_index) values ('feeder_row','journal','null','feeder_account','4');
insert into foreign_column (table_name,related_table,related_column,foreign_column,foreign_key_index) values ('feeder_row','journal','null','full_name','1');
insert into foreign_column (table_name,related_table,related_column,foreign_column,foreign_key_index) values ('feeder_row','journal','null','street_address','2');
insert into foreign_column (table_name,related_table,related_column,foreign_column,foreign_key_index) values ('feeder_row','journal','null','transaction_date_time','3');
insert into appaserver_table (table_name,form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,lookup_email_output_yn,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('financial_institution','prompt','5','entity',null,null,null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('financial_institution','entity','null',null,null,null,'y',null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('investment_account','financial_institution','null',null,null,null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('financial_institution','full_name','1',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('financial_institution','street_address','2',null,null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('full_name','text','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('street_address','text','60',null,null);
insert into table_operation (table_name,role,operation) values ('financial_institution','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('financial_institution','supervisor','delete_isa_only');
insert into table_operation (table_name,role,operation) values ('financial_institution','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row $session $login_name $role $folder $primary_data_list n');
insert into operation (operation,output_yn) values ('delete_isa_only','n');
insert into process (process,command_line) values ('delete_isa_only','delete_folder_row $session $login_name $role $folder $primary_data_list y');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown $session $login_name $role $target_frame $folder $primary_data_list $update_results $update_error $dictionary');
insert into table_operation (table_name,role,operation) values ('financial_institution','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('financial_institution','supervisor','delete_isa_only');
insert into table_operation (table_name,role,operation) values ('financial_institution','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','financial_institution','insert');
insert into role_table (role,table_name,permission) values ('supervisor','financial_institution','update');
insert into appaserver_table (table_name,form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,lookup_email_output_yn,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('investment_account','prompt','5','investment','populate_investment_account',null,'post_change_investment_account( $row )','y',null,null,null,null,null,null,null,null,'post_change_investment_account.js',null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('investment_account','financial_institution','null',null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('investment_account','investment_classification','null',null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('investment_account','investment_purpose','null',null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('account_balance','investment_account','null',null,null,null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('investment_account','account_number','3',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('investment_account','balance_latest',null,'1',null,'y',null,null,'y',null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('investment_account','certificate_maturity_date',null,'5',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('investment_account','certificate_maturity_months',null,'4',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('investment_account','full_name','1',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('investment_account','interest_rate',null,'6',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('investment_account','investment_classification',null,'2',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('investment_account','investment_purpose',null,'3',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('investment_account','street_address','2',null,null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('account_number','text','50',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('balance_latest','float','14','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('certificate_maturity_date','date','11',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('certificate_maturity_months','integer','3',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('full_name','text','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('interest_rate','float','5','2','0.0 rate < 10.0');
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('investment_classification','text','15',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('investment_purpose','text','30',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('street_address','text','60',null,null);
insert into table_operation (table_name,role,operation) values ('investment_account','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('investment_account','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row $session $login_name $role $folder $primary_data_list n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown $session $login_name $role $target_frame $folder $primary_data_list $update_results $update_error $dictionary');
insert into table_operation (table_name,role,operation) values ('investment_account','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('investment_account','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','investment_account','insert');
insert into role_table (role,table_name,permission) values ('supervisor','investment_account','update');
insert into process (process,command_line) values ('populate_investment_account','populate_investment_account.sh $where');
insert into appaserver_table (table_name,form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,lookup_email_output_yn,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('investment_classification','table','5','investment',null,null,null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('investment_account','investment_classification','null',null,null,null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('investment_classification','investment_classification','1',null,null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('investment_classification','text','15',null,null);
insert into table_operation (table_name,role,operation) values ('investment_classification','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('investment_classification','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row $session $login_name $role $folder $primary_data_list n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown $session $login_name $role $target_frame $folder $primary_data_list $update_results $update_error $dictionary');
insert into table_operation (table_name,role,operation) values ('investment_classification','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('investment_classification','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','investment_classification','insert');
insert into role_table (role,table_name,permission) values ('supervisor','investment_classification','update');
insert into appaserver_table (table_name,form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,lookup_email_output_yn,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('investment_purpose','table','5','investment',null,null,null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('investment_account','investment_purpose','null',null,null,null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('investment_purpose','investment_purpose','1',null,null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('investment_purpose','text','30',null,null);
insert into table_operation (table_name,role,operation) values ('investment_purpose','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('investment_purpose','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row $session $login_name $role $folder $primary_data_list n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown $session $login_name $role $target_frame $folder $primary_data_list $update_results $update_error $dictionary');
insert into table_operation (table_name,role,operation) values ('investment_purpose','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('investment_purpose','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','investment_purpose','insert');
insert into role_table (role,table_name,permission) values ('supervisor','investment_purpose','update');
insert into appaserver_table (table_name,form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,lookup_email_output_yn,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('journal','prompt','10','PB&J',null,'post_change_journal_ledger','post_change_journal_ledger( \'$state\' )','y','<table border=1><tr><th>Total Debit</th><th>=</th><th>Total Credit</th><tr><th>Asset</th><th>=</th><th>Liability + Equity</th><tr><td>Asset, Expense, Loss<td><td>Liability, Revenue, Equity, Gain</table>',null,null,null,null,null,null,null,'post_change_journal_ledger.js',null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('journal','account','null',null,null,null,null,null,null,'y',null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('journal','transaction','null','1',null,null,null,null,null,'n','y',null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('feeder_row','journal','null',null,'n',null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('journal','account','4',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('journal','balance',null,'10','y','y',null,null,'y',null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('journal','credit_amount',null,'9',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('journal','debit_amount',null,'8',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('journal','full_name','1',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('journal','previous_balance',null,'7','y','y',null,null,'y',null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('journal','street_address','2',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('journal','transaction_date_time','3',null,null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('account','text','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('balance','float','11','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('credit_amount','float','10','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('debit_amount','float','10','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('full_name','text','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('previous_balance','float','10','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('street_address','text','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('transaction_date_time','current_date_time','19',null,'Must be unique throughout all transactions.');
insert into table_operation (table_name,role,operation) values ('journal','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('journal','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row $session $login_name $role $folder $primary_data_list n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown $session $login_name $role $target_frame $folder $primary_data_list $update_results $update_error $dictionary');
insert into table_operation (table_name,role,operation) values ('journal','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('journal','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','journal','insert');
insert into role_table (role,table_name,permission) values ('supervisor','journal','update');
insert into process (process,command_line) values ('post_change_journal_ledger','journal_trigger full_name street_address transaction_date_time account debit_amount credit_amount $state preupdate_transaction_date_time preupdate_account preupdate_debit_amount preupdate_credit_amount');
insert into appaserver_table (table_name,form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,lookup_email_output_yn,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('prior_fixed_asset','prompt','5','PB&J',null,'prior_fixed_asset_trigger',null,null,'Fixed asset inventory acquired prior to using PredictBooks.',null,null,null,null,null,null,null,'post_change_fixed_asset_purchase.js',null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('prior_fixed_asset','account','asset_account',null,null,null,null,null,null,null,null,null,'y',null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('prior_fixed_asset','entity','null',null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('prior_fixed_asset','transaction','purchase_date_time',null,null,null,null,null,null,null,null,null,null,'y',null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('prior_fixed_asset','asset_account',null,'5',null,'n',null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('prior_fixed_asset','asset_name','1',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('prior_fixed_asset','fixed_asset_cost',null,'4',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('prior_fixed_asset','full_name',null,'1',null,null,null,'n',null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('prior_fixed_asset','purchase_date_time',null,'3',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('prior_fixed_asset','street_address',null,'2',null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('asset_account','text','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('asset_name','text','40',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('fixed_asset_cost','float','12','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('full_name','text','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('purchase_date_time','current_date_time','19',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('street_address','text','60',null,null);
insert into table_operation (table_name,role,operation) values ('prior_fixed_asset','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('prior_fixed_asset','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row $session $login_name $role $folder $primary_data_list n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown $session $login_name $role $target_frame $folder $primary_data_list $update_results $update_error $dictionary');
insert into table_operation (table_name,role,operation) values ('prior_fixed_asset','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('prior_fixed_asset','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','prior_fixed_asset','insert');
insert into role_table (role,table_name,permission) values ('supervisor','prior_fixed_asset','update');
insert into process (process,command_line) values ('prior_fixed_asset_trigger','prior_fixed_asset_trigger asset_name $state preupdate_full_name preupdate_street_address preupdate_purchase_date_time preupdate_fixed_asset_cost preupdate_asset_account');
insert into appaserver_table (table_name,form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,lookup_email_output_yn,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('subclassification','prompt','5','PB&J',null,null,null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('subclassification','element','null',null,null,null,null,null,null,'y',null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('account','subclassification','null',null,null,null,null,null,null,null,null,'y',null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('subclassification','display_order',null,'2',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('subclassification','element',null,'1',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('subclassification','subclassification','1',null,null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('display_order','integer','3',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('element','text','20',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('subclassification','text','35',null,null);
insert into table_operation (table_name,role,operation) values ('subclassification','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('subclassification','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row $session $login_name $role $folder $primary_data_list n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown $session $login_name $role $target_frame $folder $primary_data_list $update_results $update_error $dictionary');
insert into table_operation (table_name,role,operation) values ('subclassification','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('subclassification','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','subclassification','insert');
insert into role_table (role,table_name,permission) values ('supervisor','subclassification','update');
insert into appaserver_table (table_name,form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,lookup_email_output_yn,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('tax_form','table','5','tax',null,null,null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('tax_form_line','tax_form','null',null,null,null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('tax_form','tax_form','1',null,null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('tax_form','text','20',null,null);
insert into table_operation (table_name,role,operation) values ('tax_form','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('tax_form','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row $session $login_name $role $folder $primary_data_list n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown $session $login_name $role $target_frame $folder $primary_data_list $update_results $update_error $dictionary');
insert into table_operation (table_name,role,operation) values ('tax_form','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('tax_form','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','tax_form','insert');
insert into role_table (role,table_name,permission) values ('supervisor','tax_form','update');
insert into appaserver_table (table_name,form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,lookup_email_output_yn,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('tax_form_line','prompt','20','tax','populate_tax_form_line',null,null,'y',null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('tax_form_line','tax_form','null',null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('tax_form_line_account','tax_form_line','null','1',null,null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('tax_form_line','tax_form','1',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('tax_form_line','tax_form_description',null,'1',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('tax_form_line','tax_form_line','2',null,null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('tax_form','text','20',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('tax_form_description','text','40',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('tax_form_line','text','5',null,null);
insert into table_operation (table_name,role,operation) values ('tax_form_line','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('tax_form_line','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row $session $login_name $role $folder $primary_data_list n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown $session $login_name $role $target_frame $folder $primary_data_list $update_results $update_error $dictionary');
insert into table_operation (table_name,role,operation) values ('tax_form_line','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('tax_form_line','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','tax_form_line','insert');
insert into role_table (role,table_name,permission) values ('supervisor','tax_form_line','update');
insert into process (process,command_line) values ('populate_tax_form_line','populate_tax_form_line.sh ignored $where');
insert into appaserver_table (table_name,form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,lookup_email_output_yn,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('tax_form_line_account','prompt','5','tax',null,null,null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('tax_form_line_account','account','null',null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('tax_form_line_account','tax_form_line','null','1',null,null,null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('tax_form_line_account','account','3',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('tax_form_line_account','tax_form','1',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('tax_form_line_account','tax_form_line','2',null,null,null,null,null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('account','text','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('tax_form','text','20',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('tax_form_line','text','5',null,null);
insert into table_operation (table_name,role,operation) values ('tax_form_line_account','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('tax_form_line_account','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row $session $login_name $role $folder $primary_data_list n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown $session $login_name $role $target_frame $folder $primary_data_list $update_results $update_error $dictionary');
insert into table_operation (table_name,role,operation) values ('tax_form_line_account','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('tax_form_line_account','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','tax_form_line_account','insert');
insert into role_table (role,table_name,permission) values ('supervisor','tax_form_line_account','update');
insert into appaserver_table (table_name,form,insert_rows_number,subschema,populate_drop_down_process,post_change_process,post_change_javascript,drillthru_yn,notepad,storage_engine,no_initial_capital_yn,create_view_statement,lookup_email_output_yn,html_help_file_anchor,exclude_application_export_yn,data_directory,javascript_filename,index_directory) values ('transaction','prompt','1','PB&J',null,null,null,'y',null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('transaction','entity','null',null,null,null,null,null,null,null,null,null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('journal','transaction','null','1',null,null,null,null,null,'n','y',null,null,null,null);
insert into relation (table_name,related_table,related_column,pair_one2m_order,omit_drillthru_yn,omit_drilldown_yn,relation_type_isa_yn,copy_common_columns_yn,automatic_preselection_yn,drop_down_multi_select_yn,join_one2m_each_row_yn,ajax_fill_drop_down_yn,omit_ajax_fill_drop_down_yn,trigger_insert_update_yn,hint_message) values ('prior_fixed_asset','transaction','purchase_date_time',null,null,null,null,null,null,null,null,null,null,'y',null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('transaction','check_number',null,'3',null,null,'y',null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('transaction','full_name','1',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('transaction','memo',null,'1',null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('transaction','street_address','2',null,null,null,null,null,null,null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('transaction','transaction_amount',null,'1',null,'y',null,null,'y',null,null,null);
insert into table_column (table_name,column_name,primary_key_index,display_order,omit_insert_prompt_yn,omit_insert_yn,additional_unique_index_yn,additional_index_yn,omit_update_yn,lookup_required_yn,insert_required_yn,default_value) values ('transaction','transaction_date_time','3',null,null,null,'y',null,null,null,null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('check_number','integer','6',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('full_name','text','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('memo','text','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('street_address','text','60',null,null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('transaction_amount','float','10','2',null);
insert into appaserver_column (column_name,column_datatype,width,float_decimal_places,hint_message) values ('transaction_date_time','current_date_time','19',null,'Must be unique throughout all transactions.');
insert into table_operation (table_name,role,operation) values ('transaction','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('transaction','supervisor','drilldown');
insert into operation (operation,output_yn) values ('delete','n');
insert into process (process,command_line) values ('delete','delete_folder_row $session $login_name $role $folder $primary_data_list n');
insert into operation (operation,output_yn) values ('drilldown','y');
insert into process (process,command_line) values ('drilldown','drilldown $session $login_name $role $target_frame $folder $primary_data_list $update_results $update_error $dictionary');
insert into table_operation (table_name,role,operation) values ('transaction','supervisor','delete');
insert into table_operation (table_name,role,operation) values ('transaction','supervisor','drilldown');
insert into role_table (role,table_name,permission) values ('supervisor','transaction','insert');
insert into role_table (role,table_name,permission) values ('supervisor','transaction','update');
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('bank_of_america','100 North Tryon Street','Charlotte','NC','28255',null,null,null,null,'https://bankofamerica.com',null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Home Depot','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Kaiser','1 Kaiser Plaza','Oakland','CA','94612-3610',null,null,null,null,'https://kp.org',null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('AT&T','208 S. Akard St.','Dallas','TX','75202',null,null,null,null,'https://att.com',null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Raley\'s Bel Air','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('California Department of Motor Vehicles','2415 1st Ave','Sacramento','CA','95818',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Safeway Supermarket','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('PG&E',' 300 Lakeside Drive, Suite 210','Oakland','CA','94612',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Target','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Shell Service','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('CVS','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('ADT','265 Thruway Park Drive, Suite 1','West Henrietta','NY','14586',null,null,null,null,'https://myadt.com',null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Liberty Mutual Group','PO Box 91018','Chicago','IL','60680-1176',null,null,null,null,'https://libertymutual.com',null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('American Red Cross','430 17th St NW.','Washington','DC','20006',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Jiffy Lube','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Amazon','410 Terry Ave N.','Seattle','WA','98109',null,null,null,null,'https://amazon.com',null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Arco','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('McDonald\'s','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Supercuts','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('UPS Store','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Safeway Gas Station','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Chevron',' 5001 Executive Parkway, Suite 200','San Ramon','CA','94583',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Unknown','null',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Rite Aid','null',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Wal Mart','702 SW 8th St','Bentonville','AR','72716-6209',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('7-Eleven','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Pepboy\'s Store','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Denny\'s Restaurant','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Wendy\'s Restaurant','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Staples','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Day\'s Inn','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('United Airlines','233 South Wacker Drive','Chicago','IL','60606',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Best Buy','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Starbucks','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Walgreens','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Amtrak','1 Massachusetts Ave NW','Washington','DC','20001',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('American Airlines','1 Skyview Dr',' Fort Worth','TX','76155-1801',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('CARLS JR','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Jamba Juice','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Speedway','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Post Office','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('FasTrak Bayarea Tolls','P.O. Box 26879','San Francisco','CA','94126',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Internal Revenue Service','1111 Constitution Avenue, NW','Washington','DC','20224',null,null,null,null,'https://www.eftps.gov/eftps/',null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Taco Bell','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('OLD NAVY','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('eBay','2025 Hamilton Ave','San Jose','CA','95125',null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Lowe\'s Hardware','any',null,null,null,null,null,null,null,null,null,null);
insert into entity (full_name,street_address,city,state_code,zip_code,land_phone_number,cell_phone_number,email_address,notepad,website_address,website_login,website_password) values ('Burger King','any',null,null,null,null,null,null,null,null,null,null);
